(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"320x480_atlas_", frames: [[0,202,320,200],[0,0,320,200],[0,606,320,200],[0,404,320,200]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["320x480_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AgPBZIAAgfIAfAAIAAAfgAgPAsIAAiEIAfAAIAACEg");
	this.shape.setTransform(89.3977,9.9264,0.75,0.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAtAAIAwCHIAxiHIAtAAIAACxg");
	this.shape_1.setTransform(78.6167,9.9264,0.75,0.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AgvBZIAAixIBeAAIAAAgIg9AAIAAApIA7AAIAAAfIg7AAIAAApIA9AAIAAAgg");
	this.shape_2.setTransform(65.7732,9.9264,0.75,0.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAoBZIAAh8IhPB8IghAAIAAixIAhAAIAAB8IBPh8IAhAAIAACxg");
	this.shape_3.setTransform(54.2984,9.9264,0.75,0.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQATAAAPAGQAbAMAAAdQAAAXgUALQAPAFAHAKQAJAMgBAPQABA2hGAAgAgYA5IAVAAQAcAAAAgWQAAgXgcAAIgVAAgAgYgTIAPAAQAXAAAAgTQAAgSgXAAIgPAAg");
	this.shape_4.setTransform(42.7487,9.9264,0.75,0.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIggAAIAACRg");
	this.shape_5.setTransform(33.4301,9.9264,0.75,0.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAageArgBQAcABAVAOQAXAOAKAZIglAAQgRgVgbgBQgaAAgRASQgRASAAAYQAAAZARARQASASAZABQAbAAAQgVIAlAAQgLAYgVAOQgVAOgdAAQgqABgaggg");
	this.shape_6.setTransform(22.7241,9.9826,0.75,0.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAfAAAPARQANANAAAXQAAAZgQAPQgRAPgaAAgAgZA5IAZAAQANAAAGgGQAHgGAAgLQAAgKgHgGQgGgGgNAAIgZAAg");
	this.shape_7.setTransform(10.7993,9.9264,0.75,0.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAxBZIgxiDIgvCDIglAAIBHixIAcAAIBGCxg");
	this.shape_8.setTransform(-1.3317,9.9264,0.75,0.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AhCBBQgbgaAAgnQAAgmAbgbQAbgbAnAAQAnAAAcAbQAbAbAAAmQAAAngbAaQgcAbgnAAQgmAAgcgbgAgqgqQgSASAAAYQAAAZASASQARASAZAAQAaAAARgSQASgTAAgYQAAgYgSgSQgRgSgaAAQgZAAgRASg");
	this.shape_9.setTransform(-15.3564,9.9826,0.75,0.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAXgTALQANAFAIAKQAJAMAAAPQAAAXgPAOQgSARglAAgAgXA5IAVAAQAbAAAAgWQAAgXgbAAIgVAAgAgXgTIAPAAQAWAAAAgTQAAgSgWAAIgPAAg");
	this.shape_10.setTransform(-27.8249,9.9264,0.75,0.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgbQAbgaAnAAQAoAAAbAaQAbAbAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSASAAAYQAAAZASASQARARAZAAQAaAAASgRQARgSAAgZQAAgZgSgRQgRgSgaABQgZAAgRARg");
	this.shape_11.setTransform(-40.9309,9.9826,0.75,0.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAcAAIBBCRIARAAIAABCgAgrAoIBXAAIgshjg");
	this.shape_12.setTransform(-55.8743,11.2014,0.75,0.75);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AghBZIAVgtIhFiEIAoAAIAuBeIApheIAkAAIhRCxg");
	this.shape_13.setTransform(-66.7866,9.9264,0.75,0.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAbgeAqAAQAcAAAWAOQAWAOALAaIgmAAQgRgWgcgBQgZABgRARQgRASAAAYQAAAZASASQARARAZABQAbAAAPgVIAnAAQgMAYgUAOQgWAOgcAAQgqAAgbgfg");
	this.shape_14.setTransform(-84.205,9.9826,0.75,0.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAzBZIgSguIhBAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_15.setTransform(66.6919,-12.5732,0.75,0.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAsAAIAxCHIAxiHIAtAAIAACxg");
	this.shape_16.setTransform(51.7485,-12.5732,0.75,0.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgnQAAgmAbgbQAcgaAmAAQAoAAAbAaQAbAbAAAmQAAAngbAbQgbAbgoAAQgmAAgcgbgAgqgqQgSARAAAZQAAAZASASQARARAZAAQAaAAASgRQARgTAAgYQAAgZgSgRQgRgRgagBQgZABgRARg");
	this.shape_17.setTransform(35.9051,-12.5169,0.75,0.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAbAAIBCCRIARAAIAABCgAgqAoIBWAAIgshjg");
	this.shape_18.setTransform(20.9616,-11.2982,0.75,0.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AgvBZIAAixIBfAAIAAAgIg+AAIAAApIA7AAIAAAfIg7AAIAAApIA+AAIAAAgg");
	this.shape_19.setTransform(4.8182,-12.5732,0.75,0.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_20.setTransform(-3.7316,-12.5732,0.75,0.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAeAAAQARQANAOAAAWQAAAZgRAPQgQAPgaAAgAgZA5IAZAAQAMAAAHgGQAHgGAAgLQAAgKgHgGQgHgGgMAAIgZAAg");
	this.shape_21.setTransform(-11.8502,-12.5732,0.75,0.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAYgUAKQAPAFAIAKQAIAMAAAPQAAA2hGAAgAgYA5IAWAAQAbAAAAgWQAAgXgbAAIgWAAgAgYgTIAQAAQAWAAAAgTQAAgSgWAAIgQAAg");
	this.shape_22.setTransform(-22.4062,-12.5732,0.75,0.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AhBBCQgcgbABgmQgBgnAcgbQAagaAnAAQAoAAAaAaQAcAbAAAnQAAAmgcAbQgbAagnABQgngBgagagAgrgqQgRASABAYQgBAZASARQARASAZAAQAaAAARgSQARgSAAgYQAAgZgRgRQgRgSgaAAQgZAAgSASg");
	this.shape_23.setTransform(-35.5122,-12.5169,0.75,0.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_24.setTransform(-46.4058,-12.5732,0.75,0.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgaQAbgcAnABQAogBAbAcQAbAaAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSARAAAZQAAAZASARQARATAZAAQAaAAASgTQARgRAAgZQAAgZgSgRQgRgSgaABQgZgBgRASg");
	this.shape_25.setTransform(-57.2805,-12.5169,0.75,0.75);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00A7E0").s().p("AgrBZIAAixIBXAAIAAAgIg2AAIAACRg");
	this.shape_26.setTransform(-68.1928,-12.5732,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t5, new cjs.Rectangle(-90.8,-19.4,181.39999999999998,38.599999999999994), null);


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AmOCsQgQgJgIgQQgKgPAAgUQAAgTAKgQQAIgQAQgJQAQgJAUAAQAUAAAQAJQAQAJAJAQQAJAQAAATQAAAUgJAPQgKAQgPAJQgQAJgUABQgUgBgQgJgAmBBJQgLAGgFAKQgHAKAAANQAAANAHAKQAFAKALAGQAKAGANABQANgBALgGQAKgGAGgKQAFgLAAgMQAAgNgFgKQgHgKgJgGQgLgGgNAAQgNAAgKAGgAH8CyIgOgiIgxAAIgNAiIgcAAIA4iFIAUAAIA3CFgAHkB4IgOgnIgQAnIAeAAgAFpCyIAAhtIgZAAIAAgYIBKAAIAAAYIgZAAIAABtgAEuCyIgpg6IAAA6IgZAAIAAiFIAZAAIAAA6IApg6IAdAAIgyBCIAyBDgACOCyIAAiFIBHAAIAAAYIguAAIAAAfIAsAAIAAAYIgsAAIAAAeIAuAAIAAAYgABmCyIgkhjIglBjIgbAAIA1iFIAVAAIA1CFgAgjCyIAAhtIgxAAIAABtIgZAAIAAiFIBiAAIAACFgAieCyIAAhkIgjBkIgVAAIgjhkIAABkIgaAAIAAiFIAiAAIAmBmIAkhmIAiAAIAACFgAnLCyIgpg6IAAA6IgaAAIAAiFIAaAAIAAA6IApg6IAeAAIgzBCIAzBDgAg6gzQgPgKgKgPQgJgQAAgTQAAgUAJgPQAJgQAQgJQAQgKAUAAQAUAAAPAKQAQAJAJAQQAJAPABAUQgBATgJAQQgJAPgQAKQgPAJgUAAQgUAAgQgJgAguiXQgJAGgGALQgHAKAAAMQAAANAHAKQAGALAJAGQALAGANAAQAOAAAJgGQAKgGAFgLQAHgKgBgNQABgMgHgKQgGgLgJgGQgJgGgOAAQgNAAgLAGgAIYgtIAAiFIBHAAIAAAXIguAAIAAAfIAtAAIAAAYIgtAAIAAAfIAuAAIAAAYgAHrgtIgpg7IAAA7IgZAAIAAiFIAZAAIAAA5IApg5IAdAAIgyBBIAyBEgAF3gtIAAhuIgwAAIAABuIgZAAIAAiFIBiAAIAACFgADJgtIAQgiIg0hjIAeAAIAjBGIAghGIAbAAIg9CFgACDgtIgpg7IAAA7IgZAAIAAiFIAZAAIAAA5IApg5IAdAAIgyBBIAyBEgAiGgtIAAhuIgxAAIAABuIgZAAIAAiFIBiAAIAACFgAkrgtIAAheIg7BeIgZAAIAAiFIAZAAIAABdIA7hdIAZAAIAACFgAnkgtIAAiFIAmAAQAQAAAJAEQAKAFAEAHQAFAGABAHQADAHgBAFQABAGgDAIQgCAHgFAGQgGAGgIAEQgKAEgOAAIgNAAIAAAzgAnLh4IAOAAIAJAAQAFgCADgDQAEgEAAgIQAAgIgEgEQgDgEgFgBIgJgBIgOAAgAoVgtIAAhuIgwAAIAABuIgaAAIAAiFIBiAAIAACFg");
	this.shape.setTransform(0.1,-2.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(-60.6,-20.5,121.5,36.3), null);


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AgPCsQgQgJgKgQQgJgPAAgUQAAgTAJgQQAKgQAPgJQAQgJATAAQAUAAAQAJQAQAJAJAQQAJAQABATQgBAUgJAPQgKAQgPAJQgQAJgUABQgTgBgPgJgAgEBJQgKAGgGAKQgFAKAAANQAAANAFAKQAGAKAKAGQAKAGANABQAOgBAJgGQALgGAFgKQAHgLAAgMQAAgNgHgKQgFgKgLgGQgJgGgOAAQgNAAgKAGgAkTCvQgNgHgJgKQgJgKgEgNQgEgMAAgLQAAgMAEgMQAEgMAJgKQAJgKANgHQANgGARAAQAOAAAMAEQAMAFAKAJQAIAJAGANIgcAAQgDgEgFgEQgFgEgGgCQgGgCgJAAQgNAAgKAGQgKAGgGAKQgFALgBAMQABAMAFALQAHAKAKAGQAKAGANABQAJAAAIgEQAJgEAGgIIAcAAQgFAMgJAJQgJAJgMAEQgMAFgOABQgSgBgMgGgAGTCyIAAgzIgkAzIgdAAIAlgxQgKgBgJgFQgHgGgFgIQgEgJgBgLIABgNQADgHAEgHQAGgHAKgFQAKgFARAAIAmAAIAACFgAF1BIQgFADgCAEQgCAFAAAFQAAAFACAEQACAFAFADQAGACAKABIAOAAIAAgoIgOAAQgKAAgGADgAEnCyIAAhdIg7BdIgZAAIAAiFIAZAAIAABeIA7heIAZAAIAACFgABqCyIAAiFIAhAAIAIAAIALACQAHACAGAEQAGADAEAHQAEAHAAAKQAAAIgDAGIgGAIIgFAEQAKADAGAJQAGAIAAAMQAAAKgEAJQgEAJgMAGQgMAGgVAAgACDCaIAQAAIAFAAIAHgCQAEgBACgEQADgDAAgGIgBgHQgBgEgEgDQgFgEgKAAIgQAAgACDBgIAMAAQAIAAAEgCQADgDABgDIABgFQAAgHgDgDQgDgDgEAAIgHgBIgMAAgAhOCyIgkhjIgkBjIgcAAIA1iFIAVAAIA2CFgAmNCyIAPgiIgzhjIAfAAIAjBHIAehHIAbAAIg8CFgAjWgUIAAgZIhZAAIAAiFIAZAAIAABtIAwAAIAAhtIAZAAIAABtIAPAAIAAAxgApzgxQgNgGgJgKQgIgLgFgMQgEgMAAgMQAAgLAEgMQAFgMAIgKQAJgLANgGQANgHARAAQAOAAAMAFQANAFAIAJQAKAJAFANIgcAAQgDgFgFgDQgFgEgGgDQgGgCgJAAQgNAAgKAHQgKAGgFAKQgHAKAAAMQAAANAHAKQAFALALAGQAKAGANAAQAJAAAIgEQAJgDAGgIIAcAAQgFALgJAJQgJAJgMAFQgMAFgOAAQgSAAgMgHgAJUgtIAAiFIBHAAIAAAXIguAAIAAAfIAsAAIAAAYIgsAAIAAAfIAuAAIAAAYgAIjgtIAAiFIAYAAIAACFgAG8gtIAAiFIAaAAIAAAzIATAAQARAAAKAGQAJAGAEAJQAEAKABAKQgBAMgGAJQgFAJgKAGQgKAFgNAAgAHWhFIATAAQAJAAAGgFQAEgEAAgIQAAgIgEgFQgGgEgJAAIgTAAgAGMgtIAAg4IgxAAIAAA4IgZAAIAAiFIAZAAIAAA1IAxAAIAAg1IAYAAIAACFgADagtIAAiFIAZAAIAAAzIATAAQAQAAALAGQAJAGAEAJQAFAKAAAKQgBAMgGAJQgFAJgKAGQgKAFgNAAgADzhFIAUAAQAIAAAFgFQAGgEAAgIQAAgIgGgFQgFgEgIAAIgUAAgACxgtIgkhjIglBjIgbAAIA1iFIAVAAIA1CFgAAwgtIgOgjIgwAAIgOAjIgbAAIA3iFIAUAAIA3CFgAAYhoIgOgmIgPAmIAdAAgAhdgtIAAheIg7BeIgZAAIAAiFIAZAAIAABdIA7hdIAZAAIAACFgAmNgtIAAiFIBIAAIAAAXIgvAAIAAAfIAtAAIAAAYIgtAAIAAAfIAvAAIAAAYgAm+gtIAAhuIgwAAIAABuIgZAAIAAiFIBiAAIAACFg");
	this.shape.setTransform(-0.35,-0.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(-67,-18.5,133.4,36.3), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AAmBDIgNgjIgxAAIgNAjIgcAAIA4iFIATAAIA4CFgAgOAIIAdAAIgPgmg");
	this.shape.setTransform(84.725,11.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AATBDIgpg7IAAA7IgZAAIAAiFIAZAAIAAA6IApg6IAdAAIgyBCIAyBDg");
	this.shape_1.setTransform(72.85,11.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AAeBDIAAhdIg7BdIgZAAIAAiFIAZAAIAABdIA7hdIAZAAIAACFg");
	this.shape_2.setTransform(60.125,11.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAYBDIAAg4IgvAAIAAA4IgZAAIAAiFIAZAAIAAA2IAvAAIAAg2IAZAAIAACFg");
	this.shape_3.setTransform(47.275,11.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("AAgBDIggguIgfAuIgdAAIAvhDIgvhCIAdAAIAfAvIAggvIAdAAIguBCIAuBDg");
	this.shape_4.setTransform(34.975,11.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgjBDIAAiFIBHAAIAAAYIguAAIAAAfIAsAAIAAAXIgsAAIAAAfIAuAAIAAAYg");
	this.shape_5.setTransform(24.25,11.125);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AgLBDIAAhtIgZAAIAAgYIBJAAIAAAYIgYAAIAABtg");
	this.shape_6.setTransform(15.625,11.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("AAUBDIAAg0IgBAAIgiA0IgdAAIAlgyQgQgCgJgKQgLgKAAgRQAAgQAIgLQANgRAcAAIAnAAIAACFgAgTgWQAAAUAZAAIAOAAIAAgoIgOAAQgZAAAAAUg");
	this.shape_7.setTransform(1.9,11.125);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAmBDIgNgjIgxAAIgNAjIgcAAIA4iFIATAAIA4CFgAgOAIIAdAAIgPgmg");
	this.shape_8.setTransform(-9.925,11.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AAYBDIAAg4IgvAAIAAA4IgZAAIAAiFIAZAAIAAA2IAvAAIAAg2IAZAAIAACFg");
	this.shape_9.setTransform(-22.775,11.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("AAZBDIAAg4IgwAAIAAA4IgZAAIAAiFIAZAAIAAA2IAwAAIAAg2IAYAAIAACFg");
	this.shape_10.setTransform(-35.075,11.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AgxAxQgVgUAAgdQAAgcAVgUQAUgVAdAAQAeAAAVAVQATAUABAcQgBAdgUAUQgUAVgeAAQgdAAgUgVgAgggfQgNANAAASQAAATANANQANAOATAAQATAAAOgOQAMgNABgTQgBgSgMgNQgNgOgUAAQgSAAgOAOg");
	this.shape_11.setTransform(-48.8,11.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("AAgBDIggguIgeAuIgeAAIAvhDIgvhCIAeAAIAeAvIAggvIAdAAIguBCIAuBDg");
	this.shape_12.setTransform(-62.55,11.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AgZBDIAQgiIg0hjIAeAAIAjBGIAehGIAcAAIg9CFg");
	this.shape_13.setTransform(-75.025,11.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AATBDIgpg7IAAA7IgZAAIAAiFIAZAAIAAA6IApg6IAdAAIgyBCIAyBDg");
	this.shape_14.setTransform(-86.55,11.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAUBDIAAg0IgjA0IgdAAIAlgxQgQgCgJgLQgLgKAAgRQAAgQAIgLQANgRAcAAIAnAAIAACFgAgTgWQAAAUAYAAIAPAAIAAgoIgPAAQgYAAAAAUg");
	this.shape_15.setTransform(60.7,-11.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AAmBDIgNgjIgxAAIgNAjIgcAAIA4iFIATAAIA4CFgAgOAIIAdAAIgPgmg");
	this.shape_16.setTransform(48.875,-11.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AASBDIgog7IAAA7IgZAAIAAiFIAZAAIAAA6IAog6IAeAAIgxBCIAxBDg");
	this.shape_17.setTransform(37,-11.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("AgwAuQgRgUAAgaQAAgZARgUQAUgYAgAAQAVAAAQALQARALAIATIgcAAQgOgRgUAAQgSAAgNAOQgNAOAAARQAAATANANQAOAOARAAQAVAAAMgQIAcAAQgSAogsAAQgfAAgUgYg");
	this.shape_18.setTransform(24,-11.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AAYBDIAAg4IgvAAIAAA4IgZAAIAAiFIAZAAIAAA2IAvAAIAAg2IAZAAIAACFg");
	this.shape_19.setTransform(10.725,-11.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AAUBDIAAg0IgjA0IgdAAIAlgxQgQgCgJgLQgLgKAAgRQAAgQAIgLQAMgRAdAAIAnAAIAACFgAgTgWQAAAUAZAAIAOAAIAAgoIgOAAQgZAAAAAUg");
	this.shape_20.setTransform(-1.15,-11.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("AgrBDIAAiFIAZAAIAAA0IATAAQAXAAALANQAKAKAAARQgBASgMALQgMAMgTAAgAgSArIATAAQATAAAAgRQAAgIgGgFQgFgEgIAAIgTAAg");
	this.shape_21.setTransform(-11.1,-11.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("AAkBDIgkhiIgkBiIgbAAIA1iFIAVAAIA1CFg");
	this.shape_22.setTransform(-23.275,-11.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AAmBDIgOgjIgwAAIgNAjIgcAAIA4iFIATAAIA4CFgAgOAIIAdAAIgPgmg");
	this.shape_23.setTransform(-36.475,-11.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgMBDIAAhtIgYAAIAAgYIBJAAIAAAYIgZAAIAABtg");
	this.shape_24.setTransform(-46.175,-11.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AAeBDIAAhdIg6BdIgaAAIAAiFIAaAAIAABdIA6hdIAYAAIAACFg");
	this.shape_25.setTransform(-56.7,-11.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(-91.3,-18.1,182.6,36.3), null);


(lib.pic5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._5();
	this.instance.parent = this;
	this.instance.setTransform(-120,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pic5, new cjs.Rectangle(-120,-100,320,200), null);


(lib.pic3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._3();
	this.instance.parent = this;
	this.instance.setTransform(-120,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pic3, new cjs.Rectangle(-120,-100,320,200), null);


(lib.pic2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._2();
	this.instance.parent = this;
	this.instance.setTransform(-120,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pic2, new cjs.Rectangle(-120,-100,320,200), null);


(lib.pic1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-120,-100);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.pic1, new cjs.Rectangle(-120,-100,320,200), null);


(lib.butt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYAvIAAhdIAxAAIAAARIggAAIAAAWIAfAAIAAAPIgfAAIAAAWIAgAAIAAARg");
	this.shape.setTransform(47.0311,0.8162,1.3333,1.3333);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgYAvIAAhdIAxAAIAAARIggAAIAAAWIAfAAIAAAPIgfAAIAAAWIAgAAIAAARg");
	this.shape_1.setTransform(38.1978,0.8162,1.3333,1.3333);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AARAvIAAgoIghAAIAAAoIgSAAIAAhdIASAAIAAAmIAhAAIAAgmIASAAIAABdg");
	this.shape_2.setTransform(27.9645,0.8162,1.3333,1.3333);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgfAvIAAhdIA2AAIAAARIgkAAIAAATIAOAAQATAAAIAMQAEAHAAAJQAAANgJAIQgIAIgOAAgAgNAeIAOAAQAGAAAEgEQAEgDAAgFQAAgFgDgCQgEgFgHAAIgOAAg");
	this.shape_3.setTransform(17.3979,0.8162,1.3333,1.3333);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiAjQgPgOAAgVQAAgTAPgOQAOgPAUAAQAVAAAPAPQANAOAAATQAAAVgNAOQgPAOgVAAQgUAAgOgOgAgWgWQgJAKAAAMQAAANAJAKQAJAJANAAQANAAAKgJQAKgKgBgNQABgMgKgKQgJgJgOAAQgNAAgJAJg");
	this.shape_4.setTransform(4.8979,0.8495,1.3333,1.3333);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAvIAAhdIAaAAQASAAAKAMQAFAHAAALQAAALgHAHQgIAKgSgBIgJAAIAAAkgAgMgFIALAAQAOAAgBgMQABgMgOAAIgLAAg");
	this.shape_5.setTransform(-6.502,0.8162,1.3333,1.3333);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAiA4IAAgSIhDAAIAAASIgRAAIAAgjIAJAAIAihMIAPAAIAiBMIAJAAIAAAjgAgWAVIAtAAIgXg0g");
	this.shape_6.setTransform(-18.602,1.9829,1.3333,1.3333);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgiAjQgPgOAAgVQAAgTAPgOQAOgPAUAAQAVAAAOAPQAOAOABATQgBAVgOAOQgOAOgVAAQgUAAgOgOgAgWgWQgJAKAAAMQAAANAJAKQAKAJAMAAQAOAAAJgJQAKgKgBgNQAAgMgJgKQgJgJgOAAQgMAAgKAJg");
	this.shape_7.setTransform(-32.7019,0.8495,1.3333,1.3333);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARAvIAAhMIghAAIAABMIgSAAIAAhdIBEAAIAABdg");
	this.shape_8.setTransform(-45.5686,0.8162,1.3333,1.3333);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("An6CDIAAkFIP1AAIAAEFg");
	this.shape_9.setTransform(0.0313,-0.0505,1.3333,1.3333);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.butt, new cjs.Rectangle(-67.5,-17.4,135.1,34.9), null);


// stage content:
(lib._320x480 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EgY6glaMAx1AAAMAAABK1Mgx1AAAg");
	this.shape.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(219));

	// t5
	this.instance = new lib.t5();
	this.instance.parent = this;
	this.instance.setTransform(160,344,1.0666,1.0666,0,0,0,0.1,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(159).to({_off:false},0).to({regX:0,regY:0,scaleX:1.3333,scaleY:1.3333,x:159.95,y:343.95,alpha:1},6,cjs.Ease.get(1)).wait(47).to({regX:0.1,regY:0.1,scaleX:1.0666,scaleY:1.0666,x:160,y:344,alpha:0},6,cjs.Ease.get(1)).wait(1));

	// t3
	this.instance_1 = new lib.t3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(160,344,1.0666,1.0666,0,0,0,0.1,0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(106).to({_off:false},0).to({regX:0,regY:0,scaleX:1.3333,scaleY:1.3333,x:159.95,y:343.95,alpha:1},6,cjs.Ease.get(1)).wait(47).to({regX:0.1,regY:0.1,scaleX:1.0666,scaleY:1.0666,x:160,y:344,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(53));

	// t2
	this.instance_2 = new lib.t2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(160,344,1.0666,1.0666,0,0,0,0.1,0.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(53).to({_off:false},0).to({regX:0,regY:0,scaleX:1.3333,scaleY:1.3333,x:159.95,y:343.95,alpha:1},6,cjs.Ease.get(1)).wait(47).to({regX:0.1,regY:0.1,scaleX:1.0666,scaleY:1.0666,x:160,y:344,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(106));

	// t1
	this.instance_3 = new lib.t1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(160,346,1.0666,1.0666,0,0,0,0.1,0.1);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:0,regY:0,scaleX:1.3333,scaleY:1.3333,x:159.95,y:343.95,alpha:1},6,cjs.Ease.get(1)).wait(47).to({regX:0.1,regY:0.1,scaleX:1.0666,scaleY:1.0666,x:160,y:344,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(159));

	// 5.jpg
	this.instance_4 = new lib.pic5();
	this.instance_4.parent = this;
	this.instance_4.setTransform(120,185);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(159).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(47).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

	// 3.jpg
	this.instance_5 = new lib.pic3();
	this.instance_5.parent = this;
	this.instance_5.setTransform(120,185);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(106).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(47).to({alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(53));

	// 2.jpg
	this.instance_6 = new lib.pic2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(120,185);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(53).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(47).to({alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(106));

	// 1.jpg
	this.instance_7 = new lib.pic1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(120,185);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({alpha:1},6,cjs.Ease.get(1)).wait(47).to({alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(159));

	// Слой 2
	this.instance_8 = new lib.butt();
	this.instance_8.parent = this;
	this.instance_8.setTransform(160,417.9);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(159).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(47).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

	// fon
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s().p("AvSBkIAAgRIgoAAIAAAOIgBACIgCABIgGAAIAAgYIACAAIADAAIAEgDIACgEIACgIIAEgbIAfAAIAAAqIAJAAIAAAVIAAACIgCABgAvuA/IgCAIIgDAFIAYAAIAAgjIgPAAgAPgBSIgHgDIgFgHIgDgHIAEgCIADAAQAAAAABABQAAAAABAAQAAAAAAAAQAAABAAAAIAEAHIAEADIAHABIAGgBIAFgDIACgEIABgFIAAgFIgDgEIgGgCIgJgBIAAgHIAIgBIAGgCIACgFIABgEIgBgGIgCgDQgBgBAAAAQgBAAgBgBQAAAAgBAAQAAAAgBAAIgEgBIgFABIgEACIgDADIgBAEIgCACIgDABIgFgBIADgJIAFgGIAHgDIAIgCIAJACIAHADIAEAGIABAHIgBAGIgCAFIgEADIgFACQAHACADAFQADAEAAAGQAAAFgCADQAAADgEAFQgEADgEAAIgJACgAOiBSIgFgDIgDgDIADgEIACgBIACABIADABQABABAAAAQABAAAAABQABAAAAAAQABAAAAAAIAGABIAGgBIAFgEIADgEIABgHIAAgGIgDgEIgFgDIgHgCQgFAAgGACIgGgBIAGghIAhAAIAAAEIgBADIgEACIgWAAIgDARIAKgCQAGAAAEADQADAAAEAEQADAEABADQACADAAAGIgCAJQgBAEgEAEQgFAEgEABQgEACgGAAgAM1BSQgEgCgEgFQgEgGgBgGQgCgFAAgKQAAgJACgHQABgGAEgFQAGgGACgBQAEgCAGAAIAKACQAFACADAFQAEAEACAHQACAHAAAJQAAAKgCAFQgCAJgEADQgDAEgFADIgKACQgGAAgEgCgAM5AVIgFAFIgEAJIAAAaIAEAJIAFAFIAGABIAGgBIAFgFIAEgJIABgNIgBgNQgBgFgDgEIgFgFIgGgCgALEBSQgGgDgCgEQgFgFgBgHQgCgFAAgKQAAgJACgHQABgGAFgFQAEgFAEgCQAEgCAGAAQAFAAAFACQAEACAEAFQAEAFACAGIABAQIgBAPQgCAHgEAFQgDAEgFADQgFACgFAAQgGAAgEgCgALIAVIgFAFQgDAEgBAFIgBANIABANQABAEADAFIAFAFIAGABIAFgBIAGgFQADgFAAgEIACgNIgCgNQAAgFgDgEIgGgFIgFgCgAKLBSQgEgBgDgDIgEgIQgDgFAAgFIADgKIAGgMIASgWIACgCIADgBIAIAAIgVAaIgCACIgBACIAFgCIAHgBIAHABQAEABADADIAFAHIABAJIgBAJIgFAHQgEAEgEABQgEACgGAAQgFAAgFgCgAKQAwIgFADIgDAFIgBAFIAAAGIADAFIAFADIAGABIAGgBIAFgDIADgFIABgGIgBgGIgDgEIgEgDIgHgBgAFvBSQgFgDgDgEQgDgDgCgJQgCgFAAgKQAAgJACgHQACgHADgEQAEgFAEgCQAGgCAFAAIAJACIAJAHQADAEACAHQACAHAAAJQAAAKgCAFQgCAJgDADQgEAEgFADIgJACQgFAAgGgCgAFzAVIgFAFQgCAEgBAFIgBANIABANIADAJIAFAFIAHABIAFgBIAFgFQACgCACgHIABgNIgBgNQgCgHgCgCIgFgFIgFgCgAAcBRQgFgBgHgGQgFgHgCgFQgCgIAAgGQAAgGACgIQADgHAEgEQAFgFAHgDQAIgDAGAAQAFAAAJADQAHADAEAFQAFAEACAHQADAFAAAJQAAAJgDAFQgCAFgFAHQgGAGgFABQgGADgIAAQgJAAgFgDgAAgAXQgEABgEAEQgDAEgCAEQgCAGAAAGQAAAGACAGQABAEAEAEQAEAEAEABIAKACIAKgCIAIgFQADgDACgFIABgMIgBgMIgFgIIgIgFIgKgCgAhABSIgFgDIgEgDIADgEIACgBIADABIADABIAEACIAGABIAGgBIAFgEIADgEIABgHIgBgGIgDgEIgEgDIgHgCQgFAAgHACIgFgBIAFghIAiAAIAAAEIgBADIgFACIgVAAIgDARIAKgCQAFAAAEADQAEAAADAEQAEAEABADQABADAAAGIgBAJQgCAEgEAEQgEAEgEABQgEACgGAAgAitBSQgFgDgEgEQgCgDgDgJQgCgFAAgKQAAgJACgHQADgHACgEIAJgHQAEgCAGAAIAKACQAEACAEAFQADAEACAHQACAHAAAJQAAAKgCAFQgCAJgDADQgDAEgFADIgKACQgGAAgEgCgAipAVIgGAFIgDAJIAAAaIADAJIAGAFIAGABIAGgBIAFgFQADgFAAgEQACgDAAgKQAAgKgCgDQAAgFgDgEIgFgFIgGgCgAlcBSIgFgDIgDgDIADgEIACgBIACABIADABQABABAAAAQAAAAABABQABAAAAAAQABAAAAAAIAGABIAGgBIAFgEIADgEIABgHIAAgGIgDgEIgFgDIgHgCQgFAAgGACIgGgBIAGghIAhAAIAAAEQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAAAIgEACIgWAAIgDARIAKgCQAGAAAEADQADAAAEAEQADAEABADIABAJQAAAFgCAEQAAAEgFAEQgEAEgEABQgEACgGAAgAnJBSQgEgCgEgFQgEgGgBgGQgCgFAAgKQAAgJACgHQABgGAEgFQAGgGACgBQAEgCAGAAIAKACQAFACADAFQAEAEACAHQACAHAAAJQAAAKgCAFQgCAJgEADQgDAEgFADIgKACQgGAAgEgCgAnFAVIgFAFIgEAJIAAAaIAEAJIAFAFIAGABIAGgBIAFgFIAEgJIABgNIgBgNQgBgFgDgEIgFgFIgGgCgAuFBSQgEAAgDgDQgEgDgBgEQgCgDAAgGQAAgFADgFQAEgFAHgCQgGAAgDgFQgCgEAAgGQAAgFABgDQABgEADgCIAHgDIAJgCIAJACIAGADIAFAGIABAIQAAAGgCAEQgEAFgFAAQAHACADAFQADAEAAAGIgBAJQgCAFgDACQgDACgFABIgJACgAuBAzIgEADIgDAEQgBACAAADIAAAGIADADIAFAEIAGAAIAGAAIAEgEQABAAAAAAQAAAAABgBQAAAAAAgBQABgBAAAAIABgGIgBgFIgDgEIgFgDIgFAAgAuAAUIgEADIgDADIAAAFIAAAEQAAABAAAAQABABAAAAQAAABABAAQAAABABAAIADADIAGABIAFgBIAEgDIADgEIAAgEIAAgFIgDgDIgEgDIgFgBgAvBBSIgBgDIAAgEIABgDIADgBIAEAAIADABIACAGIgCAEIgFACgAN/BTIAAgSIgeAAIgDgBIgCgGIAjgtIAJAAIAAAtIAJAAIAAAGIgCABIgHAAIAAASgANnA6IAYAAIAAggIABgCgAL2BTIAdg5IADgEIglAAIgBgBIgBgCIAAgGIAwAAIAAAGIgBADIgcA5IgDADIgDABgAJNBTIAXgeIACgCIgHACIgHABIgHgBIgHgEIgEgGIgBgJIABgIIAFgIIAIgEQAEgCAFAAQAGAAAEACQADAAAEAEQADADABAFQACAEAAAFIgCALIgXAjIgCABIgDABgAJWAVIgEADIgDAEIgBAGQAAAGADADQAFAEAGAAIAGgBIAEgDIADgEIABgFIgBgGIgDgEQgBgCgDgBIgGgCgAITBTIAdg5IADgEIglAAIgBgBIgBgCIAAgGIAwAAIAAAGIgBADIgdA5IgCADIgCABgAHaBTIAdg5IADgEIgkAAIgCgBIAAgCIAAgGIAvAAIAAAGIAAADIgdA5IgCADIgEABgAG5BTIAAgSIgfAAIgCgBIAAgBIgBgFIAhgtIAKAAIAAAtIAKAAIAAAFIgBABIgBABIgIAAIAAASgAGhA6IAYAAIAAggIABgCgAEwBTIAAgHIAPAAIAAgvIABgEIgNAKIgBAAIgCAAIgBAAIgDgEIAVgSIAIAAIAAA/IANAAIAAAHgAD4BTIAAggIglAAIAAAgIgJAAIAAhGIAJAAIAAAfIAlAAIAAgfIALAAIAABGgACOBTIAAhGIAVAAQAHAAAFACQAGABACADIAFAHIACAJIgCAJIgFAHQgDADgFABQgFADgHAAIgKAAIAAAZgACZAxIARgBIAGgEQAAAAABAAQAAAAAAgBQABAAAAgBQAAgBABAAIABgGIgBgHIgDgDIgFgDIgSgBgABaBTIAAhGIAqAAIAAAIIggAAIAAA+gAh7BTIAAgHIAPAAIAAgzIgLAKIgCAAIgDAAIAAAAIgDgEIAVgSIAIAAIAAA/IANAAIAAAHgAj0BTIAAgEIABgBIABgCIAbgcIAEgFIADgGIABgFIgCgGIgCgDIgEgCIgFgBIgFABIgDACIgDADIgCAEIgCACIgDABIgEgBIACgJIAFgGIAHgDIAJgCIAIACQAEAAADADQAEAEAAADQACACAAAGIgBAHIgEAGIgEAGIgYAZIAIgCIAXAAIACABIABADIAAAFgAklBTIAAgHIAPAAIAAgzIgMAKIgBAAIgCAAIgBAAIgDgEIAVgSIAHAAIAAA/IAOAAIAAAHgAl/BTIAAgSIgfAAIgCgBIgCgGIAigtIAJAAIAAAtIAKAAIAAAGIgCABIgIAAIAAASgAmXA6IAYAAIAAgigAoIBTIAdg5IADgEIglAAIgBgBIgBgCIAAgGIAwAAIAAAGIgBADIgdA5IgCADIgDABgApBBTIAdg5IADgEIgkAAIgCgBIAAgCIAAgGIAvAAIAAAGIgBADIgdA5IgBADIgEABgAp4BTIAAggIglAAIAAAgIgLAAIAAhGIALAAIAAAfIAlAAIAAgfIAKAAIAABGgArDBTIAAggIglAAIAAAgIgKAAIAAhGIAKAAIAAAfIAlAAIAAgfIAKAAIAABGgAsOBTIAAg6IgBADIgiAzIgCADIgDABIgHAAIAAhGIAKAAIAAA6IABgEIAkg1IACgBIAIAAIAABGgAOvgLIAAgRIhEAAIAAgyIAJAAIAAArIAUAAIAAgrIAJAAIAAArIATAAIAAgrIAKAAIAAArIAJAAIAAAWIgBACIgCAAgALRgLIAAgRIgpAAIAAAPIgBACIgCAAIgFAAIAAgYIACAAIADgBIADgBIADgGIACgHIADgcIAgAAIAAArIAJAAIAAAWIgBACIgBAAgAK1gvIgCAIIgDAEIAYAAIAAgkIgQAAgAHXgLIAAhDIAGAAQAAAAABABQAAAAAAAAQABAAAAAAQAAABAAAAIABAGQACgEAFgCQAEgCAFAAQAGAAACACQACAAAEAEIAEAIIABALIgBAKIgEAIIgHAGQgFACgEAAIgIgBIgGgFIAAAWgAHmhFIgGAFIAAAZIAFADIAGACQAHAAAEgFQADgGAAgIIAAgJIgCgFIgFgDIgEgBQgFAAgDACgAt/gLIAAgRIg4AAIAAAPIAAACIgDAAIgGAAIAAgZIAHAAIAEgCIACgFIADgIIACgLIADglIAqAAIAAA/IALAAIAAAXIAAACIgDAAgAujhGIgGAbIgEAHIAiAAIAAg2IgXAAgAWvgRIAAAAIAGgLIgBAAIgCAAIgCgCIgBgCIAAgCQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAQAAAAABAAIADAAIACACIACABIAAADIgCAJIgEAFIgEAEgAFggQIAAgBIgBAAIACgDIACgCIACgDIAAgDIAAAAIgFgCIgBgCIAAgCIABgEQABAAAAgBQABAAAAAAQABAAAAAAQABAAABAAIACAAIADACIABABIAAADIgBAFIgBAEIgHAJgAh2gRIAAAAIABgCIABgBIAEgIIgDAAIgCgCIgBgCIgBgCIACgEQABAAAAgBQAAAAABAAQAAAAABAAQABAAABAAIACAAIACACIACAEIgBAFIgFAJIgEAEgAQ6gdQgDgBgEgEIgFgIIgBgLIABgKIAEgIIAIgFIAKgCQAHAAACACIAHAEIgCAEIgBABIgDAAIgFgEIgFAAIgGABIgEAEIgDAFIgBAIIABAIIADAGIAEADIAGACIAJgDIAEgCIABABIADADIgEAEIgEACIgFABIgGABQgEAAgEgCgAM+gdQgDgBgEgEQgDgDgCgGIgCgKIACgLIAFgHQACgDAFgCIAKgCIAKACQAFABADAEIAEAHIACALIgCAKQgCAGgCADQgFAEgDABQgEACgGAAQgGAAgEgCgAM+hCQgEAEAAAJQAAAKAEAEQADAFAHgBQAHABAEgFQAEgGAAgIQAAgHgEgGQgEgFgHAAQgIAAgCAFgAKCgcIgFgBIgEgCIgEgEIADgDIABgBIAIADIAGACIAEgBIAGgEIABgEQAAgDgEgCQgCgDgGAAIgGAAIAAgGIAGAAQAFAAADgCQADgCAAgDIgBgDIgCgCIgDgCIgEAAIgFAAIgGADIgBABIgCAAIgCgGIAGgDQADgCAHAAIAIAAIAGAEIADADIABAGIAAADIgCADIgCADIgFABQAEACADADQADACAAAFQAAAFgBACQgBADgDACIgHADIgHABgAJRgdQgDgBgEgEQgEgCgCgHIgBgLIABgKIAFgHIAHgFIAKgCQAGAAACACQAEAAADADIAEAIIACAKIgBACIgBABIghAAIABAHIADAGIAFADIAGABIAGgBIAHgCIACgBIABABIADADIgEAEIgFACIgFABIgFABQgFAAgFgCgAJRhEQgEADgBAHIAaAAIAAgGIgCgDIgFgEIgFgBQgGABgDADgAIZgdIgHgFQgEgEgBgFQgCgEAAgGIACgLQABgDAEgEQADgEAEgBIAKgCIAKACQAEABADAEQAEAEABADIACALQAAAGgCAEQgBAFgEAEIgHAFQgEACgGAAQgFAAgFgCgAIYhCQgDAGAAAHQAAAIADAGQAEAFAHgBQAHABAEgFQADgGAAgIQAAgHgDgGQgEgFgHAAQgIAAgDAFgAE0gcIgEgCQgBgBgCgEIgBgFIABgGIAGgFIAJgEIAPAAIAAgFQAAgEgDgEQgDgDgEAAIgGAAIgIAGIgBgBIgCgBIgCgEQAEgDAFgCQAEgCAHAAIAHAAIAGAFIAEAGIABAHIAAAgIgEAAQgBABAAgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgCgCIAAgFIgFAEIgDACIgFABIgFABgAFAgxIgGACIgEACIgBAEIABAEIABABIADACIADAAIAEAAIAEgCIAGgEIAAgKgACogdQgDgBgEgEIgFgIQgBgDAAgIQAAgHABgDQABgDADgFIAIgFIAKgCQAHAAADACIAHAEIgDAEIgBABIgDAAIgCgCIgDgCIgEAAIgHABQgDABgBADQgDACAAADIgBAIIABAIIADAGIAEADIAGACIAFgCIAGgCIABgBIADABIACADIgEAEIgJADIgGABQgEAAgEgCgABxgdQgEgBgEgEQgDgDgBgGQgCgEAAgGIACgLQABgEADgDQACgDAGgCIAKgCIAJACQAFABADAEIAFAHIABALQAAAIgBACIgFAJQgEAEgEABQgEACgFAAQgGAAgEgCgABwhCQgDAEAAAJQAAAKADAEQAEAFAHgBQAHABAEgFQADgGAAgIQAAgHgDgGQgEgFgHAAQgIAAgDAFgAgggcIgCgBIgCgCIAAgDIAAgCIACgCIACgBIAFAAIACABIABACIAAAFIgBACIgCABIgDABgAlMgcIgFgBIgIgGIADgEIACAAIAFACQABAAAAAAQABAAAAABQABAAAAAAQABAAABAAQACACADgBIAGgBIAFgDIADgGIACgHIgCgFQAAgCgDgDIgEgCIgHgBQgFAAgGABIgGgBIAGgiIAiAAIAAAFIgCADQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAIgWAAIgDARIAKgBQAGAAAEACQAEABADADQAEADAAAEIACAIQAAAGgCAEQgBAEgEAEIgJAFQgEACgGAAgAoigcIgCgBIgBgFIABgEIACgBIAFAAIACABIACACIABACIgBADIgCACIgCABIgCABgApjgcIgCgBIgCgCIAAgDIAAgCIACgCIACgBIAFAAIACABIABACIAAAFIgBACIgCABIgDABgArGgcIgBgBIgCgCIAAgDIAAgCIACgCIABgBIAGAAIABABIACACIAAACIAAADIgCACIgBABIgDABgAr3geQgFgBgGgGQgFgFgCgGQgCgHAAgIQAAgIACgHQAEgHADgEQAEgEAHgDQAJgDAFAAQAIAAAGADQAFACAEAEIgCAFIgCABIgBAAIgCgBIgDgCIgGgCIgHgBIgJABIgIAGIgFAJQgCAFAAAGQAAAHACAEIAFAJQACADAGADQACABAHAAIAFAAIAJgDIAEgDIABgBIACAAIAEAGQgEADgHAEQgFADgJAAQgJAAgFgDgA0IgeQgEgBgHgGQgGgHgBgEQgDgJAAgGQAAgGADgJQACgFAFgGQAEgEAHgDQAIgDAGAAQAFAAAJADQAHADAEAEQAEAEADAHQADAGAAAJQAAAIgDAHQgCAGgFAFQgFAGgGABQgGADgIAAQgJAAgFgDgA0EhZIgIAGQgDAEgCAFQgCAFAAAGQAAAHACAEQABAEAEAFIAIAGIAKABIAKgBIAIgGQADgDACgGIABgLIgBgLIgFgJIgIgGIgKgBgA1WgeQgHgCgFgFQgFgHgCgEQgCgHAAgIQAAgJACgGQADgFAEgGQADgDAJgEQAIgDAGAAQAFAAAJADQAIAEADADQAFAGACAFQADAJAAAGQAAAGgDAJQgCAEgFAHQgFAFgGACQgGADgIAAQgJAAgFgDgA1ShZIgJAGIgEAJIgCALIACALQACAGACADIAJAGIAKABIAJgBIAIgGQAEgFABgEQACgEAAgHQAAgGgCgFQgBgFgEgEIgIgGIgJgBgA2lgeQgFgBgGgGQgFgFgCgGQgDgHAAgIQAAgJADgGQADgHAEgEQAEgEAHgDQAJgDAFAAQAGAAAIADQAHADAEAEQADADAEAIQADAHAAAIQAAAIgDAHIgHALQgGAGgFABQgFADgJAAQgIAAgGgDgA2hhZIgIAGIgFAJQgBADAAAIQAAAIABADQACAGADADIAIAGIAKABIAKgBIAIgGQAEgFABgEQACgEAAgHQAAgGgCgFQgCgFgDgEIgIgGIgKgBgAWZgcIAAgjIABgCIgBABIgBACIgBABIgWAfIgCACIgCAAIgFAAIAAgyIAJAAIAAAmIAZgjIABgBIACgCIAGAAIAAAygAUZgcIAAgGIAXgXIAJgLIADgFIAAgGIAAgFIgDgEQAAAAgBgBQAAAAAAAAQgBgBAAAAQgBAAgBAAIgFgBIgFABQAAAAgBAAQAAAAgBABQAAAAAAAAQgBABAAAAIgDADIgCAEQAAABAAAAQAAABAAAAQAAAAgBAAQAAAAAAAAIgDABIgFgBIACgJIAGgGIAHgEIAIgBIAIABQAFACACADQADACACAEIABAHIgBAIIgDAHQgDAEgCABIgYAYIAJgBIAWAAIADABIAAACIAAAGgATrgcIAAglIAAABIgBACIgCABIgWAfIgBACIgCAAIgFAAIAAgyIAJAAIAAAjIgBADIACgEIACgBIACgDIATgbIACgBIACgCIAFAAIAAAygASzgcIAAglIgBABIgBACIgBABIgWAfIgBACIgCAAIgGAAIAAgyIAJAAIAAAmIACgEIABgBIAWgeIABgBIACgCIAGAAIAAAygASCgcIgDAAIgDgDIgJgPIgDgDIgDgBIgGAAIAAAWIgJAAIAAgyIAJAAIAAAWIAFAAIAEgBIACgCIAKgQIACgBIACgCIAIAAIgPAXIgEABIAEACIADAEIANAUgAQYgcIAAgXIgXAAIAAAXIgJAAIAAgyIAJAAIAAAUIAXAAIAAgUIAJAAIAAAygAPhgcIAAgjIABgCIgCABIAAACIgCABIgCAFIgEAEIgPAWIgCACIgCAAIgFAAIAAgyIAJAAIAAAmIABgEIABgBIAXgeIABgBIACgCIAFAAIAAAygAL9gcIAAhHIAVAAQAHABAEACQAGABADADIAFAHIABAJIgBAJIgGAHQgDADgFACQgEABgHAAIgLAAIAAAagAMHg+IASgBIAFgDQACgBABgEIABgFIgBgGIgDgFIgFgCIgSgBgAG+gcIAAg+IgiAAIAAA+IgLAAIAAhHIA4AAIAABHgAD/gcIAAgyIATAAIAHACIAGACIADADIABAGIgBADIgBADIgDAEIgFAAQAHACACADQADACAAAFIgBAHQgBADgDACIgGADIgIAAgAEIgiIAKAAQAEAAAEgDQADgCAAgEIgBgDIgBgCIgEgBIgFgBIgKAAgAEIg4IAKAAIADgBIADgBQAAgBABAAQAAAAAAAAQABgBAAAAQAAgBAAgBIABgCIAAgDIgCgCIgDgCIgEAAIgKAAgADxgcIgEAAIgDgDIgJgPIgCgDIgKgBIAAAWIgJAAIAAgyIAJAAIAAAWIAFAAIADgBIADgCIAKgQIACgBIADgCIAHAAIgPAXIgEABIAFACIACAEIANAUgABPgcIAAg1IAAgCIgZAtIgCABIgBAAQgBAAgBgBQAAAAgBAAQAAgBAAAAQgBgBAAAAIgYgrIAAA3IgJAAIAAhHIAIAAIADADIAaAwIABgEIAZgsIABgCIACgBIAIAAIAABHgAhGgcIAAgyIAgAAIAAAHIgXAAIAAArgAiogcIAZghIgGADIgHACIgHgCIgHgEIgEgGIgBgIIABgJIAFgHIAIgFQAEgCAFAAQAFAAAEACQAFACACADIAFAHQABADAAAGIAAAFIgEALIgUAeIgCACIgDAAgAiehaIgEADQgBABAAAAQgBABAAAAQAAABgBAAQAAABAAAAIgBAFQAAAHADAEQAEADAGAAIAGgBQABAAABgBQABAAAAAAQABAAAAgBQAAAAAAAAIADgFIACgGIgCgFIgDgEIgEgDIgFgBgAjhgcIAAgHIAPAAIAAgyIgMAJIgCABIgCAAIAAgBIgDgEIAVgTIAHAAIAABAIAOAAIAAAHgAkCgcIAAgSIgfAAIgCAAIgBgCIgBgFIAiguIAJAAIAAAtIAKAAIAAAGIAAACIgCAAIgIAAIAAASgAkbg2IAZAAIAAgeIAAgDgAmLgcIAAgHIAPAAIAAgyIgNAJIgBABIgCAAIgBgBIgDgEIAVgTIAIAAIAABAIANAAIAAAHgAnEgcIAAgHIAPAAIAAgyIgMAJIgCABIgCAAIAAgBIgDgEIAVgTIAHAAIAABAIAOAAIAAAHgApNgcIAAhHIArAAIAAAJIggAAIAAA+gAp/gcIAAggIglAAIAAAgIgLAAIAAhHIALAAIAAAgIAlAAIAAggIAKAAIAABHgAs7gcIAAg7IgBAFIgkA1IgDABIgIAAIAAhHIALAAIgBA8IACgFIAigzIACgCIACgCIAIAAIAABHgAvTgcIAAggIglAAIAAAgIgLAAIAAhHIALAAIAAAgIAlAAIAAggIAJAAIAABHgAwTgcQAAABgBgBQAAAAgBAAQAAAAAAAAQAAAAAAAAIgBgCIgHgQIgfAAIgGAQIgCACIgCAAIgIAAIAchHIALAAIAcBHgAwthUIgCADIgKAaIAZAAIgNgigAxXgcIgDAAIgCgDIgSgZIgDgDIgEgBIgIAAIAAAgIgKAAIAAhHIAKAAIAAAgIAKAAIACgCIAUgbIACgCIACgBIAJAAIgVAdQgCAEgEABIAEACIAZAjgAn9gkIgCgBIABgCIAIgNIABgCIgBgBIAAAAIgIgNIgBgDIACgBIADgBIAMASIAAABIgMAUgAoMgkIgBgBIAAgCIAJgPIgBgBIgIgNIAAgDIABgBIAEgBIALASIAAABIgLAUgAymg2IAAgBIAMgSIADABIABABIAAADIgJAOIABACIAIANIAAACIgBABIgDACgAy1g2IAAgBIAMgSIADABIACABIgBADIgJAOIABACIAIANIABACIgCABIgDACgAVTg2IAAgIIAYAAIAAAIgAWIhVIgFgDIgDgDIgBgFIACgDIAGAAIAAAFIABADIACABIAHAAIADgBIABgIIAGAAIACADIgCAFIgDADIgEADIgGABgATZhVIgEgDIgDgDIgBgFIAAgBIACgCIAFAAIAAAFIACADIACABIAHAAIACgBIABgDIAAgFIAGAAIABACIABABIgBAFQAAABAAAAQgBABAAAAQAAAAgBAAQgBABAAAAIgEADIgHABg");
	this.shape_1.setTransform(160.075,461.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("ApGBTQgqgmAYg4QAWgzBGgdQBOghB9ABQAcAAAaADIAgAEIANADIgSAgQgogLggAAQhAAAg0ATQhHAZgKAyQgHAeAWAaQAcAiA9gDQATgBAlgMQAtgPAbgVIA/g3IANgIQAIgDAKgBIBEAAIAWBeIArhcIBLAAIArBHIAghHIBFAAIg8CDIhHAAIgthMIgiBMIgrAAIAAAAIhSAAIgDgXIhKAAIgZAWIgwAAQg4AUhKAAQhqAAgugqgAjHA4IArgBIgDglgAGHB1IAsgrIgshjIBEAAIASA0IA4g2IBNAAIiFCFQgHAHgFACIgQACgAD+BqIhvAAIA9iDIBvAAQA1AAAUAYQAQAVgMAaQgLAYgdAQQglAUg6AAIgDAAgADpBIIATAAQAXABARgGQAdgIAFgWQAIgeg0gBIgUAAg");
	this.shape_2.setTransform(160.0795,43.234,1.3333,1.3333);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(219));

	// bg
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape_3.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(219));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(159.5,239.5,161,241);
// library properties:
lib.properties = {
	id: '9C9328AEEA6A9941B02EC00BA392E8FF',
	width: 320,
	height: 480,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/320x480_atlas_.jpg", id:"320x480_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['9C9328AEEA6A9941B02EC00BA392E8FF'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
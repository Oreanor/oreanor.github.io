(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"970x250_atlas_", frames: [[600,0,298,274],[300,0,298,274],[0,276,300,250],[0,0,298,274]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["970x250_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["970x250_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["970x250_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["970x250_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.uznat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgwBaIAAi0IBhAAIAAAhIg/AAIAAAqIA8AAIAAAfIg8AAIAAAqIA/AAIAAAgg");
	this.shape.setTransform(67.925,1.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBaIAAi0IBgAAIAAAhIg/AAIAAAqIA8AAIAAAfIg8AAIAAAqIA/AAIAAAgg");
	this.shape_1.setTransform(55.2,1.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhBaIAAhLIhBAAIAABLIghAAIAAi0IAhAAIAABJIBBAAIAAhJIAhAAIAAC0g");
	this.shape_2.setTransform(40.35,1.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag8BaIAAi0IBpAAIAAAhIhIAAIAAAlIAcAAQAlAAAPAYQAIANAAASQAAAZgQAPQgRAPgbAAgAgbA6IAdAAQAMAAAIgHQAGgHAAgJQAAgJgFgFQgHgJgOAAIgdAAg");
	this.shape_3.setTransform(25.125,1.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhDBDQgbgbAAgoQAAgmAbgbQAcgcAnAAQAoAAAcAcQAbAbAAAmQAAAogbAbQgcAbgoAAQgnAAgcgbgAgrgrQgSASAAAZQAAAZASATQASASAZAAQAaAAASgTQASgSAAgZQAAgZgSgSQgRgSgbAAQgZAAgSASg");
	this.shape_4.setTransform(7.075,1.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag5BaIAAi0IAzAAQAlAAAQAXQALAOAAAUQAAAWgNAOQgRATgiAAIgRAAIAABEgAgXgKIAUAAQAbAAAAgXQAAgYgbAAIgUAAg");
	this.shape_5.setTransform(-9.475,1.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABCBsIAAgjIiCAAIAAAjIgiAAIAAhDIARAAIBEiUIAcAAIBDCUIARAAIAABDgAgsApIBZAAIgthlg");
	this.shape_6.setTransform(-26.95,2.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhDBDQgbgbgBgoQABgmAbgbQAcgcAnAAQAoAAAcAcQAbAbAAAmQAAAogbAbQgcAbgoAAQgoAAgbgbgAgrgrQgSASAAAZQAAAZASATQASASAZAAQAaAAATgTQARgSAAgZQAAgZgRgSQgTgSgaAAQgaAAgRASg");
	this.shape_7.setTransform(-47.25,1.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAhBaIAAiTIhBAAIAACTIghAAIAAi0ICEAAIAAC0g");
	this.shape_8.setTransform(-65.85,1.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AvPD9IAAn5IefAAIAAH5g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.uznat, new cjs.Rectangle(-97.6,-25.2,195.2,50.5), null);


(lib.t5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AgPBZIAAgfIAfAAIAAAfgAgPAsIAAiEIAfAAIAACEg");
	this.shape.setTransform(236.194,39.0999,0.9749,0.9749);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAtAAIAwCHIAxiHIAtAAIAACxg");
	this.shape_1.setTransform(222.1801,39.0999,0.9749,0.9749);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AgvBZIAAixIBeAAIAAAgIg9AAIAAApIA7AAIAAAfIg7AAIAAApIA9AAIAAAgg");
	this.shape_2.setTransform(205.4852,39.0999,0.9749,0.9749);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAoBZIAAh8IhPB8IghAAIAAixIAhAAIAAB8IBPh8IAhAAIAACxg");
	this.shape_3.setTransform(190.5695,39.0999,0.9749,0.9749);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQATAAAPAGQAbAMAAAdQAAAXgUALQAPAFAHAKQAJAMgBAPQABA2hGAAgAgYA5IAVAAQAcAAAAgWQAAgXgcAAIgVAAgAgYgTIAPAAQAXAAAAgTQAAgSgXAAIgPAAg");
	this.shape_4.setTransform(175.5562,39.0999,0.9749,0.9749);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIggAAIAACRg");
	this.shape_5.setTransform(163.4433,39.0999,0.9749,0.9749);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAageArgBQAcABAVAOQAXAOAKAZIglAAQgRgVgbgBQgaAAgRASQgRASAAAYQAAAZARARQASASAZABQAbAAAQgVIAlAAQgLAYgVAOQgVAOgdAAQgqABgaggg");
	this.shape_6.setTransform(149.5268,39.1731,0.9749,0.9749);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAfAAAPARQANANAAAXQAAAZgQAPQgRAPgaAAgAgZA5IAZAAQANAAAGgGQAHgGAAgLQAAgKgHgGQgGgGgNAAIgZAAg");
	this.shape_7.setTransform(134.0262,39.0999,0.9749,0.9749);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAxBZIgxiDIgvCDIglAAIBHixIAcAAIBGCxg");
	this.shape_8.setTransform(118.2574,39.0999,0.9749,0.9749);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AhCBBQgbgaAAgnQAAgmAbgbQAbgbAnAAQAnAAAcAbQAbAbAAAmQAAAngbAaQgcAbgnAAQgmAAgcgbgAgqgqQgSASAAAYQAAAZASASQARASAZAAQAaAAARgSQASgTAAgYQAAgYgSgSQgRgSgaAAQgZAAgRASg");
	this.shape_9.setTransform(100.0271,39.1731,0.9749,0.9749);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAXgTALQANAFAIAKQAJAMAAAPQAAAXgPAOQgSARglAAgAgXA5IAVAAQAbAAAAgWQAAgXgbAAIgVAAgAgXgTIAPAAQAWAAAAgTQAAgSgWAAIgPAAg");
	this.shape_10.setTransform(83.8196,39.0999,0.9749,0.9749);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgbQAbgaAnAAQAoAAAbAaQAbAbAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSASAAAYQAAAZASASQARARAZAAQAaAAASgRQARgSAAgZQAAgZgSgRQgRgSgaABQgZAAgRARg");
	this.shape_11.setTransform(66.7836,39.1731,0.9749,0.9749);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAcAAIBBCRIARAAIAABCgAgrAoIBXAAIgshjg");
	this.shape_12.setTransform(47.359,40.7572,0.9749,0.9749);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AghBZIAVgtIhFiEIAoAAIAuBeIApheIAkAAIhRCxg");
	this.shape_13.setTransform(33.1744,39.0999,0.9749,0.9749);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAbgeAqAAQAcAAAWAOQAWAOALAaIgmAAQgRgWgcgBQgZABgRARQgRASAAAYQAAAZASASQARARAZABQAbAAAPgVIAnAAQgMAYgUAOQgWAOgcAAQgqAAgbgfg");
	this.shape_14.setTransform(10.5327,39.1731,0.9749,0.9749);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAzBZIgSguIhBAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_15.setTransform(206.6794,9.8534,0.9749,0.9749);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAsAAIAxCHIAxiHIAtAAIAACxg");
	this.shape_16.setTransform(187.2548,9.8534,0.9749,0.9749);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgnQAAgmAbgbQAcgaAmAAQAoAAAbAaQAbAbAAAmQAAAngbAbQgbAbgoAAQgmAAgcgbgAgqgqQgSARAAAZQAAAZASASQARARAZAAQAaAAASgRQARgTAAgYQAAgZgSgRQgRgRgagBQgZABgRARg");
	this.shape_17.setTransform(166.6604,9.9265,0.9749,0.9749);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAbAAIBCCRIARAAIAABCgAgqAoIBWAAIgshjg");
	this.shape_18.setTransform(147.2359,11.5107,0.9749,0.9749);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AgvBZIAAixIBfAAIAAAgIg+AAIAAApIA7AAIAAAfIg7AAIAAApIA+AAIAAAgg");
	this.shape_19.setTransform(126.2515,9.8534,0.9749,0.9749);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_20.setTransform(115.1378,9.8534,0.9749,0.9749);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAeAAAQARQANAOAAAWQAAAZgRAPQgQAPgaAAgAgZA5IAZAAQAMAAAHgGQAHgGAAgLQAAgKgHgGQgHgGgMAAIgZAAg");
	this.shape_21.setTransform(104.5847,9.8534,0.9749,0.9749);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAYgUAKQAPAFAIAKQAIAMAAAPQAAA2hGAAgAgYA5IAWAAQAbAAAAgWQAAgXgbAAIgWAAgAgYgTIAQAAQAWAAAAgTQAAgSgWAAIgQAAg");
	this.shape_22.setTransform(90.8632,9.8534,0.9749,0.9749);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AhBBCQgcgbABgmQgBgnAcgbQAagaAnAAQAoAAAaAaQAcAbAAAnQAAAmgcAbQgbAagnABQgngBgagagAgrgqQgRASABAYQgBAZASARQARASAZAAQAaAAARgSQARgSAAgYQAAgZgRgRQgRgSgaAAQgZAAgSASg");
	this.shape_23.setTransform(73.8271,9.9265,0.9749,0.9749);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_24.setTransform(59.6669,9.8534,0.9749,0.9749);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgaQAbgcAnABQAogBAbAcQAbAaAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSARAAAZQAAAZASARQARATAZAAQAaAAASgTQARgRAAgZQAAgZgSgRQgRgSgaABQgZgBgRASg");
	this.shape_25.setTransform(45.5311,9.9265,0.9749,0.9749);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00A7E0").s().p("AgrBZIAAixIBXAAIAAAgIg2AAIAACRg");
	this.shape_26.setTransform(31.3465,9.8534,0.9749,0.9749);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t5, new cjs.Rectangle(2,0.9,235.8,50.2), null);


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AoTDgQgVgNgNgUQgMgVAAgaQAAgaAMgVQANgVAVgMQAVgNAbAAQAaAAAVANQAVAMANAVQAMAVAAAaQAAAagMAVQgNAUgVANQgVAMgaAAQgbAAgVgMgAoDBbQgNAIgIAOQgIANAAARQAAARAIAOQAIAOANAIQAOAIARAAQASAAAOgIQAOgJAHgNQAIgOAAgRQAAgRgIgNQgIgOgNgIQgOgIgRAAQgSAAgOAIgAKlDoIgSguIhCAAIgSAuIgkAAIBKiyIAaAAIBKCygAKGCaIgUg0IgUA0IAoAAgAHhDoIAAiSIghAAIAAggIBjAAIAAAgIghAAIAACSgAGSDoIg3hOIAABOIghAAIAAiyIAhAAIAABNIA3hNIAoAAIhDBYIBDBagAC+DoIAAiyIBfAAIAAAgIg/AAIAAApIA8AAIAAAgIg8AAIAAApIA/AAIAAAggACHDoIgwiEIgxCEIgkAAIBGiyIAdAAIBGCygAgwDoIAAiSIhBAAIAACSIggAAIAAiyICCAAIAACygAjTDoIAAiFIgvCFIgcAAIgwiFIAACFIggAAIAAiyIAsAAIAyCIIAxiIIAtAAIAACygAplDoIg4hOIAABOIggAAIAAiyIAgAAIAABNIA4hNIAnAAIhDBYIBDBagAhOg+QgVgNgNgUQgMgVAAgaQAAgaAMgVQANgVAVgMQAVgNAbAAQAaAAAUANQAVAMANAVQAMAVAAAaQAAAagMAVQgNAUgVANQgUAMgaAAQgbAAgVgMgAg+jDQgNAIgIAOQgIANAAARQAAARAIAOQAIAOANAIQAOAIARAAQASAAANgIQAOgJAHgNQAIgOAAgRQAAgRgIgNQgIgOgNgIQgNgIgRAAQgSAAgOAIgALLg2IAAiyIBfAAIAAAgIg/AAIAAApIA8AAIAAAgIg8AAIAAApIA/AAIAAAggAKOg2Ig4hOIAABOIggAAIAAiyIAgAAIAABNIA4hNIAnAAIhDBYIBDBagAH0g2IAAiSIhBAAIAACSIggAAIAAiyICCAAIAACygAEMg2IAVgtIhFiFIAoAAIAvBfIAphfIAkAAIhQCygACug2Ig4hOIAABOIggAAIAAiyIAgAAIAABNIA4hNIAnAAIhDBYIBDBagAi0g2IAAiSIhBAAIAACSIghAAIAAiyICDAAIAACygAmPg2IAAh9IhQB9IggAAIAAiyIAgAAIAAB9IBQh9IAhAAIAACygAqGg2IAAiyIAyAAQAVAAANAGQAMAGAHAKQAGAJACAJQACAJAAAHQAAAIgCAKQgDAJgHAIQgHAJgNAFQgMAFgTAAIgRAAIAABEgApliZIATAAIAMgCQAGgBAFgFQAFgFAAgLQAAgKgFgGQgFgEgGgCIgMgBIgTAAgArHg2IAAiSIhBAAIAACSIghAAIAAiyICDAAIAACyg");
	this.shape.setTransform(98.725,39.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(17.8,15.7,161.89999999999998,47.3), null);


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AgVDgQgVgNgNgUQgMgVAAgaQAAgaAMgVQANgVAVgMQAVgNAaAAQAaAAAVANQAVAMANAVQAMAVAAAaQAAAagMAVQgNAUgVANQgVAMgaAAQgaAAgVgMgAgFBbQgNAIgIAOQgIANAAARQAAARAIAOQAIAOANAIQANAIARAAQASAAAOgIQAOgJAHgNQAIgOAAgRQAAgRgIgNQgIgOgNgIQgOgIgRAAQgSAAgNAIgAlwDjQgRgIgMgOQgLgOgGgQQgGgQAAgQQAAgPAGgQQAGgQALgOQAMgOARgIQASgJAXAAQATAAAQAGQAQAHAMAMQAMAMAIARIgmAAQgEgGgHgFQgGgFgIgDQgJgDgKAAQgSAAgOAIQgNAJgIANQgIAOAAAQQAAARAIAOQAIANAOAJQAOAIARAAQAMAAALgFQALgFAJgKIAmAAQgIAPgLAMQgMAMgQAGQgQAHgTAAQgXAAgSgJgAIaDoIAAhFIgBAAIgvBFIgnAAIAxhCQgOgCgKgGQgLgHgGgMQgHgLAAgQQAAgHACgJQADgKAGgJQAHgKANgGQAOgHAWAAIAzAAIAACygAHyBaQgHAEgDAGQgDAGAAAGQAAAHADAGQADAGAHAEQAHAEANAAIAUAAIAAg1IgUAAQgNAAgHAEgAGKDoIAAh9IhQB9IggAAIAAiyIAgAAIAAB9IBQh9IAhAAIAACygACPDoIAAiyIAqAAIALAAIAQADQAIACAIAFQAIAFAGAJQAFAJAAAOQAAALgEAHQgEAHgEAEIgHAFQAOAFAIALQAIAMAAAPQAAANgGAMQgGAMgPAIQgQAIgcABgACvDIIAWAAIAGAAQAEgBAFgCQAFgCAEgFQAEgEAAgJQAAgDgCgGQgBgFgGgEQgHgEgMgBIgWAAgACvB7IAQAAQAKgBAFgDQAFgEACgEIABgHQAAgIgEgEQgFgEgFgBIgJgBIgQAAgAhpDoIgwiEIgxCEIgkAAIBGiyIAdAAIBGCygAoSDoIAVgtIhEiFIAoAAIAvBfIAphfIAkAAIhRCygAkfgVIAAghIh1AAIAAiyIAgAAIAACSIBBAAIAAiSIAhAAIAACSIAUAAIAABBgAtEg7QgSgIgLgOQgMgOgFgQQgGgQAAgQQAAgPAGgQQAFgQAMgOQALgOASgIQARgJAYAAQASAAAQAGQAQAHAMAMQANAMAHARIglAAQgFgGgGgFQgHgFgIgDQgIgDgLAAQgSAAgNAIQgOAJgHANQgIAOAAAQQAAARAIAOQAIANANAJQAOAIARAAQAMAAAMgFQALgFAIgKIAmAAQgHAPgMAMQgMAMgPAGQgQAHgUAAQgXAAgRgJgAMag2IAAiyIBfAAIAAAgIg+AAIAAApIA8AAIAAAgIg8AAIAAApIA+AAIAAAggALZg2IAAiyIAhAAIAACygAJRg2IAAiyIAgAAIAABFIAbAAQAWAAANAIQANAIAFAMQAGANAAANQAAARgIAMQgHAMgOAHQgNAHgRAAgAJxhWIAbAAQAMAAAHgGQAHgGAAgLQAAgLgHgGQgHgFgMgBIgbAAgAIPg2IAAhLIhBAAIAABLIggAAIAAiyIAgAAIAABHIBBAAIAAhHIAhAAIAACygAEjg2IAAiyIAgAAIAABFIAbAAQAWAAANAIQANAIAFAMQAGANAAANQAAARgIAMQgHAMgOAHQgNAHgRAAgAFDhWIAbAAQAMAAAHgGQAHgGAAgLQAAgLgHgGQgHgFgMgBIgbAAgADsg2IgwiEIgxCEIgkAAIBGiyIAdAAIBGCygAA/g2IgSguIhAAAIgSAuIglAAIBKiyIAaAAIBKCygAAhiEIgUg0IgUA0IAoAAgAh8g2IAAh9IhQB9IggAAIAAiyIAgAAIAAB9IBQh9IAhAAIAACygAoRg2IAAiyIBfAAIAAAgIg+AAIAAApIA8AAIAAAgIg8AAIAAApIA+AAIAAAggApSg2IAAiSIhBAAIAACSIghAAIAAiyICDAAIAACyg");
	this.shape.setTransform(106.125,25.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(17.2,1.8,177.9,47.2), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AAzBZIgSguIhBAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape.setTransform(233.675,39.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AAYBZIg2hOIAABOIghAAIAAixIAhAAIAABNIA2hNIAoAAIhCBYIBCBZg");
	this.shape_1.setTransform(217.925,39.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AAoBZIAAh8IhPB8IggAAIAAixIAgAAIAAB8IBPh8IAgAAIAACxg");
	this.shape_2.setTransform(201.025,39.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAgBZIAAhLIg/AAIAABLIghAAIAAixIAhAAIAABIIA/AAIAAhIIAhAAIAACxg");
	this.shape_3.setTransform(183.975,39.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("AArBZIgrg+IgpA+IgmAAIA9hZIg9hYIAmAAIApA+IArg+IAmAAIg9BYIA9BZg");
	this.shape_4.setTransform(167.65,39.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgvBZIAAixIBfAAIAAAgIg9AAIAAApIA6AAIAAAfIg6AAIAAApIA9AAIAAAgg");
	this.shape_5.setTransform(153.4,39.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIggAAIAACRg");
	this.shape_6.setTransform(141.975,39.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("AAbBZIAAhFIgBAAIguBFIgnAAIAxhCQgVgCgNgOQgNgOAAgXQAAgVALgOQAQgXAmAAIA0AAIAACxgAgYgdQAAAaAfAAIAUAAIAAg1IgUAAQgfAAAAAbg");
	this.shape_7.setTransform(123.725,39.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_8.setTransform(108.05,39.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AAgBZIAAhLIhAAAIAABLIggAAIAAixIAgAAIAABIIBAAAIAAhIIAhAAIAACxg");
	this.shape_9.setTransform(91.025,39.175);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("AAgBZIAAhLIg/AAIAABLIghAAIAAixIAhAAIAABIIA/AAIAAhIIAhAAIAACxg");
	this.shape_10.setTransform(74.675,39.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AhCBBQgbgaABgnQgBgmAbgaQAcgbAmAAQAnAAAcAbQAbAaAAAmQAAAngbAaQgbAbgoAAQgmAAgcgbgAgrgqQgRARAAAZQAAAZARASQASASAZAAQAaAAARgSQARgTAAgYQABgZgSgRQgRgSgaAAQgZAAgSASg");
	this.shape_11.setTransform(56.45,39.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("AAqBZIgqg+IgpA+IgmAAIA8hZIg8hYIAmAAIApA+IAqg+IAmAAIg9BYIA9BZg");
	this.shape_12.setTransform(38.2,39.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AgiBZIAVgtIhEiEIAoAAIAuBeIApheIAkAAIhRCxg");
	this.shape_13.setTransform(21.625,39.175);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AAYBZIg2hOIAABOIghAAIAAixIAhAAIAABNIA2hNIAnAAIhBBYIBBBZg");
	this.shape_14.setTransform(6.35,39.175);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAaBZIAAhFIAAAAIguBFIgmAAIAwhCQgVgCgNgOQgNgOAAgXQgBgVALgOQARgXAmAAIAzAAIAACxgAgZgdQABAaAfAAIATAAIAAg1IgTAAQgfAAgBAbg");
	this.shape_15.setTransform(201.8,9.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_16.setTransform(186.1,9.175);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AAZBZIg3hOIAABOIghAAIAAixIAhAAIAABNIA3hNIAnAAIhCBYIBCBZg");
	this.shape_17.setTransform(170.325,9.175);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAghAXgbQAaggArAAQAcAAAVAPQAXAOALAZIgmAAQgQgVgcgBQgZABgSARQgRASAAAYQAAAYASASQARATAZgBQAbAAAPgUIAnAAQgMAYgUAOQgWAPgcAAQgrgBgagfg");
	this.shape_18.setTransform(153.1,9.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AAgBZIAAhLIhAAAIAABLIggAAIAAixIAgAAIAABIIBAAAIAAhIIAhAAIAACxg");
	this.shape_19.setTransform(135.45,9.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AAbBZIAAhFIgBAAIguBFIgnAAIAxhCQgVgCgNgOQgOgOABgXQAAgVALgOQAQgXAmAAIA0AAIAACxgAgZgdQAAAaAhAAIATAAIAAg1IgTAAQghAAAAAbg");
	this.shape_20.setTransform(119.7,9.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAfAAAPARQANAOAAAWQAAAZgRAPQgQAPgaAAgAgZA5IAZAAQAMAAAHgGQAHgGAAgLQAAgKgHgGQgHgGgMAAIgZAAg");
	this.shape_21.setTransform(106.5,9.175);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("AAwBZIgwiDIgwCDIgkAAIBHixIAbAAIBHCxg");
	this.shape_22.setTransform(90.325,9.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_23.setTransform(72.8,9.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_24.setTransform(59.925,9.175);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AAnBZIAAh8IhOB8IghAAIAAixIAhAAIAAB8IBOh8IAhAAIAACxg");
	this.shape_25.setTransform(46,9.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(0,0,242.4,48.5), null);


(lib.p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._5();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p5, new cjs.Rectangle(-149,-145,298,274), null);


(lib.p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._3();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p3, new cjs.Rectangle(-149,-145,300,250), null);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._2();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2, new cjs.Rectangle(-149,-145,298,274), null);


(lib.p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1, new cjs.Rectangle(-149,-145,298,274), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AqTBeQgvgrAbhAQAag5BOghQBYglCOAAQAgAAAcAEIAlAFIAPADIgUAkQgsgMgmAAQhIAAg7AVQhQAcgMA5QgHAiAYAeQAgAnBFgEQAWgBAqgOQAzgRAdgYIBIg/QAHgFAHgEQAGgCAIgBIAHAAIBNAAIAZBqIAwhpIBVAAIAxBRIAlhRIBOAAIhFCUIhQAAIgzhWIgmBWIgxAAIAAABIhcAAIgEgbIhUAAIgcAZIg3AAQg/AXhUAAQh4AAg0gvgAjhA/IAxgBIgEgpgAG6CFIAygxIgyhxIBNAAIAVA8IA/g9IBXAAIibCaQgFAFgEABQgFACgNABgAEgB3Ih+AAIBEiUIB+AAQA9AAAWAcQASAXgOAeQgNAbggASQgpAWhCAAIgDAAgAEHBSIAWAAQAaAAAUgGQAggKAGgYQAGgUgUgJQgOgGgWAAIgXAAg");
	this.shape.setTransform(0.0208,-5.0003);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-68.9,-19.1,137.9,28.200000000000003), null);


(lib.legal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("ACxBSQgFgFgBgIIAIgBQABAHAEACQADADAEAAQAGAAAEgDQADgEAAgGQAAgFgDgDQgEgEgFAAIgGABIABgHIABAAQAGAAADgCQAEgDABgGQAAgDgEgDQgDgDgEAAQgEAAgDADQgDADgCAFIgHgBQACgIAEgEQAGgFAHAAQAFAAAFADQAEACACAEQADAEAAAEQAAAEgDADQgCADgEADQAFABAEAEQADAEAAAGQAAAIgHAGQgFAGgKAAQgIAAgGgFgACBBSQgGgFAAgIIAHAAQABAGADACQAEADAEAAQAHAAADgEQAEgEAAgHQAAgHgEgEQgDgDgHAAQgEAAgDACQgDABgBADIgIgBIAHggIAfAAIAAAHIgaAAIgDARQAHgEAFAAQAJAAAFAFQAGAGAAAJQAAAJgFAGQgGAIgLAAQgIAAgFgFgAAfBQQgHgHAAgSQAAgMACgGQADgHAEgEQAEgEAIAAQAFAAADADQAFABACAEIAEAKIABAPQAAALgCAHQgCAGgEAEQgFAEgHAAQgKAAgEgHgAAkAhQgEAGAAAQQAAAPAEAFQADAFAGAAQAFAAADgFQAFgFAAgPQAAgQgFgFQgDgFgFAAQgGAAgDAEgAhCBQQgHgHAAgSQABgMACgGQACgHAEgEQAFgEAHAAQAFAAAEADQADABADAEIAEAKQABAFABAKQgBALgCAHQgCAGgEAEQgFAEgHAAQgKAAgEgHgAg9AhQgDAGgBAQQABAPADAFQAEAFAFAAQAFAAAEgFQADgFABgPQgBgQgDgFQgEgFgFAAQgFAAgEAEgAh0BQQgGgHAAgRQAAgSAGgIQAHgIAJAAQAJAAAEAFQAEAEACAHIgIABQgBgFgCgCQgDgDgFAAIgHACQgDACgCAFQgCAGAAAJQACgEAEgCIAJgCQAIAAAGAGQAFAFAAAJQAAAGgDAFQgDAFgEADQgFADgFAAQgKAAgGgHgAhtA3QgEAEAAAGIACAIQABADADADQADABAEAAQAFAAADgEQADgDAAgHQAAgHgDgEQgDgDgGAAQgFAAgDADgAikBTQgEgEgBgIIAHgBQABAGADACQACACAEAAQAEAAADgBIAFgEIACgIQACgEgBgFIAAgCQgCAEgFACQgDACgFAAQgIAAgFgFQgFgGgBgJQAAgKAGgFQAGgHAJAAQAFAAAGAEQAEADADAGQADAGAAAMQAAAMgDAHQgDAHgEAEQgGAEgHAAQgHAAgFgEgAieAhQgFAEAAAHQAAAGAFAEQADAEAFAAQAGAAADgEQADgEAAgHQAAgGgDgEQgEgEgFAAQgFAAgDAEgAloBQQgGgHAAgSQAAgMACgGQADgHAEgEQAEgEAIAAQAEAAAEADQAEABADAEQACAEABAGIABAPQAAALgBAHQgDAGgEAEQgFAEgGAAQgKAAgFgHgAliAhQgEAGgBAQQABAPAEAFQADAFAGAAQAFAAADgFQAEgFAAgPQAAgQgEgFQgDgFgFAAQgGAAgDAEgAqXBSQgHgEgEgHQgDgIgBgIQABgPAIgJQAIgKAOAAQAIAAAHAFQAIAEADAHQAEAIAAAJQAAAKgFAHQgDAIgIAEQgHAEgHAAQgJAAgHgFgAqWAjQgHAGAAAOQAAALAHAHQAGAHAIAAQAKAAAGgHQAHgHAAgMQAAgHgEgGQgCgGgFgDQgFgDgGAAQgJAAgGAGgArpBSQgFgFgBgIIAIAAQAAAGAEACQAEADADAAQAHAAADgEQAEgEABgHQgBgHgEgEQgDgDgHAAQgDAAgDACQgDABgCADIgHgBIAGggIAfAAIAAAHIgZAAIgDARQAGgEAGAAQAIAAAGAFQAFAGAAAJQABAJgFAGQgGAIgMAAQgIAAgFgFgAtLBQQgGgHAAgSQAAgMACgGQADgHAEgEQAEgEAHAAQAFAAAEADQAEABADAEIADAKIABAPQAAALgCAHQgCAGgEAEQgEAEgIAAQgJAAgFgHgAtGAhQgDAGAAAQQAAAPADAFQAEAFAFAAQAGAAADgFQAEgFAAgPQAAgQgEgFQgDgFgGAAQgFAAgEAEgAveBSQgGgFAAgIIAIAAQABAGADACQADADAFAAQAGAAAEgEQAEgEgBgHQABgHgEgEQgEgDgGAAQgEAAgDACQgDABgBADIgHgBIAFggIAgAAIAAAHIgaAAIgDARQAGgEAGAAQAJAAAFAFQAGAGAAAJQAAAJgFAGQgGAIgLAAQgIAAgGgFgAxABQQgFgHAAgSQAAgMABgGQADgHAEgEQAFgEAGAAQAFAAAEADQAEABADAEIAEAKIABAPQAAALgCAHQgDAGgEAEQgEAEgIAAQgJAAgFgHgAw6AhQgEAGAAAQQAAAPAEAFQADAFAFAAQAGAAADgFQAEgFAAgPQAAgQgEgFQgDgFgGAAQgFAAgDAEgABiBWIAAgPIgcAAIAAgHIAdgqIAHAAIAAAqIAIAAIAAAHIgIAAIAAAPgABOBAIAUAAIAAgdgAgOBWQAAgIADgKQACgLAGgKQAEgJAGgHIgeAAIAAgHIAoAAIAAAGQgGAGgGALQgGAKgCAMQgDAHAAAKgAjSBWQAAgIADgKQACgLAGgKQAFgJAGgHIgfAAIAAgHIApAAIAAAGQgGAGgGALQgGAKgEAMQgCAHAAAKgAkDBWQAAgIADgKQADgLAFgKQAFgJAGgHIgeAAIAAgHIAoAAIAAAGQgGAGgGALQgGAKgDAMQgCAHgBAKgAkkBWIAAgPIgcAAIAAgHIAdgqIAHAAIAAAqIAIAAIAAAHIgIAAIAAAPgAk4BAIAUAAIAAgdgAmJBWIAAgyIgIAGIgIAEIAAgIQAGgDAFgEQAFgFACgEIAFAAIAABAgAnLBWIAAgeIggAAIAAAeIgIAAIAAhAIAIAAIAAAbIAgAAIAAgbIAJAAIAABAgAovBWIAAhAIAYAAQAGAAAEACQAEAAADACQADADACADQADAEAAAFQAAAIgGAFQgFAGgNAAIgRAAIAAAagAonA1IARAAQAIAAADgEQAEgCAAgGQAAgEgCgCQgCgDgDgBIgIgBIgRAAgApeBWIAAhAIAoAAIAAAIIggAAIAAA4gAsKBWIAAgyIgIAGIgJAEIAAgIQAHgDAFgEQAFgFACgEIAFAAIAABAgAuDBWIAAgGQACgEAEgEIAKgJQAKgJAEgFQADgFAAgEQAAgFgDgDQgDgDgFAAQgGAAgDADQgDAEgBAGIgHgBQAAgJAFgFQAGgFAJAAQAJAAAFAFQAFAFAAAIIgBAHQgBAEgFAEQgCAEgJAHIgJAIIgDAEIAfAAIAAAIgAueBWIAAgyIgHAGIgIAEIAAgIQAGgDAFgEQAFgFADgEIAEAAIAABAgAv8BWIAAgPIgbAAIAAgHIAcgqIAHAAIAAAqIAIAAIAAAHIgIAAIAAAPgAwQBAIAUAAIAAgdgAxuBWQAAgIAEgKQACgLAGgKQAEgJAHgHIgfAAIAAgHIApAAIAAAGQgHAGgFALQgHAKgDAMQgCAHgBAKgAyeBWQAAgIACgKQADgLAFgKQAFgJAGgHIgeAAIAAgHIAoAAIAAAGQgFAGgHALQgFAKgEAMQgCAHAAAKgAzTBWIAAgeIghAAIAAAeIgJAAIAAhAIAJAAIAAAbIAhAAIAAgbIAIAAIAABAgA0TBWIAAgeIghAAIAAAeIgIAAIAAhAIAIAAIAAAbIAhAAIAAgbIAJAAIAABAgA1RBWIAAgyIgiAyIgJAAIAAhAIAIAAIAAAzIAigzIAIAAIAABAgAFcgEIAAg/IAHAAIAAAGQADgEADgCQADgBAEAAQAHAAADADQAFADACAFQADAGAAAGQAAAHgDAGQgDAFgEADQgFADgGAAQgDAAgDgBQgDgCgCgDIAAAXgAFng5QgEAEAAAJQAAAJAEAEQADAEAFAAQAFAAAEgFQAEgEAAgJQAAgJgEgEQgDgEgGAAQgEAAgEAFgAuOgHIAAgPIgpAAIAAAPIgIAAIAAgWIAFAAQAHgLAAgkIAAgJIAmAAIAAA4IAHAAIAAAWgAurhKIAAAWQgCAOgFAJIAdAAIAAgwIgWAAgAUZgIIAAgOIgkAAIAAAOIgGAAIAAgUIADAAQAJgLAAgcIAfAAIAAAnIAFAAIAAAUgAT6gcIAZAAIAAghIgSAAQgBAWgGALgAMIgIIAAgOIg6AAIAAgtIAIAAIAAAnIASAAIAAgnIAIAAIAAAnIARAAIAAgnIAIAAIAAAnIAFAAIAAAUgAI8gIIAAgOIgkAAIAAAOIgHAAIAAgUIAFAAQAHgLABgcIAfAAIAAAnIAFAAIAAAUgAIdgcIAYAAIAAghIgSAAQAAAWgGALgATFgMQABgBABAAQAAAAABgBQAAAAAAgBQABAAAAgBIABgGIgEAAIAAgIIAIAAIAAAIQABAFgCADQgBADgFACgADugMQADgBABgDIABgGIgEAAIAAgIIAJAAIAAAIQAAAFgCADQgCADgEACgAi+gMQADgBABgDIABgGIgFAAIAAgIIAJAAIAAAIQAAAFgCADQgBADgEACgAVcgaQgHgGAAgIQAAgGADgEQAEgEAFgCQgEgBgCgEQgDgDAAgEQAAgIAFgEQAFgFAIAAQAIAAAGAFQAEAEAAAIQAAAEgCADQgCAEgFABQAGACADAEQADAFAAAFQAAAIgGAGQgFAFgKAAQgJAAgFgFgAVhgxQgDAEgBAFQAAAEACADQACADADABIAGACQAGAAADgDQAFgEAAgGQAAgFgFgEQgDgDgGAAQgFAAgEADgAVjhMQgDADAAAEQAAAEADADQADAEAEAAQAFAAADgEQADgDAAgDQAAgFgDgDQgDgCgFAAQgEAAgDACgAN8gbQgGgGAAgLQAAgIACgFQADgGAFgDQAFgCAFAAQAJAAAEADQAEAEACAHIgIACQAAgFgDgDQgDgCgEAAQgGAAgEAEQgDAEAAAJQAAAKADAEQAEAEAFAAQAFAAADgDQADgDABgFIAIAAQgBAJgFAEQgGAEgIAAQgJAAgFgGgAKggbQgFgGgBgLQABgNAGgGQAHgFAIAAQAJAAAGAGQAGAGAAALQAAAJgCAFQgDAFgFADQgFACgGAAQgJAAgHgGgAKng5QgFAEAAAJQAAAIAFAEQAEAFAFAAQAGAAAEgFQADgEAAgJQAAgIgDgEQgEgFgGAAQgFAAgEAFgAHrgiIAIgCQABAEACADQAEACADAAQAEAAADgCQADgCAAgEQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgFgDQgBgBgFAAIgCABIAAgHIAHAAIADgCQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgDgCgCQgCgCgEAAQgGAAgDAIIgIgBQAEgNANAAQAIAAAEADQAEAFAAAFQAAAGgGADQAEACACADQABADABAEQAAAGgFAEQgEADgJAAQgPAAgDgNgAHBgbQgFgGAAgLQAAgMAFgGQAGgGAKAAQAJAAAGAGQAGAGgBALIAAACIghAAQAAAIADAEQAEAEAGAAQAEAAAEgCQADgDABgEIAIABQgCAHgEAEQgGADgIAAQgKAAgGgGgAHIg6QgDADgBAGIAZAAQAAgGgDgCQgDgFgGAAQgGAAgDAEgAGQgbQgGgGAAgLQAAgNAHgGQAGgFAJAAQAJAAAGAGQAGAGAAALQAAAJgCAFQgEAFgEADQgGACgFAAQgKAAgGgGgAGWg5QgDAEgBAJQABAIADAEQAEAFAGAAQAFAAAFgFQADgEAAgJQAAgIgDgEQgFgFgFAAQgGAAgEAFgAC9gYQgEgEAAgGQAAgDACgDQABgDADgBIAFgDIAHgBIAOgDIAAgBQAAgFgCgCQgDgDgGAAQgGAAgCACQgDACgBAFIgIgBIADgIQAEgDADgCQAFgBAGAAQAFAAAEABQAEABACADIACAFIAAAHIAAAKQAAALABADIACAFIgIAAQgBgCAAgDIgIAFIgJABQgIAAgEgDgADMgpIgHABIgDACIAAAEQAAADABACQADACAFAAQAEAAAEgCQACgBACgEQACgCAAgFIAAgEIgNAEgAA+gbQgGgGAAgLQAAgIADgFQACgGAFgDQAFgCAGAAQAHAAAFADQAFAEABAHIgHACQgBgFgDgDQgDgCgDAAQgGAAgEAEQgEAEAAAJQAAAKAEAEQADAEAGAAQAEAAAEgDQACgDABgFIAIAAQgCAJgFAEQgEAEgIAAQgJAAgGgGgAANgbQgHgGAAgLQAAgNAIgGQAFgFAJAAQAJAAAGAGQAGAGABALQAAAJgDAFQgDAFgFADQgFACgGAAQgKAAgFgGgAASg5QgEAEAAAJQAAAIAEAEQAFAFAFAAQAGAAAEgFQAEgEgBgJQABgIgEgEQgEgFgGAAQgFAAgFAFgAjsgYQgEgFgBgHIAHgBQABAFADADQACACAEAAQAEAAADgCIAFgEIACgHIABgKIAAgBQgCAEgFACQgDACgFAAQgIAAgFgGQgFgFgBgJQAAgKAGgGQAGgGAJAAQAFAAAGADQAEAEADAGQADAGAAALQAAAMgDAIQgDAHgEAEQgGADgHAAQgHAAgFgDgAjnhKQgDAEgBAHQABAGADADQADAEAGAAQAGAAADgEQADgDAAgHQAAgHgDgDQgEgEgFAAQgFAAgEAEgAl/gZQgFgFgBgIIAIgBQABAGADADQADADAEAAQAHAAADgEQAFgEAAgIQAAgGgFgEQgDgEgHAAQgDAAgDACQgDACgCADIgHgBIAGghIAfAAIAAAHIgZAAIgEARQAHgDAGAAQAIAAAFAFQAGAGABAJQgBAJgFAGQgFAHgMAAQgHAAgGgEgAsbgZQgGgEgDgHQgDgJAAgJQAAgJADgIQAEgHAGgEQAIgDAIAAQAKAAAGAEQAGAFADAJIgIABQgCgGgFgEQgEgDgGAAQgHAAgFAEQgFADgCAGQgCAGAAAGQAAAIADAGQABAGAGAEQAEACAHAAQAGAAAFgEQAFgEACgIIAIADQgDAJgGAGQgHAFgKAAQgKAAgHgEgAzngZQgIgEgDgHQgEgIAAgIQABgQAHgJQAJgJAOAAQAIAAAHAEQAHAFAEAHQADAIAAAJQAAAJgEAIQgDAIgIAEQgHADgHAAQgKAAgGgEgAznhIQgGAGgBAOQABALAGAHQAGAGAJAAQAKAAAGgGQAGgHAAgMQAAgIgDgGQgDgFgEgEQgGgDgFAAQgJAAgHAHgA0sgZQgHgEgEgHQgDgIAAgIQAAgQAJgJQAHgJAOAAQAJAAAHAEQAHAFAEAHQADAIAAAJQAAAJgEAIQgDAIgIAEQgHADgIAAQgJAAgHgEgA0rhIQgHAGABAOQgBALAHAHQAGAGAJAAQAJAAAHgGQAGgHAAgMQAAgIgDgGQgDgFgFgEQgFgDgGAAQgJAAgGAHgA1wgZQgHgEgEgHQgDgIAAgIQAAgQAIgJQAJgJANAAQAJAAAGAEQAIAFADAHQAEAIAAAJQAAAJgEAIQgEAIgHAEQgHADgIAAQgJAAgHgEgA1vhIQgHAGAAAOQAAALAHAHQAGAGAIAAQALAAAFgGQAHgHAAgMQgBgIgCgGQgDgFgFgEQgFgDgGAAQgJAAgGAHgAUqgWIAAgIIAIAAIAAAIgASxgWIAAgiIgWAiIgIAAIAAgtIAIAAIAAAiIAWgiIAIAAIAAAtgARCgWIABgFQABgEAEgEQADgEAHgGIAOgNQADgFAAgFQABgEgEgEQgDgCgFAAQgGAAgDADQgEADAAAGIgHgBQAAgJAFgEQAGgFAJAAQAJAAAFAFQAFAFAAAIIgBAHQgBAEgFAEIgLALIgKAIIgCAEIAeAAIAAAHgAQagWIAAgiIgWAiIgIAAIAAgtIAIAAIAAAiIAVgiIAJAAIAAAtgAPpgWIAAgiIgWAiIgIAAIAAgtIAHAAIAAAiIAWgiIAIAAIAAAtgAO+gWIgJgOIgFgFQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIAAAVIgIAAIAAgtIAIAAIAAAUQAEAAABgCQACgBADgHIADgIIAEgCIAFAAIACAAIAAAGIgDAAIgDABQgCABgBAEIgDAHQgBACgDABQAEABAGAIIAIAOgANlgWIAAgUIgVAAIAAAUIgIAAIAAgtIAIAAIAAATIAVAAIAAgTIAIAAIAAAtgAM1gWIAAgiIgWAiIgIAAIAAgtIAIAAIAAAiIAWgiIAHAAIAAAtgAJjgWIAAg/IAYAAIAKABQAFABADACQADACABAEQADAEAAAFQAAAIgGAFQgEAGgOAAIgQAAIAAAZgAJsg3IAQAAQAIAAADgDQAEgDAAgFQAAgEgBgDQgDgDgDgBIgIAAIgQAAgAFHgWIAAg3IghAAIAAA3IgIAAIAAg/IAyAAIAAA/gACNgWIAAgtIARAAIAKABQAEABACADQACADAAAEQAAADgBACQgCADgCACQADABACADQACACAAAFQAAAGgEADQgFADgIAAgACVgcIAJAAIAKgBQACgCAAgEQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgIAAIgJAAgACVgwIAIAAIAHgBIADgCQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABgDgDgCIgJgBIgIAAgACAgWIgJgOIgFgFIgDgCIAAAVIgJAAIAAgtIAJAAIAAAUQACAAACgCQACgBADgHIADgIQABAAAAAAQAAgBABAAQAAAAABAAQAAgBABAAIAFAAIACAAIAAAGIgCAAIgEABIgDAFIgDAHQgBACgEABQAFABAGAIIAHAOgAgKgWIAAg0IgTA0IgHAAIgSg1IAAA1IgIAAIAAg/IANAAIAOAtIAEAKIACgLIAQgsIALAAIAAA/gAhtgWIAAgIIAJAAIAAAIgAiPgWIAAgtIAaAAIAAAGIgSAAIAAAngAkOgWIAAgxIgIAFQgEADgEABIAAgHQAHgDAFgFIAHgIIAFAAIAAA/gAk8gWIAAgOIgbAAIAAgIIAcgpIAHAAIAAApIAIAAIAAAIIgIAAIAAAOgAlPgsIATAAIAAgcgAmhgWIAAgxIgIAFIgIAEIAAgHQAHgDAFgFQAFgEACgEIAFAAIAAA/gAnRgWIAAgxIgIAFQgFADgDABIAAgHQAGgDAFgFQAFgEACgEIAFAAIAAA/gApEgWIAAgIIAJAAIAAAIgAp1gWIAAg/IApAAIAAAIIghAAIAAA3gAqMgWIAAgIIAJAAIAAAIgAqkgWIAAgdIggAAIAAAdIgJAAIAAg/IAJAAIAAAbIAgAAIAAgbIAIAAIAAA/gArkgWIAAgIIAIAAIAAAIgAtSgWIAAgxIgiAxIgJAAIAAg/IAIAAIAAAyIAigyIAIAAIAAA/gAvPgWIAAgdIghAAIAAAdIgIAAIAAg/IAIAAIAAAbIAhAAIAAgbIAJAAIAAA/gAwIgWIgIgTIgaAAIgHATIgJAAIAZg/IAJAAIAZA/gAwhhCIgHATIAWAAIgGgSQgEgIgBgFIgEAMgAxEgWIgKgRIgIgKQgDgCgFAAIAAAdIgIAAIAAg/IAIAAIAAAcQAGAAACgCQADgCAEgJIAEgJQABgCAEgCQADgCADAAIAGABIAAAHIgCAAIgCAAQgEAAgCABIgFAJQgCAIgCACQgCACgEABQAGACAGAJIANAVgAoegZIAMgTIgMgUIAHAAIAOAUIgOATgAougZIAMgTIgMgUIAGAAIAOAUIgOATgAx6gZIgNgTIANgUIAHAAIgMAUIAMATgAyLgZIgNgTIANgUIAHAAIgLAUIALATgARzgoIAAgJIAYAAIAAAJgASehMQgEgDAAgFIAFAAIACAEIAFABIAFgBIACgEIAGAAQAAAFgDADQgEADgFAAQgGAAgDgDgAQHhMQgEgDgBgFIAFAAIADAEIAFABIAFgBQACgCABgCIAFAAQAAAFgEADQgDADgGAAQgFAAgDgDg");
	this.shape.setTransform(149.3,23.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.legal, new cjs.Rectangle(-2,0,292,34.7), null);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bfQMAAAg+fMAu3AAAMAAAA+fg");
	this.shape.setTransform(199.997,125,1.3333,0.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,400,250), null);


(lib.pics = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p5
	this.instance = new lib.p5();
	this.instance.parent = this;
	this.instance.setTransform(10,0.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(225).to({_off:false},0).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).wait(67).to({x:-10,alpha:0},6,cjs.Ease.get(1)).wait(1));

	// p3
	this.instance_1 = new lib.p3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(10,0.7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(150).to({_off:false},0).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(75));

	// p2
	this.instance_2 = new lib.p2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(10,0.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75).to({_off:false},0).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(150));

	// p1
	this.instance_3 = new lib.p1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(10,0.7);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(225));

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bWqMAAAgtTMAu3AAAMAAAAtTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(305));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-159,-145,320,290);


(lib.main = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t5
	this.instance = new lib.t5();
	this.instance.parent = this;
	this.instance.setTransform(-119.65,-55.45,0.99,0.99);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(224).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-133,y:-58.3,alpha:1},5,cjs.Ease.get(1)).wait(70).to({alpha:0},5).wait(1));

	// t3
	this.instance_1 = new lib.t3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-97.1,-39.4,0.99,0.99);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(149).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-107.9,y:-43.8,alpha:1},5,cjs.Ease.get(1)).wait(67).to({scaleX:0.99,scaleY:0.99,x:-97.1,y:-39.4,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(78));

	// t2
	this.instance_2 = new lib.t2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-108.4,-25.75,0.99,0.99);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-120.5,y:-28.65,alpha:1},5,cjs.Ease.get(1)).wait(66).to({scaleX:0.99,scaleY:0.99,x:-108.4,y:-25.75,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(153));

	// t1
	this.instance_3 = new lib.t1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-119.95,-23.95,0.99,0.99);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1.1,scaleY:1.1,x:-133.3,y:-26.65,alpha:1},4,cjs.Ease.get(1)).wait(68).to({scaleX:0.99,scaleY:0.99,x:-119.95,y:-23.95,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(227));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-133.3,-57.3,266.70000000000005,84);


// stage content:
(lib._970x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EhLsgTcMCXZAAAMAAAAm5MiXZAAAg");
	this.shape.setTransform(485,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(305));

	// uznat
	this.uznat = new lib.uznat();
	this.uznat.name = "uznat";
	this.uznat.parent = this;
	this.uznat.setTransform(798.55,192.75,0.9,0.9);
	this.uznat.alpha = 0;
	this.uznat._off = true;

	this.timeline.addTween(cjs.Tween.get(this.uznat).wait(224).to({_off:false},0).to({alpha:1},6).wait(68).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

	// legal
	this.legal = new lib.legal();
	this.legal.name = "legal";
	this.legal.parent = this;
	this.legal.setTransform(-0.7,228.25,1,1,0,0,0,0.3,17.6);

	this.timeline.addTween(cjs.Tween.get(this.legal).wait(305));

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(166.6,126.35,1.3,1.3,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(305));

	// pics
	this.pics = new lib.pics();
	this.pics.name = "pics";
	this.pics.parent = this;
	this.pics.setTransform(480.5,145);

	this.timeline.addTween(cjs.Tween.get(this.pics).wait(305));

	// text
	this.text = new lib.main();
	this.text.name = "text";
	this.text.parent = this;
	this.text.setTransform(800.3,128.05);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(305));

	// bg
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(0,125,2.425,1,0,0,0,0,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(305));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(484.5,124.5,486,165.5);
// library properties:
lib.properties = {
	id: '203284B51D404641B13688055CA644EC',
	width: 970,
	height: 250,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/970x250_atlas_.jpg", id:"970x250_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['203284B51D404641B13688055CA644EC'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
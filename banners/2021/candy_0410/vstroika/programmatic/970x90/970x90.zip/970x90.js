(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"970x90_atlas_NP_", frames: [[0,276,298,274],[300,0,300,250],[300,252,300,250],[0,0,298,274]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["970x90_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["970x90_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["970x90_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._5 = function() {
	this.initialize(ss["970x90_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.uznat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgwBaIAAi0IBhAAIAAAhIg/AAIAAAqIA8AAIAAAfIg8AAIAAAqIA/AAIAAAgg");
	this.shape.setTransform(67.925,1.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgvBaIAAi0IBgAAIAAAhIg/AAIAAAqIA8AAIAAAfIg8AAIAAAqIA/AAIAAAgg");
	this.shape_1.setTransform(55.2,1.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAhBaIAAhLIhBAAIAABLIghAAIAAi0IAhAAIAABJIBBAAIAAhJIAhAAIAAC0g");
	this.shape_2.setTransform(40.35,1.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag8BaIAAi0IBpAAIAAAhIhIAAIAAAlIAcAAQAlAAAPAYQAIANAAASQAAAZgQAPQgRAPgbAAgAgbA6IAdAAQAMAAAIgHQAGgHAAgJQAAgJgFgFQgHgJgOAAIgdAAg");
	this.shape_3.setTransform(25.125,1.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhDBDQgbgbAAgoQAAgmAbgbQAcgcAnAAQAoAAAcAcQAbAbAAAmQAAAogbAbQgcAbgoAAQgnAAgcgbgAgrgrQgSASAAAZQAAAZASATQASASAZAAQAaAAASgTQASgSAAgZQAAgZgSgSQgRgSgbAAQgZAAgSASg");
	this.shape_4.setTransform(7.075,1.325);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag5BaIAAi0IAzAAQAlAAAQAXQALAOAAAUQAAAWgNAOQgRATgiAAIgRAAIAABEgAgXgKIAUAAQAbAAAAgXQAAgYgbAAIgUAAg");
	this.shape_5.setTransform(-9.475,1.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABCBsIAAgjIiCAAIAAAjIgiAAIAAhDIARAAIBEiUIAcAAIBDCUIARAAIAABDgAgsApIBZAAIgthlg");
	this.shape_6.setTransform(-26.95,2.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhDBDQgbgbgBgoQABgmAbgbQAcgcAnAAQAoAAAcAcQAbAbAAAmQAAAogbAbQgcAbgoAAQgoAAgbgbgAgrgrQgSASAAAZQAAAZASATQASASAZAAQAaAAATgTQARgSAAgZQAAgZgRgSQgTgSgaAAQgaAAgRASg");
	this.shape_7.setTransform(-47.25,1.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAhBaIAAiTIhBAAIAACTIghAAIAAi0ICEAAIAAC0g");
	this.shape_8.setTransform(-65.85,1.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AvPD9IAAn5IefAAIAAH5g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.uznat, new cjs.Rectangle(-97.6,-25.2,195.2,50.5), null);


(lib.t5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AgPBZIAAgfIAfAAIAAAfgAgPAsIAAiEIAfAAIAACEg");
	this.shape.setTransform(236.194,39.0999,0.9749,0.9749);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAtAAIAwCHIAxiHIAtAAIAACxg");
	this.shape_1.setTransform(222.1801,39.0999,0.9749,0.9749);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AgvBZIAAixIBeAAIAAAgIg9AAIAAApIA7AAIAAAfIg7AAIAAApIA9AAIAAAgg");
	this.shape_2.setTransform(205.4852,39.0999,0.9749,0.9749);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAoBZIAAh8IhPB8IghAAIAAixIAhAAIAAB8IBPh8IAhAAIAACxg");
	this.shape_3.setTransform(190.5695,39.0999,0.9749,0.9749);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQATAAAPAGQAbAMAAAdQAAAXgUALQAPAFAHAKQAJAMgBAPQABA2hGAAgAgYA5IAVAAQAcAAAAgWQAAgXgcAAIgVAAgAgYgTIAPAAQAXAAAAgTQAAgSgXAAIgPAAg");
	this.shape_4.setTransform(175.5562,39.0999,0.9749,0.9749);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIggAAIAACRg");
	this.shape_5.setTransform(163.4433,39.0999,0.9749,0.9749);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAageArgBQAcABAVAOQAXAOAKAZIglAAQgRgVgbgBQgaAAgRASQgRASAAAYQAAAZARARQASASAZABQAbAAAQgVIAlAAQgLAYgVAOQgVAOgdAAQgqABgaggg");
	this.shape_6.setTransform(149.5268,39.1731,0.9749,0.9749);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAfAAAPARQANANAAAXQAAAZgQAPQgRAPgaAAgAgZA5IAZAAQANAAAGgGQAHgGAAgLQAAgKgHgGQgGgGgNAAIgZAAg");
	this.shape_7.setTransform(134.0262,39.0999,0.9749,0.9749);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAxBZIgxiDIgvCDIglAAIBHixIAcAAIBGCxg");
	this.shape_8.setTransform(118.2574,39.0999,0.9749,0.9749);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AhCBBQgbgaAAgnQAAgmAbgbQAbgbAnAAQAnAAAcAbQAbAbAAAmQAAAngbAaQgcAbgnAAQgmAAgcgbgAgqgqQgSASAAAYQAAAZASASQARASAZAAQAaAAARgSQASgTAAgYQAAgYgSgSQgRgSgaAAQgZAAgRASg");
	this.shape_9.setTransform(100.0271,39.1731,0.9749,0.9749);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAXgTALQANAFAIAKQAJAMAAAPQAAAXgPAOQgSARglAAgAgXA5IAVAAQAbAAAAgWQAAgXgbAAIgVAAgAgXgTIAPAAQAWAAAAgTQAAgSgWAAIgPAAg");
	this.shape_10.setTransform(83.8196,39.0999,0.9749,0.9749);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgbQAbgaAnAAQAoAAAbAaQAbAbAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSASAAAYQAAAZASASQARARAZAAQAaAAASgRQARgSAAgZQAAgZgSgRQgRgSgaABQgZAAgRARg");
	this.shape_11.setTransform(66.7836,39.1731,0.9749,0.9749);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAcAAIBBCRIARAAIAABCgAgrAoIBXAAIgshjg");
	this.shape_12.setTransform(47.359,40.7572,0.9749,0.9749);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AghBZIAVgtIhFiEIAoAAIAuBeIApheIAkAAIhRCxg");
	this.shape_13.setTransform(33.1744,39.0999,0.9749,0.9749);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAgiAXgbQAbgeAqAAQAcAAAWAOQAWAOALAaIgmAAQgRgWgcgBQgZABgRARQgRASAAAYQAAAZASASQARARAZABQAbAAAPgVIAnAAQgMAYgUAOQgWAOgcAAQgqAAgbgfg");
	this.shape_14.setTransform(10.5327,39.1731,0.9749,0.9749);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAzBZIgSguIhBAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_15.setTransform(206.6794,9.8534,0.9749,0.9749);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AA9BZIAAiEIgvCEIgbAAIgviEIAACEIghAAIAAixIAsAAIAxCHIAxiHIAtAAIAACxg");
	this.shape_16.setTransform(187.2548,9.8534,0.9749,0.9749);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgnQAAgmAbgbQAcgaAmAAQAoAAAbAaQAbAbAAAmQAAAngbAbQgbAbgoAAQgmAAgcgbgAgqgqQgSARAAAZQAAAZASASQARARAZAAQAaAAASgRQARgTAAgYQAAgZgSgRQgRgRgagBQgZABgRARg");
	this.shape_17.setTransform(166.6604,9.9265,0.9749,0.9749);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("ABABqIAAgiIh/AAIAAAiIghAAIAAhCIARAAIBCiRIAbAAIBCCRIARAAIAABCgAgqAoIBWAAIgshjg");
	this.shape_18.setTransform(147.2359,11.5107,0.9749,0.9749);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AgvBZIAAixIBfAAIAAAgIg+AAIAAApIA7AAIAAAfIg7AAIAAApIA+AAIAAAgg");
	this.shape_19.setTransform(126.2515,9.8534,0.9749,0.9749);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_20.setTransform(115.1378,9.8534,0.9749,0.9749);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAeAAAQARQANAOAAAWQAAAZgRAPQgQAPgaAAgAgZA5IAZAAQAMAAAHgGQAHgGAAgLQAAgKgHgGQgHgGgMAAIgZAAg");
	this.shape_21.setTransform(104.5847,9.8534,0.9749,0.9749);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("Ag5BZIAAixIArAAQAUAAAOAGQAbAMAAAdQAAAYgUAKQAPAFAIAKQAIAMAAAPQAAA2hGAAgAgYA5IAWAAQAbAAAAgWQAAgXgbAAIgWAAgAgYgTIAQAAQAWAAAAgTQAAgSgWAAIgQAAg");
	this.shape_22.setTransform(90.8632,9.8534,0.9749,0.9749);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AhBBCQgcgbABgmQgBgnAcgbQAagaAnAAQAoAAAaAaQAcAbAAAnQAAAmgcAbQgbAagnABQgngBgagagAgrgqQgRASABAYQgBAZASARQARASAZAAQAaAAARgSQARgSAAgYQAAgZgRgRQgRgSgaAAQgZAAgSASg");
	this.shape_23.setTransform(73.8271,9.9265,0.9749,0.9749);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgQBZIAAiRIggAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_24.setTransform(59.6669,9.8534,0.9749,0.9749);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AhCBCQgbgbAAgmQAAgnAbgaQAbgcAnABQAogBAbAcQAbAaAAAnQAAAmgbAbQgbAagoAAQgmAAgcgagAgqgqQgSARAAAZQAAAZASARQARATAZAAQAaAAASgTQARgRAAgZQAAgZgSgRQgRgSgaABQgZgBgRASg");
	this.shape_25.setTransform(45.5311,9.9265,0.9749,0.9749);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00A7E0").s().p("AgrBZIAAixIBXAAIAAAgIg2AAIAACRg");
	this.shape_26.setTransform(31.3465,9.8534,0.9749,0.9749);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t5, new cjs.Rectangle(2,0.9,235.8,50.2), null);


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AE7BQQgVgMgNgVQgMgVAAgaQAAgZAMgVQANgUAVgNQAVgMAbgBQAaABAVAMQAVANANAUQAMAVAAAZQAAAagMAVQgNAVgVAMQgVAMgaABQgbgBgVgMgAFLgzQgNAIgIANQgIAOAAAQQAAARAIANQAIAOANAIQAOAIARABQASgBAOgIQAOgIAHgOQAIgOAAgQQAAgQgIgOQgIgNgNgIQgOgIgRgBQgSABgOAIgAs9BQQgVgMgMgVQgMgVgBgaQABgZAMgVQAMgUAVgNQAVgMAbgBQAbABAVAMQAVANAMAUQAMAVABAZQgBAagMAVQgMAVgVAMQgVAMgbABQgbgBgVgMgAssgzQgOAIgIANQgIAOAAAQQAAARAIANQAIAOAOAIQANAIASABQASgBANgIQAOgIAIgOQAIgOAAgQQAAgQgIgOQgIgNgOgIQgNgIgSgBQgSABgNAIgAX0BYIgSguIhCAAIgSAuIgkAAIBKiwIAaAAIBKCwgAXVALIgUgzIgUAzIAoAAgAUwBYIAAiRIghAAIAAgfIBjAAIAAAfIghAAIAACRgAThBYIg3hOIAABOIghAAIAAiwIAhAAIAABNIA3hNIAoAAIhDBXIBDBZgAQNBYIAAiwIBfAAIAAAfIg/AAIAAAqIA8AAIAAAeIg8AAIAAApIA/AAIAAAggAPWBYIgwiDIgxCDIgkAAIBGiwIAdAAIBGCwgAMeBYIAAiRIhBAAIAACRIggAAIAAiwICCAAIAACwgAJ7BYIAAiEIgvCEIgcAAIgwiEIAACEIggAAIAAiwIAsAAIAyCHIAxiHIAtAAIAACwgADpBYIg4hOIAABOIggAAIAAiwIAgAAIAABNIA4hNIAnAAIhDBXIBDBZgAgjBYIAAiwIBeAAIAAAfIg9AAIAAAqIA7AAIAAAeIg7AAIAAApIA9AAIAAAggAhgBYIg3hOIAABOIghAAIAAiwIAhAAIAABNIA3hNIAoAAIhDBXIBDBZgAj5BYIAAiRIhBAAIAACRIghAAIAAiwICDAAIAACwgAniBYIAVgtIhEiDIAoAAIAvBdIAphdIAkAAIhRCwgApABYIg3hOIAABOIghAAIAAiwIAhAAIAABNIA3hNIAoAAIhDBXIBDBZgAujBYIAAiRIhBAAIAACRIggAAIAAiwICCAAIAACwgAx+BYIAAh8IhPB8IghAAIAAiwIAhAAIAAB7IBPh7IAhAAIAACwgA10BYIAAiwIAxAAQAVAAANAGQANAGAGAJQAHAJACAJQACAJAAAHQAAAJgDAJQgDAKgHAHQgHAIgMAGQgNAFgTAAIgRAAIAABDgA1UgKIAUAAIALgBQAHgBAFgFQAFgFAAgLQAAgLgFgFQgFgFgHgBIgLgCIgUAAgA22BYIAAiRIhBAAIAACRIggAAIAAiwICCAAIAACwg");
	this.shape.setTransform(102.375,39.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(-88.6,22.5,380.6,32.7), null);


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AuABrIAAghIh2AAIAAixIAgAAIAACRIBBAAIAAiRIAhAAIAACRIAUAAIAABBgAOKBCQgUgNgNgUQgMgVgBgZQABgaAMgVQANgVAUgMQAWgNAaAAQAbAAAVANQAVAMAMAVQAMAVABAaQgBAZgMAVQgMAUgVANQgVAMgbAAQgaAAgWgMgAObhCQgOAIgHAOQgIANAAARQAAAQAIAOQAHAOAOAIQAOAIARAAQASAAAOgIQANgJAIgNQAIgOAAgQQAAgRgIgNQgIgOgNgIQgOgIgSAAQgSAAgNAIgAIwBFQgRgIgMgOQgMgOgFgQQgGgQAAgPQAAgPAGgQQAFgQAMgOQAMgOARgIQARgJAYAAQATAAAPAGQAQAHAMAMQANAMAHARIglAAQgFgGgGgFQgGgFgJgDQgIgDgLAAQgRAAgOAIQgOAJgHANQgIAOAAAQQAAAQAIAOQAIANAOAJQAOAIAQAAQAMAAAMgFQALgFAIgKIAmAAQgHAPgMAMQgMAMgPAGQgQAHgUAAQgXAAgRgJgA2mBFQgRgIgMgOQgMgOgFgQQgGgQAAgPQAAgPAGgQQAFgQAMgOQAMgOARgIQARgJAYAAQATAAAPAGQAQAHAMAMQANAMAHARIglAAQgFgGgGgFQgGgFgJgDQgIgDgLAAQgRAAgOAIQgOAJgHANQgIAOAAAQQAAAQAIAOQAIANAOAJQAOAIAQAAQAMAAAMgFQALgFAIgKIAmAAQgHAPgMAMQgMAMgPAGQgQAHgUAAQgXAAgRgJgAW6BKIAAhFIAAAAIgwBFIgmAAIAxhCQgOgCgLgGQgKgGgGgMQgHgLAAgQQAAgHACgJQACgKAHgJQAHgKANgGQANgHAXAAIAzAAIAACxgAWThDQgIAEgCAGQgDAGAAAGQAAAHADAGQACAGAIAEQAHAEANAAIATAAIAAg1IgTAAQgNAAgHAEgAUqBKIAAh8IhPB8IggAAIAAixIAgAAIAAB8IBPh8IAhAAIAACxgAQvBKIAAixIArAAIAKAAIAQADQAJACAIAFQAIAFAFAJQAGAJgBAOQAAALgDAHQgEAHgEAEIgHAFQAOAFAHALQAJALgBAPQABANgGAMQgGAMgQAIQgPAIgdABgARQAqIAVAAIAGAAQAFgBAFgCQAFgCAEgFQAEgEAAgJQAAgDgCgGQgBgFgGgEQgHgDgNgBIgVAAgARQgiIAQAAQAKgBAFgDQAFgEABgEIACgHQgBgIgDgEQgFgEgFgBIgJgBIgQAAgAM3BKIgxiDIgwCDIglAAIBHixIAdAAIBGCxgAGOBKIAVgtIhFiEIApAAIAuBfIAqhfIAkAAIhRCxgAC5BKIAAixIBeAAIAAAgIg+AAIAAApIA8AAIAAAfIg8AAIAAApIA+AAIAAAggAB3BKIAAixIAhAAIAACxgAgQBKIAAixIAfAAIAABFIAbAAQAWAAANAIQANAIAFAMQAGAMAAANQAAARgHAMQgIAMgOAHQgNAHgRAAgAAPAqIAbAAQAMAAAHgGQAHgGAAgLQAAgLgHgGQgHgEgMgBIgbAAgAhSBKIAAhKIhBAAIAABKIggAAIAAixIAgAAIAABHIBBAAIAAhHIAiAAIAACxgAk+BKIAAixIAhAAIAABFIAaAAQAWAAANAIQANAIAFAMQAGAMAAANQAAARgIAMQgHAMgNAHQgOAHgRAAgAkdAqIAbAAQALAAAHgGQAHgGAAgLQAAgLgHgGQgHgEgLgBIgbAAgAl0BKIgxiDIgxCDIgkAAIBHixIAcAAIBHCxgAohBKIgSguIhCAAIgSAuIglAAIBLixIAaAAIBKCxgApAgDIgUg0IgUA0IAoAAgAreBKIAAh8IhPB8IghAAIAAixIAhAAIAAB8IBPh8IAhAAIAACxgAxyBKIAAixIBeAAIAAAgIg+AAIAAApIA8AAIAAAfIg8AAIAAApIA+AAIAAAggAy0BKIAAiRIhBAAIAACRIggAAIAAixICCAAIAACxg");
	this.shape.setTransform(120.95,26.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(-71.9,8.8,386.70000000000005,32.7), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AAzBZIgSguIhBAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape.setTransform(332.525,23.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A7E0").s().p("AAYBZIg2hOIAABOIghAAIAAixIAhAAIAABNIA2hNIAoAAIhCBYIBCBZg");
	this.shape_1.setTransform(316.775,23.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#00A7E0").s().p("AAoBZIAAh8IhPB8IggAAIAAixIAgAAIAAB8IBPh8IAgAAIAACxg");
	this.shape_2.setTransform(299.875,23.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#00A7E0").s().p("AAgBZIAAhLIg/AAIAABLIghAAIAAixIAhAAIAABIIA/AAIAAhIIAhAAIAACxg");
	this.shape_3.setTransform(282.825,23.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#00A7E0").s().p("AArBZIgrg+IgpA+IgmAAIA9hZIg9hYIAmAAIApA+IArg+IAmAAIg9BYIA9BZg");
	this.shape_4.setTransform(266.5,23.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#00A7E0").s().p("AgvBZIAAixIBfAAIAAAgIg9AAIAAApIA6AAIAAAfIg6AAIAAApIA9AAIAAAgg");
	this.shape_5.setTransform(252.25,23.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIggAAIAACRg");
	this.shape_6.setTransform(240.825,23.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A7E0").s().p("AAbBZIAAhFIgBAAIguBFIgnAAIAxhCQgVgCgNgOQgNgOAAgXQAAgVALgOQAQgXAmAAIA0AAIAACxgAgYgdQAAAaAfAAIAUAAIAAg1IgUAAQgfAAAAAbg");
	this.shape_7.setTransform(222.575,23.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_8.setTransform(206.9,23.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7E0").s().p("AAgBZIAAhLIhAAAIAABLIggAAIAAixIAgAAIAABIIBAAAIAAhIIAhAAIAACxg");
	this.shape_9.setTransform(189.875,23.275);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#00A7E0").s().p("AAgBZIAAhLIg/AAIAABLIghAAIAAixIAhAAIAABIIA/AAIAAhIIAhAAIAACxg");
	this.shape_10.setTransform(173.525,23.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#00A7E0").s().p("AhCBBQgbgaABgnQgBgmAbgaQAcgbAmAAQAnAAAcAbQAbAaAAAmQAAAngbAaQgbAbgoAAQgmAAgcgbgAgrgqQgRARAAAZQAAAZARASQASASAZAAQAaAAARgSQARgTAAgYQABgZgSgRQgRgSgaAAQgZAAgSASg");
	this.shape_11.setTransform(155.3,23.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#00A7E0").s().p("AAqBZIgqg+IgpA+IgmAAIA8hZIg8hYIAmAAIApA+IAqg+IAmAAIg9BYIA9BZg");
	this.shape_12.setTransform(137.05,23.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#00A7E0").s().p("AgiBZIAVgtIhEiEIAoAAIAuBeIApheIAkAAIhRCxg");
	this.shape_13.setTransform(120.475,23.275);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#00A7E0").s().p("AAYBZIg2hOIAABOIghAAIAAixIAhAAIAABNIA2hNIAnAAIhBBYIBBBZg");
	this.shape_14.setTransform(105.2,23.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#00A7E0").s().p("AAaBZIAAhFIAAAAIguBFIgmAAIAwhCQgVgCgNgOQgNgOAAgXQgBgVALgOQARgXAmAAIAzAAIAACxgAgZgdQABAaAfAAIATAAIAAg1IgTAAQgfAAgBAbg");
	this.shape_15.setTransform(83.05,22.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_16.setTransform(67.35,22.975);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#00A7E0").s().p("AAZBZIg3hOIAABOIghAAIAAixIAhAAIAABNIA3hNIAnAAIhCBYIBCBZg");
	this.shape_17.setTransform(51.575,22.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#00A7E0").s().p("AhAA9QgXgbAAgiQAAghAXgbQAaggArAAQAcAAAVAPQAXAOALAZIgmAAQgQgVgcgBQgZABgSARQgRASAAAYQAAAYASASQARATAZgBQAbAAAPgUIAnAAQgMAYgUAOQgWAPgcAAQgrgBgagfg");
	this.shape_18.setTransform(34.35,23.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#00A7E0").s().p("AAgBZIAAhLIhAAAIAABLIggAAIAAixIAgAAIAABIIBAAAIAAhIIAhAAIAACxg");
	this.shape_19.setTransform(16.7,22.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#00A7E0").s().p("AAbBZIAAhFIgBAAIguBFIgnAAIAxhCQgVgCgNgOQgOgOABgXQAAgVALgOQAQgXAmAAIA0AAIAACxgAgZgdQAAAaAhAAIATAAIAAg1IgTAAQghAAAAAbg");
	this.shape_20.setTransform(0.95,22.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#00A7E0").s().p("Ag6BZIAAixIAhAAIAABFIAZAAQAfAAAPARQANAOAAAWQAAAZgRAPQgQAPgaAAgAgZA5IAZAAQAMAAAHgGQAHgGAAgLQAAgKgHgGQgHgGgMAAIgZAAg");
	this.shape_21.setTransform(-12.25,22.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#00A7E0").s().p("AAwBZIgwiDIgwCDIgkAAIBHixIAbAAIBHCxg");
	this.shape_22.setTransform(-28.425,22.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#00A7E0").s().p("AAzBZIgTguIhAAAIgSAuIgkAAIBKixIAZAAIBKCxgAgTALIAnAAIgUgzg");
	this.shape_23.setTransform(-45.95,22.975);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#00A7E0").s().p("AgPBZIAAiRIghAAIAAggIBhAAIAAAgIghAAIAACRg");
	this.shape_24.setTransform(-58.825,22.975);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00A7E0").s().p("AAnBZIAAh8IhOB8IghAAIAAixIAhAAIAAB8IBOh8IAhAAIAACxg");
	this.shape_25.setTransform(-72.75,22.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(-80,13.8,421.3,18.8), null);


(lib.p5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._5();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p5, new cjs.Rectangle(-149,-145,298,274), null);


(lib.p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._3();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p3, new cjs.Rectangle(-149,-145,300,250), null);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._2();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145,1.0067,0.9124);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2, new cjs.Rectangle(-149,-145,300,250), null);


(lib.p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-149,-145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1, new cjs.Rectangle(-149,-145,298,274), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("AqTBeQgvgrAbhAQAag5BOghQBYglCOAAQAgAAAcAEIAlAFIAPADIgUAkQgsgMgmAAQhIAAg7AVQhQAcgMA5QgHAiAYAeQAgAnBFgEQAWgBAqgOQAzgRAdgYIBIg/QAHgFAHgEQAGgCAIgBIAHAAIBNAAIAZBqIAwhpIBVAAIAxBRIAlhRIBOAAIhFCUIhQAAIgzhWIgmBWIgxAAIAAABIhcAAIgEgbIhUAAIgcAZIg3AAQg/AXhUAAQh4AAg0gvgAjhA/IAxgBIgEgpgAG6CFIAygxIgyhxIBNAAIAVA8IA/g9IBXAAIibCaQgFAFgEABQgFACgNABgAEgB3Ih+AAIBEiUIB+AAQA9AAAWAcQASAXgOAeQgNAbggASQgpAWhCAAIgDAAgAEHBSIAWAAQAaAAAUgGQAggKAGgYQAGgUgUgJQgOgGgWAAIgXAAg");
	this.shape.setTransform(0.0208,-5.0003);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-68.9,-19.1,137.9,28.200000000000003), null);


(lib.legal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AnpApIAAg+IAHAAIAAAGQADgEADgCQADgBAEAAQAHAAADADQAFADACAFQADAGAAAFQAAAHgDAGQgDAFgEADQgFADgGAAQgDAAgDgBQgDgCgCgDIAAAXgAnegLQgEAEAAAIQAAAJAEAEQADAEAFAAQAFAAAEgFQAEgEAAgJQAAgIgEgEQgDgEgGAAQgEAAgEAFgA7UAmIAAgPIgpAAIAAAPIgIAAIAAgWIAFAAQAHgLAAgjIAAgJIAmAAIAAA3IAHAAIAAAWgA7xgcIAAAWQgCANgFAJIAdAAIAAgvIgWAAgAHTAlIAAgOIgkAAIAAAOIgGAAIAAgUIADAAQAJgLgBgbIAgAAIAAAmIAFAAIAAAUgAG0ARIAZAAIAAggIgSAAQgBAVgGALgAg9AlIAAgOIg6AAIAAgsIAIAAIAAAmIASAAIAAgmIAIAAIAAAmIARAAIAAgmIAIAAIAAAmIAFAAIAAAUgAkJAlIAAgOIgkAAIAAAOIgHAAIAAgUIAFAAQAHgLABgbIAfAAIAAAmIAFAAIAAAUgAkoARIAYAAIAAggIgSAAQAAAVgGALgAF/AhQABgBABAAQAAAAABgBQAAAAAAgBQABAAAAgBIABgGIgEAAIAAgIIAIAAIAAAIQABAFgCADQgBADgFACgApXAhQADgBABgDIABgGIgEAAIAAgIIAJAAIAAAIQAAAFgCADQgCADgEACgAwEAhQADgBABgDIABgGIgFAAIAAgIIAJAAIAAAIQAAAFgCADQgBADgEACgEAiiAAUQgGgFAAgIIAHgBQABAHAEACQADADAFAAQAFAAAEgDQAEgEAAgGQAAgFgEgCQgDgEgGAAIgGABIACgHIABAAQAFAAADgCQAFgDAAgGQAAgDgDgDQgDgDgEAAQgFAAgDADQgDADgBAFIgIgBQACgIAFgEQAFgFAIAAQAFAAAEADQAEACACAEQADAEAAAEQAAAEgDADQgCADgEADQAGABADAEQADAEAAAFQAAAIgGAGQgGAGgJAAQgJAAgFgFgEAhxAAUQgGgFAAgIIAIAAQABAGADACQAEADADAAQAHAAADgEQAEgEABgHQAAgGgFgEQgDgDgHAAQgDAAgDACQgDABgCADIgHgBIAGggIAfAAIAAAHIgZAAIgDARQAGgEAGAAQAIAAAGAFQAFAGABAIQAAAJgFAGQgHAIgLAAQgHAAgGgFgEAgPAASQgGgHAAgRQAAgMACgGQACgHAFgEQAEgEAHAAQAGAAADADQAEABADAEIADAKIACAPQgBAKgCAHQgCAGgEAEQgEAEgIAAQgJAAgFgHgEAgUgAcQgDAGAAAQQAAAOADAFQAEAFAFAAQAGAAADgFQAEgFAAgOQAAgQgEgFQgDgFgGAAQgFAAgEAEgAetASQgGgHAAgRQAAgMACgGQADgHAEgEQAFgEAGAAQAGAAADADQAEABADAEIAEAKQABAFAAAKQAAAKgDAHQgBAGgFAEQgEAEgIAAQgJAAgFgHgAeygcQgDAGAAAQQAAAOADAFQAEAFAFAAQAGAAADgFQAEgFAAgOQAAgQgEgFQgDgFgGAAQgFAAgEAEgAd7ASQgFgHAAgQQgBgSAHgIQAGgIAKAAQAIAAAFAFQAEAEABAHIgIABQgBgFgCgCQgDgDgFAAIgGACQgDACgCAFQgCAGAAAJQACgEAEgCIAIgCQAJAAAFAGQAGAFgBAIQAAAGgDAFQgCAFgFADQgEADgGAAQgJAAgHgHgAeCgGQgDAEAAAFIABAIQABADAEADQADABADAAQAFAAAEgEQADgDAAgHQAAgGgDgEQgEgDgFAAQgGAAgDADgAdMAVQgFgEgBgIIAHgBQABAGAEACQACACAEAAQAEAAACgBIAFgEIADgIQABgEAAgEIAAgCQgDAEgEABQgEACgEAAQgIAAgGgEQgFgGAAgJQAAgKAGgFQAFgHAJAAQAGAAAFAEQAFADADAGQADAGAAAMQAAALgDAHQgDAHgFAEQgFAEgHAAQgHAAgFgEgAdRgcQgEAEAAAHQAAAGAEAEQADAEAGAAQAFAAAEgEQADgEAAgHQAAgGgDgEQgFgEgEAAQgGAAgDAEgAaHASQgFgHAAgRQAAgMACgGQACgHAEgEQAEgEAIAAQAEAAAFADQAEABACAEQACAEACAGIABAPQAAAKgCAHQgDAGgEAEQgEAEgHAAQgJAAgGgHgAaNgcQgEAGAAAQQAAAOAEAFQAEAFAFAAQAGAAADgFQADgFAAgOQAAgQgDgFQgDgFgGAAQgFAAgEAEgAVZAUQgHgEgFgHQgDgIAAgHQAAgPAJgJQAHgKAOAAQAJAAAHAFQAHAEAEAHQADAIAAAJQAAAJgEAHQgEAIgHAEQgHAEgIAAQgJAAgGgFgAVZgaQgGAGAAAOQAAAKAGAHQAGAHAJAAQAJAAAHgHQAGgHAAgLQAAgHgDgGQgCgGgFgDQgFgDgHAAQgIAAgHAGgAUGAUQgFgFAAgIIAHAAQABAGADACQAEADAEAAQAGAAAEgEQAEgEAAgHQAAgGgEgEQgEgDgGAAQgEAAgDACQgCABgCADIgHgBIAGggIAfAAIAAAHIgaAAIgCARQAFgEAGAAQAJAAAFAFQAGAGAAAIQAAAJgEAGQgHAIgLAAQgIAAgGgFgASlASQgHgHABgRQAAgMABgGQADgHAFgEQADgEAIAAQAFAAADADQAEABAEAEIADAKIABAPQAAAKgCAHQgCAGgFAEQgEAEgHAAQgKAAgEgHgASqgcQgEAGAAAQQAAAOAEAFQADAFAGAAQAFAAADgFQAEgFABgOQgBgQgEgFQgDgFgFAAQgGAAgDAEgAQRAUQgFgFAAgIIAHAAQACAGADACQADADAFAAQAGAAAEgEQADgEAAgHQAAgGgDgEQgEgDgGAAQgFAAgCACQgEABgBADIgHgBIAGggIAfAAIAAAHIgZAAIgDARQAGgEAGAAQAIAAAGAFQAFAGAAAIQAAAJgEAGQgHAIgKAAQgJAAgGgFgAOwASQgGgHAAgRQAAgMACgGQACgHAFgEQAEgEAHAAQAFAAAEADQAEABADAEIADAKIABAPQAAAKgCAHQgCAGgFAEQgDAEgIAAQgJAAgFgHgAO1gcQgDAGAAAQQAAAOADAFQADAFAGAAQAGAAADgFQAEgFAAgOQAAgQgEgFQgDgFgGAAQgGAAgDAEgAIWATQgHgGAAgIQAAgFADgEQAEgEAFgCQgEgBgCgEQgDgDAAgEQAAgIAFgEQAFgFAIAAQAIAAAGAFQAEAEAAAIQAAAEgCADQgCAEgFABQAGACADAEQADAEAAAFQAAAIgGAGQgFAFgKAAQgJAAgFgFgAIbgDQgDADgBAFQAAAEACADQACADADABIAGACQAGAAADgDQAFgEAAgGQAAgFgFgDQgDgDgGAAQgFAAgEADgAIdgeQgDADAAAEQAAAEADADQADAEAEAAQAFAAADgEQADgDAAgDQAAgFgDgDQgDgCgFAAQgEAAgDACgAA2ASQgGgGAAgLQAAgHACgFQADgGAFgDQAFgCAFAAQAJAAAEADQAEAEACAHIgIACQAAgFgDgDQgDgCgEAAQgGAAgEAEQgDAEAAAIQAAAKADAEQAEAEAFAAQAFAAADgDQADgDABgFIAIAAQgBAJgFAEQgGAEgIAAQgJAAgFgGgAilASQgFgGgBgLQABgMAGgGQAHgFAIAAQAJAAAGAGQAGAGAAAKQAAAJgCAFQgDAFgFADQgFACgGAAQgJAAgHgGgAiegLQgFAEAAAIQAAAIAFAEQAEAFAFAAQAGAAAEgFQADgEAAgJQAAgHgDgEQgEgFgGAAQgFAAgEAFgAlaALIAIgCQABAEACADQAEACADAAQAEAAADgCQADgCAAgEQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgFgDQgBgBgFAAIgCABIAAgGIAHAAIADgCQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgDgCgCQgCgCgEAAQgGAAgDAIIgIgBQAEgNANAAQAIAAAEADQAEAFAAAFQAAAGgGADQAEABACADQABADABAEQAAAGgFAEQgEADgJAAQgPAAgDgNgAmEASQgFgGAAgLQAAgLAFgGQAGgGAKAAQAJAAAGAGQAGAGgBAKIAAACIghAAQAAAIADAEQAEAEAGAAQAEAAAEgCQADgDABgEIAIABQgCAHgEAEQgGADgIAAQgKAAgGgGgAl9gMQgDADgBAGIAZAAQAAgGgDgCQgDgFgGAAQgGAAgDAEgAm1ASQgGgGAAgLQAAgMAHgGQAGgFAJAAQAJAAAGAGQAGAGAAAKQAAAJgCAFQgEAFgEADQgGACgFAAQgKAAgGgGgAmvgLQgDAEgBAIQABAIADAEQAEAFAGAAQAFAAAFgFQADgEAAgJQAAgHgDgEQgFgFgFAAQgGAAgEAFgAqIAVQgEgEAAgGQAAgDACgDQABgDADgBIAFgCIAHgBIAOgDIAAgBQAAgFgCgCQgDgDgGAAQgGAAgCACQgDACgBAFIgIgBIADgIQAEgDADgCQAFgBAGAAQAFAAAEABQAEABACADIACAFIAAAHIAAAJQAAALABADIACAFIgIAAQgBgCAAgDIgIAFIgJABQgIAAgEgDgAp5AEIgHABIgDACIAAAEQAAADABACQADACAFAAQAEAAAEgCQACgBACgEQACgCAAgFIAAgEIgNAEgAsHASQgGgGAAgLQAAgHADgFQACgGAFgDQAFgCAGAAQAHAAAFADQAFAEABAHIgHACQgBgFgDgDQgDgCgDAAQgGAAgEAEQgEAEAAAIQAAAKAEAEQADAEAGAAQAEAAAEgDQACgDABgFIAIAAQgCAJgFAEQgEAEgIAAQgJAAgGgGgAs4ASQgHgGAAgLQAAgMAIgGQAFgFAJAAQAJAAAGAGQAGAGABAKQAAAJgDAFQgDAFgFADQgFACgGAAQgKAAgFgGgAszgLQgEAEAAAIQAAAIAEAEQAFAFAFAAQAGAAAEgFQAEgEgBgJQABgHgEgEQgEgFgGAAQgFAAgFAFgAwyAVQgEgFgBgHIAHgBQABAFADADQACACAEAAQAEAAADgCIAFgEIACgHIABgJIAAgBQgCAEgFABQgDACgFAAQgIAAgFgFQgFgFgBgJQAAgKAGgGQAGgGAJAAQAFAAAGADQAEAEADAGQADAGAAALQAAALgDAIQgDAHgEAEQgGADgHAAQgHAAgFgDgAwtgcQgDAEgBAHQABAGADADQADAEAGAAQAGAAADgEQADgDAAgHQAAgHgDgDQgEgEgFAAQgFAAgEAEgAzFAUQgFgFgBgIIAIgBQABAGADADQADADAEAAQAHAAADgEQAFgEAAgIQAAgFgFgEQgDgEgHAAQgDAAgDACQgDACgCADIgHgBIAGghIAfAAIAAAHIgZAAIgEARQAHgDAGAAQAIAAAFAFQAGAGABAIQgBAJgFAGQgFAHgMAAQgHAAgGgEgA5hAUQgGgEgDgHQgDgJAAgIQAAgJADgIQAEgHAGgEQAIgDAIAAQAKAAAGAEQAGAFADAJIgIABQgCgGgFgEQgEgDgGAAQgHAAgFAEQgFADgCAGQgCAGAAAGQAAAIADAFQABAGAGAEQAEACAHAAQAGAAAFgEQAFgEACgIIAIADQgDAJgGAGQgHAFgKAAQgKAAgHgEgEggtAAUQgIgEgDgHQgEgIAAgHQABgQAHgJQAJgJAOAAQAIAAAHAEQAHAFAEAHQADAIAAAJQAAAIgEAIQgDAIgIAEQgHADgHAAQgKAAgGgEgEggtgAaQgGAGgBAOQABAKAGAHQAGAGAJAAQAKAAAGgGQAGgHAAgLQAAgIgDgGQgDgFgEgEQgGgDgFAAQgJAAgHAHgEghyAAUQgHgEgEgHQgDgIAAgHQAAgQAJgJQAHgJAOAAQAJAAAHAEQAHAFAEAHQADAIAAAJQAAAIgEAIQgDAIgIAEQgHADgIAAQgJAAgHgEgEghxgAaQgHAGABAOQgBAKAHAHQAGAGAJAAQAJAAAHgGQAGgHAAgLQAAgIgDgGQgDgFgFgEQgFgDgGAAQgJAAgGAHgEgi2AAUQgHgEgEgHQgDgIAAgHQAAgQAIgJQAJgJANAAQAJAAAGAEQAIAFADAHQAEAIAAAJQAAAIgEAIQgEAIgHAEQgHADgIAAQgJAAgHgEgEgi1gAaQgHAGAAAOQAAAKAHAHQAGAGAIAAQALAAAFgGQAHgHAAgLQgBgIgCgGQgDgFgFgEQgFgDgGAAQgJAAgGAHgEAhSAAYIAAgPIgbAAIAAgHIAdgpIAGAAIAAApIAJAAIAAAHIgJAAIAAAPgEAg/AACIATAAIAAgcgAfiAYQAAgIACgKQADgKAGgKQAFgJAFgHIgeAAIAAgHIAoAAIAAAGQgFAGgHALQgGAKgDALQgDAHAAAKgAceAYQAAgIACgKQADgKAFgKQAFgJAGgHIgeAAIAAgHIAoAAIAAAGQgFAGgHALQgFAKgEALQgCAHAAAKgAbsAYQABgIADgKQACgKAGgKQAEgJAHgHIgfAAIAAgHIAoAAIAAAGQgFAGgGALQgHAKgDALQgCAHgBAKgAbLAYIAAgPIgbAAIAAgHIAcgpIAHAAIAAApIAIAAIAAAHIgIAAIAAAPgAa4ACIATAAIAAgcgAZmAYIAAgxIgIAGIgIAEIAAgIQAHgDAEgEQAFgFADgEIAEAAIAAA/gAYlAYIAAgdIghAAIAAAdIgIAAIAAg/IAIAAIAAAbIAhAAIAAgbIAIAAIAAA/gAXAAYIAAg/IAZAAQAFAAAEACQAEAAAEACQADADABADQADAEAAAFQAAAIgFAFQgGAGgNAAIgQAAIAAAZgAXJgIIAQAAQAJAAACgEQAEgCAAgGQAAgEgCgCQgCgDgDgBIgIgBIgQAAgAWRAYIAAg/IApAAIAAAIIggAAIAAA3gATlAYIAAgxIgIAGIgIAEIAAgIQAHgDAEgEQAGgFABgEIAGAAIAAA/gARsAYIABgGQACgEADgEIAKgJQALgIADgFQAEgFAAgEQAAgFgDgDQgEgDgFAAQgGAAgDADQgDAEAAAGIgIgBQAAgJAGgFQAFgFAKAAQAIAAAGAFQAEAFABAIIgBAHQgCAEgEAEQgDAEgIAGIgKAIIgDAEIAfAAIAAAIgARSAYIAAgxIgHAGIgJAEIAAgIQAGgDAGgEQAEgFADgEIAFAAIAAA/gAP0AYIAAgPIgcAAIAAgHIAdgpIAGAAIAAApIAJAAIAAAHIgJAAIAAAPgAPgACIAUAAIAAgcgAOCAYQAAgIADgKQADgKAFgKQAFgJAGgHIgfAAIAAgHIApAAIAAAGQgGAGgGALQgGAKgEALQgBAHgBAKgANRAYQAAgIADgKQACgKAGgKQAFgJAGgHIgeAAIAAgHIAoAAIAAAGQgGAGgGALQgGAKgEALQgCAHAAAKgAMcAYIAAgdIghAAIAAAdIgIAAIAAg/IAIAAIAAAbIAhAAIAAgbIAJAAIAAA/gALdAYIAAgdIgiAAIAAAdIgIAAIAAg/IAIAAIAAAbIAiAAIAAgbIAIAAIAAA/gAKeAYIAAgxIgiAxIgIAAIAAg/IAHAAIAAAyIAigyIAJAAIAAA/gAHkAXIAAgIIAIAAIAAAIgAFrAXIAAghIgWAhIgIAAIAAgsIAIAAIAAAhIAWghIAIAAIAAAsgAD8AXIABgFQABgEAEgEQADgEAHgGIAOgMQADgFAAgFQABgEgEgEQgDgCgFAAQgGAAgDADQgEADAAAGIgHgBQAAgJAFgEQAGgFAJAAQAJAAAFAFQAFAFAAAIIgBAHQgBAEgFAEIgLAKIgKAIIgCAEIAeAAIAAAHgADTAXIAAghIgVAhIgIAAIAAgsIAIAAIAAAhIAVghIAJAAIAAAsgACjAXIAAghIgWAhIgIAAIAAgsIAHAAIAAAhIAWghIAIAAIAAAsgAB4AXIgJgOIgFgFQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIAAAVIgIAAIAAgsIAIAAIAAAUQAEAAABgCQACgBADgHIADgIIAEgCIAFAAIACAAIAAAGIgDAAIgDABQgCABgBAEIgDAHQgBACgDAAQAEABAGAIIAIAOgAAfAXIAAgUIgVAAIAAAUIgIAAIAAgsIAIAAIAAATIAVAAIAAgTIAIAAIAAAsgAgQAXIAAghIgWAhIgIAAIAAgsIAIAAIAAAhIAWghIAHAAIAAAsgAjiAXIAAg+IAYAAIAKABQAFABADACQADACABAEQADAEAAAFQAAAIgGAFQgEAGgOAAIgQAAIAAAYgAjZgJIAQAAQAIAAADgDQAEgDAAgFQAAgEgBgDQgDgDgDgBIgIAAIgQAAgAn+AXIAAg2IghAAIAAA2IgIAAIAAg+IAyAAIAAA+gAq4AXIAAgsIARAAIAKABQAEABACADQACADAAAEQAAADgBACQgCADgCABQADABACADQACACAAAFQAAAGgEADQgFADgIAAgAqwARIAJAAIAKgBQACgCAAgEQAAAAAAgBQAAgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBgBQAAAAgBAAQAAgBgBAAQAAAAAAAAIgIAAIgJAAgAqwgCIAIAAIAHgBIADgCQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABgDgDgCIgJgBIgIAAgArFAXIgJgOIgFgFIgDgCIAAAVIgJAAIAAgsIAJAAIAAAUQACAAACgCQACgBADgHIADgIQABAAAAAAQAAgBABAAQAAAAABAAQAAgBABAAIAFAAIACAAIAAAGIgCAAIgEABIgDAFIgDAHQgBACgEAAQAFABAGAIIAHAOgAtQAXIAAgzIgTAzIgHAAIgSg0IAAA0IgIAAIAAg+IANAAIAOAsIAEAKIACgLIAQgrIALAAIAAA+gAuzAXIAAgIIAJAAIAAAIgAvVAXIAAgsIAaAAIAAAGIgSAAIAAAmgAxUAXIAAgwIgIAFQgEADgEABIAAgHQAHgDAFgFIAHgIIAFAAIAAA+gAyCAXIAAgOIgbAAIAAgIIAcgoIAHAAIAAAoIAIAAIAAAIIgIAAIAAAOgAyVABIATAAIAAgbgAznAXIAAgwIgIAFIgIAEIAAgHQAHgDAFgFQAFgEACgEIAFAAIAAA+gA0XAXIAAgwIgIAFQgFADgDABIAAgHQAGgDAFgFQAFgEACgEIAFAAIAAA+gA2KAXIAAgIIAJAAIAAAIgA27AXIAAg+IApAAIAAAIIghAAIAAA2gA3SAXIAAgIIAJAAIAAAIgA3qAXIAAgcIggAAIAAAcIgJAAIAAg+IAJAAIAAAbIAgAAIAAgbIAIAAIAAA+gA4qAXIAAgIIAIAAIAAAIgA6YAXIAAgwIgiAwIgJAAIAAg+IAIAAIAAAxIAigxIAIAAIAAA+gA8VAXIAAgcIghAAIAAAcIgIAAIAAg+IAIAAIAAAbIAhAAIAAgbIAJAAIAAA+gA9OAXIgIgTIgaAAIgHATIgJAAIAZg+IAJAAIAZA+gA9ngUIgHATIAWAAIgGgSQgEgIgBgFIgEAMgA+KAXIgKgRIgIgJQgDgCgFAAIAAAcIgIAAIAAg+IAIAAIAAAcQAGAAACgCQADgCAEgJIAEgJQABgCAEgCQADgCADAAIAGABIAAAHIgCAAIgCAAQgEAAgCABIgFAJQgCAIgCACQgCACgEABQAGACAGAIIANAVgA1kAUIAMgTIgMgTIAHAAIAOATIgOATgA10AUIAMgTIgMgTIAGAAIAOATIgOATgA/AAUIgNgTIANgTIAHAAIgMATIAMATgA/RAUIgNgTIANgTIAHAAIgLATIALATgAEtAFIAAgIIAYAAIAAAIgAFYgeQgEgDAAgFIAFAAIACAEIAFABIAFgBIACgEIAGAAQAAAFgDADQgEADgFAAQgGAAgDgDgADBgeQgEgDgBgFIAFAAIADAEIAFABIAFgBQACgCABgCIAFAAQAAAFgEADQgDADgGAAQgFAAgDgDg");
	this.shape.setTransform(233.1,18.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.legal, new cjs.Rectangle(-2,0,459.6,34.7), null);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bfQMAAAg+fMAu3AAAMAAAA+fg");
	this.shape.setTransform(199.997,125,1.3333,0.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,400,250), null);


(lib.pics = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p5
	this.instance = new lib.p5();
	this.instance.parent = this;
	this.instance.setTransform(10,0.7);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(225).to({_off:false},0).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).wait(67).to({x:-10,alpha:0},6,cjs.Ease.get(1)).wait(1));

	// p3
	this.instance_1 = new lib.p3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(10,-54.35);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(150).to({_off:false},0).to({x:0,y:-55.05,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(75));

	// p2
	this.instance_2 = new lib.p2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(10,0.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75).to({_off:false},0).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(150));

	// p1
	this.instance_3 = new lib.p1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(10,0.7);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:0,y:0,alpha:1},6,cjs.Ease.get(1)).to({_off:true},74).wait(225));

	// Слой 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bWqMAAAgtTMAu3AAAMAAAAtTg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(305));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-159,-200.1,320,345.1);


(lib.main = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t5
	this.instance = new lib.t5();
	this.instance.parent = this;
	this.instance.setTransform(-119.65,-21.7,0.99,0.99);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(224).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-133,y:-24.55,alpha:1},5,cjs.Ease.get(1)).wait(70).to({alpha:0},5).wait(1));

	// t3
	this.instance_1 = new lib.t3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(15.4,-37.15,0.99,0.99);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(149).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:4.6,y:-41.55,alpha:1},5,cjs.Ease.get(1)).wait(67).to({scaleX:0.99,scaleY:0.99,x:15.4,y:-37.15,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(78));

	// t2
	this.instance_2 = new lib.t2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(4.1,-23.5,0.99,0.99);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75).to({_off:false},0).to({scaleX:1.1,scaleY:1.1,x:-8,y:-26.4,alpha:1},5,cjs.Ease.get(1)).wait(66).to({scaleX:0.99,scaleY:0.99,x:4.1,y:-23.5,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(153));

	// t1
	this.instance_3 = new lib.t1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-7.45,-21.7,0.99,0.99);
	this.instance_3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:1.1,scaleY:1.1,x:-20.8,y:-24.4,alpha:1},4,cjs.Ease.get(1)).wait(68).to({scaleX:0.99,scaleY:0.99,x:-7.45,y:-21.7,alpha:0},5,cjs.Ease.get(1)).to({_off:true},1).wait(227));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.8,-23.5,485.40000000000003,55.1);


// stage content:
(lib._970x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EhLsgG8MCXZAAAIAAN5MiXZAAAg");
	this.shape.setTransform(485,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(306));

	// uznat
	this.uznat = new lib.uznat();
	this.uznat.name = "uznat";
	this.uznat.parent = this;
	this.uznat.setTransform(871.55,44.95,0.7,0.7);
	this.uznat._off = true;

	this.timeline.addTween(cjs.Tween.get(this.uznat).wait(226).to({_off:false},0).wait(80));

	// legal
	this.legal = new lib.legal();
	this.legal.name = "legal";
	this.legal.parent = this;
	this.legal.setTransform(459.25,81.2,1,1,0,0,0,0.3,17.6);

	this.timeline.addTween(cjs.Tween.get(this.legal).wait(306));

	// logo
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(111.55,46.35,1,1,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(306));

	// pics
	this.pics = new lib.pics();
	this.pics.name = "pics";
	this.pics.parent = this;
	this.pics.setTransform(311.45,83.95,0.6,0.6,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.pics).wait(306));

	// text
	this.text = new lib.main();
	this.text.name = "text";
	this.text.parent = this;
	this.text.setTransform(580.3,37.55,0.9,0.9,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(306));

	// bg
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(0,45,2.425,0.36,0,0,0,0,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(306));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(484.5,41.9,486,129);
// library properties:
lib.properties = {
	id: '5820BE3BD3287347B8A7B18F7147B313',
	width: 970,
	height: 90,
	fps: 25,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/970x90_atlas_NP_.jpg", id:"970x90_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5820BE3BD3287347B8A7B18F7147B313'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_atlas_P_", frames: [[0,0,69,23]]},
		{name:"728x90_atlas_NP_", frames: [[0,122,300,120],[0,0,300,120],[0,244,300,120],[0,366,300,120]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["728x90_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["728x90_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["728x90_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.initialize(ss["728x90_atlas_NP_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t4_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AATA/IAAgxIAAAAIghAxIgbAAIAjguQgQgDgJgJQgJgKAAgQQAAgSAMgMQAMgLAWAAIAkAAIAAB9gAgLgjQgGAEAAALQAAAIAGAFQAFAFALAAIAOAAIAAglIgOAAQgLAAgFAEg");
	this.shape.setTransform(84.575,12.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AArA/IAAhdIghBdIgTAAIgihdIAABdIgXAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_1.setTransform(71.95,12.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgsAAIAAAdIAqAAIAAAVIgqAAIAAAdIAsAAIAAAXg");
	this.shape_2.setTransform(59.825,12.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVAAALAKQAMALAAASQAAARgLALQgLAKgWAAIgMAAIAAAwgAgQgHIAOAAQAIAAAGgDQAFgEAAgJQAAgJgFgDQgFgFgJABIgOAAg");
	this.shape_3.setTransform(50.925,12.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgoA/IAAh9IAfAAQAVAAAKAJQALAJAAAPQAAAJgDAFQgEAHgGADQAKAEAFAHQAGAHAAAMQAAASgNAKQgNAKgXAAgAgQAoIAPAAQAJABAEgFQAGgEAAgHQAAgIgFgFQgFgEgJAAIgPAAgAgQgOIALAAQAHAAAEgDQAEgEAAgGQAAgGgEgDQgEgDgHAAIgLAAg");
	this.shape_4.setTransform(41.125,12.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgpA/IAAh9IAXAAIAAAwIASAAQAUAAALALQALAJAAASQAAASgMAKQgMALgSAAgAgSAoIASAAQAJAAAEgEQAFgFAAgHQAAgHgFgFQgFgEgIAAIgSAAg");
	this.shape_5.setTransform(27.425,12.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_6.setTransform(18.5,12.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcA/IAAhYIg3BYIgYAAIAAh9IAYAAIAABYIA3hYIAYAAIAAB9g");
	this.shape_7.setTransform(8.65,12.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AArA/IAAhdIghBdIgTAAIghhdIAABdIgYAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_8.setTransform(-5.475,12.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AguAvQgTgTAAgcQAAgZATgVQATgTAbAAQAdAAASATQATAUAAAaQAAAbgTAUQgTASgcABQgagBgUgSgAgegeQgMAMAAASQAAASAMAMQANAMARAAQASAAANgMQAMgOAAgQQAAgRgMgNQgNgMgSAAQgRAAgNAMg");
	this.shape_9.setTransform(-20.425,12.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAzIAtAAIAAgzIAXAAIAAB9g");
	this.shape_10.setTransform(-33.375,12.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AguAvQgTgUAAgbQAAgZATgVQATgTAbAAQAdAAASATQATAUAAAaQAAAcgTATQgTASgcABQgagBgUgSgAgegeQgMAMAAASQAAASAMAMQANAMARAAQASAAANgMQAMgNAAgRQAAgSgMgMQgNgMgSAAQgRAAgNAMg");
	this.shape_11.setTransform(-46.275,12.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AARA/Igmg3IAAA3IgXAAIAAh9IAXAAIAAA2IAmg2IAcAAIgvA+IAvA/g");
	this.shape_12.setTransform(-57.2,12.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AglA4QgPgLgIgRIAbAAQAFAHAJAEQAHAEALgBQAPAAAKgIQALgJADgOIg4AAIAAgWIA4AAQgEgPgKgIQgMgIgNAAQgLAAgHAEQgJADgGAJIgbAAQAIgSAQgLQAPgJAUgBQAaABATASQATASAAAcQAAAcgTATQgTASgaABQgUgBgPgJg");
	this.shape_13.setTransform(-69.55,12.95);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqAvQgTgUAAgbQAAgbATgTQATgTAaAAQAVABAOAJQAPAJAJAUIgbAAQgGgJgIgDQgIgEgJAAQgRAAgNAMQgMANAAARQAAAQAMAOQANANARgBQAKABAGgEQAIgCAGgJIAbAAQgIAQgPAMQgPAJgUABQgagBgTgSg");
	this.shape_14.setTransform(-82.6,12.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqA/IAAh9IBIAAIAAAXIgxAAIAAAaIAUAAQAUgBALALQAKALAAAQQAAARgMALQgMALgRAAgAgTAoIAUAAQAHABAGgFQAFgFAAgHQAAgGgFgFQgFgFgIAAIgUAAg");
	this.shape_15.setTransform(83.05,-10.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgvAuQgTgSAAgcQAAgaATgTQATgUAcABQAdgBASAUQAUATAAAaQgBAcgTASQgTAUgcgBQgbABgUgUgAgdgdQgNAMAAARQAAASANAMQALANASAAQASAAANgNQAMgNAAgRQAAgRgMgMQgNgNgSAAQgSAAgLANg");
	this.shape_16.setTransform(70.5,-10.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgrAuQgSgSAAgcQAAgbATgSQASgUAbABQAVgBAOALQAPAJAJASIgaAAQgHgIgIgDQgIgEgJAAQgSAAgMANQgMANAAAQQAAAQAMAOQAOANAQAAQAKgBAGgDQAIgDAHgIIAbAAQgJAQgPALQgQAKgTAAQgaABgUgUg");
	this.shape_17.setTransform(56.8,-10.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AguAuQgUgSABgcQgBgaAUgTQASgUAcABQAcgBATAUQATATAAAaQAAAcgTASQgTAUgcgBQgbABgTgUgAgdgdQgNAMAAARQAAASANAMQAMANARAAQATAAALgNQANgNAAgRQAAgRgNgMQgMgNgSAAQgRAAgMANg");
	this.shape_18.setTransform(42.95,-10.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_19.setTransform(30.025,-10.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgqAuQgTgSAAgcQAAgbATgSQASgUAbABQAUgBAPALQAPAKAJARIgbAAQgFgHgJgEQgIgEgKAAQgRAAgMANQgMANAAAQQAAARANANQAMAOARgBQAJgBAIgDQAHgDAGgIIAbAAQgHAQgQALQgQAKgTAAQgbABgSgUg");
	this.shape_20.setTransform(17.7,-10.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAcBOIAAhXIg3BXIgXAAIAAh9IAXAAIAABYIA3hYIAXAAIAAB9gAgUg8QgIgHgCgKIAUAAQABAEACACQAEACADAAQAFAAACgCQADgCABgEIATAAQgBAKgIAHQgIAGgNAAQgMAAgIgGg");
	this.shape_21.setTransform(0.725,-11.625);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAlA/IAAh9IAXAAIAAB9gAg7A/IAAh9IAXAAIAAAxIATAAQATAAALAKQALAIAAATQAAARgMALQgMALgRAAgAgkAoIATAAQAJAAAEgEQAFgFAAgHQgBgIgEgDQgEgFgJAAIgTAAg");
	this.shape_22.setTransform(-12.725,-10.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAyIAtAAIAAgyIAXAAIAAB9g");
	this.shape_23.setTransform(-25.625,-10.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAUA/IAAgwIgUAAQgJABgKgDQgIgCgEgEQgGgFgCgGQgDgGAAgMIAAgoIAXAAIAAAlQAAAGABAEQABADACABQACACAEACQACABAHAAIAUAAIAAg4IAXAAIAAB9g");
	this.shape_24.setTransform(-36.925,-10.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_25.setTransform(-48.275,-10.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAiA/IgihdIghBdIgaAAIAyh9IAUAAIAxB9g");
	this.shape_26.setTransform(-60.7,-10.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgYAAIAABmg");
	this.shape_27.setTransform(-69.75,-10.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AguAuQgTgSAAgcQAAgaATgTQATgUAbABQAdgBASAUQATASAAAbQAAAcgTASQgTAUgcgBQgaABgUgUgAgegdQgMAMAAARQAAASAMAMQANANARAAQATAAAMgNQAMgNAAgRQAAgRgMgMQgMgNgTAAQgRAAgNANg");
	this.shape_28.setTransform(-80.025,-10.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t4_Слой_1, null, null);


(lib.t3_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgrAAIAAAdIApAAIAAAWIgpAAIAAAdIArAAIAAAWg");
	this.shape.setTransform(53.325,34.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_1.setTransform(42.525,34.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXA/IAAg0IgtAAIAAA0IgXAAIAAh9IAXAAIAAAyIAtAAIAAgyIAXAAIAAB9g");
	this.shape_2.setTransform(30.475,34.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgsAAIAAAdIAqAAIAAAWIgqAAIAAAdIAsAAIAAAWg");
	this.shape_3.setTransform(20.375,34.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAwA/Igkg3IAAA3IgXAAIAAg3IgkA3IgcAAIAthAIgsg9IAbAAIAkA2IAAg2IAXAAIAAA2IAkg2IAbAAIgsA8IAtBBg");
	this.shape_4.setTransform(7.825,34.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AguAuQgTgSAAgcQAAgbATgSQATgUAbABQAcgBATAUQATATAAAaQAAAbgTATQgTAUgcgBQgbABgTgUgAgegdQgMANAAAQQAAARAMANQANANARAAQASAAANgNQAMgMAAgSQAAgRgMgMQgNgNgSAAQgSAAgMANg");
	this.shape_5.setTransform(-7.275,34.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAiA/IgihcIghBcIgaAAIAyh9IATAAIAyB9g");
	this.shape_6.setTransform(-20.025,34.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_7.setTransform(-32.425,34.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAATQAAAQgLALQgMALgVgBIgMAAIAAAwgAgQgGIAOAAQAJAAAFgFQAFgEAAgHQAAgKgFgDQgFgEgJAAIgOAAg");
	this.shape_8.setTransform(-43.075,34.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_9.setTransform(-54.025,34.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_10.setTransform(94.35,11.45);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgsAAIAAAdIAqAAIAAAVIgqAAIAAAdIAsAAIAAAXg");
	this.shape_11.setTransform(86.475,11.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAASQAAARgLAKQgMAMgVAAIgMAAIAAAvgAgQgGIAOAAQAJAAAFgEQAFgEAAgJQAAgIgFgEQgFgEgJAAIgOAAg");
	this.shape_12.setTransform(77.575,11.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgsAAIAAAdIAqAAIAAAVIgqAAIAAAdIAsAAIAAAXg");
	this.shape_13.setTransform(68.125,11.45);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgqA/IAAh9IBJAAIAAAXIgyAAIAAAZIAUAAQAUAAALAMQAKAKAAARQAAAQgLALQgMALgSAAgAgTAoIAUAAQAIABAFgFQAFgEAAgHQAAgIgFgEQgEgEgJgBIgUAAg");
	this.shape_14.setTransform(58.8,11.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAuBLIAAgYIhaAAIAAAYIgYAAIAAgvIAMAAIAvhmIATAAIAvBmIALAAIAAAvgAgeAcIA9AAIgfhGg");
	this.shape_15.setTransform(46.4,12.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgvAvQgTgUABgbQgBgZATgVQAUgSAbgBQAcABATASQATAUABAaQgBAcgTATQgTATgcAAQgbAAgUgTgAgdgdQgNAMAAARQAAASANANQAMAMARAAQATAAALgNQANgMAAgSQAAgRgNgMQgLgNgTAAQgSAAgLANg");
	this.shape_16.setTransform(32.3,11.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_17.setTransform(19.375,11.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgYA/IAQggIgxhdIAdAAIAfBCIAehCIAZAAIg5B9g");
	this.shape_18.setTransform(3.65,11.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAsA/IAAhdIgiBdIgTAAIgihdIAABdIgWAAIAAh9IAfAAIAiBgIAjhgIAfAAIAAB9g");
	this.shape_19.setTransform(-10.1,11.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AArA/IAAhdIghBdIgTAAIgihdIAABdIgWAAIAAh9IAfAAIAiBgIAjhgIAgAAIAAB9g");
	this.shape_20.setTransform(-25.75,11.45);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAkA/IgNghIgtAAIgNAhIgaAAIA1h9IARAAIA1B9gAgNAIIAcAAIgPgkg");
	this.shape_21.setTransform(-39.875,11.45);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAASQAAARgLAKQgMAMgVAAIgMAAIAAAvgAgQgGIAOAAQAJAAAFgEQAFgEAAgJQAAgIgFgEQgFgEgJAAIgOAAg");
	this.shape_22.setTransform(-49.125,11.45);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgfA/IAAh9IA+AAIAAAXIgnAAIAABmg");
	this.shape_23.setTransform(-57.45,11.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AguAvQgUgUABgbQAAgaATgUQATgSAbgBQAcABATASQATAVAAAZQAAAcgTATQgTATgcAAQgbAAgTgTgAgegdQgMAMAAARQAAASAMANQANAMARAAQASAAAMgNQANgMAAgSQAAgRgNgMQgMgNgSAAQgSAAgMANg");
	this.shape_24.setTransform(-68.8756,11.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAASQAAASgMAJQgMAMgUAAIgMAAIAAAvgAgQgGIAOAAQAJAAAEgEQAFgEABgJQAAgIgGgEQgEgEgJAAIgOAAg");
	this.shape_25.setTransform(-80.4,11.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_26.setTransform(-91.375,11.45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgKAMQAFAAACgDQADgCAAgFIAAgCIgKAAIAAgWIAVAAIAAAVQAAAHgBAEQgCAEgDADQgDADgDABIgJACg");
	this.shape_27.setTransform(111.125,-5.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgrAAIAAAdIApAAIAAAWIgpAAIAAAdIArAAIAAAWg");
	this.shape_28.setTransform(104.425,-11.55);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgpA/IAAh9IAXAAIAAAxIASAAQAUAAALAKQALAKAAASQAAAQgMALQgLALgTAAgAgSApIASAAQAIgBAGgEQAEgEAAgHQAAgIgEgEQgGgFgIAAIgSAAg");
	this.shape_29.setTransform(95.4,-11.55);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAiA/IgihcIghBcIgaAAIAyh9IATAAIAyB9g");
	this.shape_30.setTransform(83.925,-11.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgsAAIAAAdIAqAAIAAAWIgqAAIAAAdIAsAAIAAAWg");
	this.shape_31.setTransform(73.525,-11.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgqA/IAAh9IBJAAIAAAXIgxAAIAAAaIATAAQAVAAAKALQALAKAAARQAAAQgMALQgLALgTAAgAgSApIATAAQAIgBAFgEQAFgEAAgHQAAgHgEgFQgFgEgJgBIgTAAg");
	this.shape_32.setTransform(64.175,-11.55);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgrAAIAAAdIApAAIAAAWIgpAAIAAAdIArAAIAAAWg");
	this.shape_33.setTransform(50.475,-11.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_34.setTransform(42.4,-11.55);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAcBOIAAhXIg3BXIgXAAIAAh9IAXAAIAABYIA3hYIAXAAIAAB9gAgUg8QgIgGgCgLIAUAAQAAADADADQADACAEAAQAFAAADgCQADgCAAgEIAUAAQgCALgIAGQgJAHgMAAQgLAAgJgHg");
	this.shape_35.setTransform(32.525,-13.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgYA/IAPggIgwhdIAcAAIAgBCIAdhCIAaAAIg5B9g");
	this.shape_36.setTransform(20.3,-11.55);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAATQAAAQgLALQgMALgVgBIgMAAIAAAwgAgQgGIAOAAQAJAAAFgFQAFgDAAgIQAAgKgFgDQgFgEgJAAIgOAAg");
	this.shape_37.setTransform(9.975,-11.55);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAcA/IAAhYIg3BYIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_38.setTransform(-1.475,-11.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgLBHIAAgSQgZAAgPgPQgQgPAAgXQAAgXAQgPQAPgQAZAAIAAgQIAXAAIAAAQQAYAAAQAQQAQAPAAAXQAAAXgQAPQgQAPgYAAIAAASgAAMAfQAPAAAJgJQAJgKAAgMQAAgMgJgLQgJgIgPgBgAgjgXQgJAKAAANQAAAMAJAKQAJAJAPAAIAAg/QgPABgJAIg");
	this.shape_39.setTransform(-15.075,-11.75);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAkA/IgNggIgtAAIgNAgIgaAAIA1h9IARAAIA1B9gAgNAIIAcAAIgPgkg");
	this.shape_40.setTransform(-28.125,-11.55);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABALAKQAMAKAAATQAAAQgMALQgMALgUgBIgMAAIAAAwgAgQgGIAOAAQAIAAAFgFQAFgDABgIQAAgJgGgEQgEgEgJAAIgOAAg");
	this.shape_41.setTransform(-37.35,-11.55);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgeA/IAAh9IA9AAIAAAXIgmAAIAABmg");
	this.shape_42.setTransform(-45.7,-11.55);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AguAvQgUgTABgcQAAgbATgSQATgUAbABQAcgBATAUQATATAAAaQAAAcgTATQgTASgcAAQgbAAgTgSgAgegeQgMAOAAAQQAAARAMANQANANARAAQASAAANgNQAMgMAAgSQAAgRgMgNQgNgMgSAAQgSAAgMAMg");
	this.shape_43.setTransform(-57.1256,-11.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgKA/IAAhmIgYAAIAAgXIBFAAIAAAXIgYAAIAABmg");
	this.shape_44.setTransform(-67.45,-11.55);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AguAvQgUgTABgcQAAgbATgSQATgUAbABQAcgBATAUQATATAAAaQAAAcgTATQgTASgcAAQgbAAgTgSgAgegeQgMANAAARQAAASAMAMQANANARAAQASAAAMgNQANgMAAgSQAAgRgNgNQgMgMgSAAQgSAAgMAMg");
	this.shape_45.setTransform(-77.6756,-11.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgLBHIAAgSQgZAAgPgPQgQgOAAgYQAAgYAQgOQAPgQAZAAIAAgQIAXAAIAAAQQAYAAAQAQQAQAPAAAXQAAAXgQAPQgQAPgYAAIAAASgAAMAfQAPAAAIgJQAKgLAAgLQAAgMgKgLQgIgIgPgBgAgjgXQgJAKAAANQAAAMAJAKQAJAJAPAAIAAg/QgPABgJAIg");
	this.shape_46.setTransform(-92.15,-11.75);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgqAvQgTgTAAgcQAAgbATgSQAUgUAaABQATAAAQAKQAPAKAIASIgaAAQgFgHgKgFQgIgEgJAAQgRAAgNANQgMANAAAQQAAARANANQALANASAAQAHAAAKgEQAJgEAEgHIAbAAQgJASgOAJQgPALgUgBQgaAAgTgSg");
	this.shape_47.setTransform(-106.025,-11.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AguAuQgTgSAAgcQAAgZATgVQAUgSAaAAQAcAAATASQATAUAAAaQAAAcgTASQgTAUgcAAQgaAAgUgUgAgegdQgMANAAAQQAAASAMANQAOAMAQAAQASAAANgNQAMgMAAgSQAAgRgMgMQgNgNgSAAQgRAAgNANg");
	this.shape_48.setTransform(28.075,-34.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_49.setTransform(17.775,-34.55);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgqAuQgTgSAAgcQAAgaATgUQATgSAbAAQATgBAPAKQARAMAHAQIgbAAQgFgGgIgFQgJgEgJAAQgRAAgNANQgMANAAAQQAAASAMAMQANANARAAQAIAAAJgDQAIgEAFgIIAbAAQgIASgPAJQgPALgUAAQgaAAgTgUg");
	this.shape_50.setTransform(7.65,-34.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AguAuQgUgSABgcQAAgaATgUQATgSAbAAQAcAAATASQATAVAAAZQAAAcgTASQgTAUgcAAQgbAAgTgUgAgegdQgMAMAAARQAAASAMANQANAMARAAQASAAAMgNQANgMAAgSQAAgRgNgMQgMgNgSAAQgSAAgMANg");
	this.shape_51.setTransform(-6.1756,-34.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVABAMAKQALALAAARQAAARgLAKQgNALgUAAIgMAAIAAAwgAgQgGIAOAAQAIAAAGgFQAEgDABgJQAAgIgFgEQgFgEgJAAIgOAAg");
	this.shape_52.setTransform(-17.7,-34.55);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_53.setTransform(-28.675,-34.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3_Слой_1, null, null);


(lib.t2_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAcA/IAAhYIg3BYIgXAAIAAh9IAXAAIAABYIA3hYIAXAAIAAB9g");
	this.shape.setTransform(100.075,11.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AARA/Igmg3IAAA3IgXAAIAAh9IAXAAIAAA2IAmg2IAcAAIguA+IAuA/g");
	this.shape_1.setTransform(88.9,11.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeA2QgNgLACgTIAXAAQAAAIAFAFQAFAFAIAAQAJAAAFgEQAGgEAAgIQAAgHgFgFQgFgFgIAAIgLAAIAAgVIAJAAQAIAAADgEQAFgDAAgHQAAgHgEgEQgEgEgHAAQgGAAgEADQgFAEAAAFIgXAAQAAgPAKgKQAKgKASAAQARAAAKAJQALAKAAAQQAAAJgFAHQgGAHgHAEQALACAFAIQAGAJAAALQAAARgMAKQgMAKgTAAQgTAAgLgLg");
	this.shape_2.setTransform(78.592,11.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgYA/IAPggIgwhdIAcAAIAgBCIAehCIAZAAIg5B9g");
	this.shape_3.setTransform(68.45,11.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVAAALAKQAMALAAASQAAARgLALQgLAKgWAAIgMAAIAAAwgAgQgHIAOAAQAIAAAGgDQAFgFAAgIQAAgJgFgDQgFgFgJABIgOAAg");
	this.shape_4.setTransform(58.125,11.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeA/IAAh9IA9AAIAAAXIgmAAIAABmg");
	this.shape_5.setTransform(49.775,11.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAkA/IgNghIgtAAIgNAhIgaAAIA1h9IARAAIA1B9gAgNAIIAbAAIgOgkg");
	this.shape_6.setTransform(39.175,11.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeA2QgNgLACgTIAXAAQAAAIAFAFQAFAFAIAAQAJAAAFgEQAGgEAAgIQAAgHgFgFQgFgFgIAAIgLAAIAAgVIAJAAQAIAAADgEQAFgDAAgHQAAgHgEgEQgEgEgHAAQgGAAgEADQgFAEAAAFIgXAAQAAgPAKgKQAKgKASAAQARAAAKAJQALAKAAAQQAAAJgFAHQgGAHgHAEQALACAFAIQAGAJAAALQAAARgMAKQgMAKgTAAQgTAAgLgLg");
	this.shape_7.setTransform(28.242,11.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAcBOIAAhXIg3BXIgXAAIAAh9IAXAAIAABYIA3hYIAXAAIAAB9gAgUg8QgIgHgCgKIAUAAQABAEACACQAEACADAAQAFAAACgCQADgCABgEIATAAQgBAKgIAHQgIAGgNAAQgMAAgIgGg");
	this.shape_8.setTransform(13.125,10.325);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgvAvQgSgUgBgbQABgZASgVQATgTAcAAQAdAAASATQAUAUAAAaQAAAcgUATQgTASgcABQgagBgVgSgAgdgeQgNAMAAASQAAASANAMQALAMASAAQASAAANgMQAMgNAAgRQAAgSgMgMQgNgMgSAAQgSAAgLAMg");
	this.shape_9.setTransform(-0.3,11.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAzIAtAAIAAgzIAXAAIAAB9g");
	this.shape_10.setTransform(-13.225,11.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgpA/IAAh9IBHAAIAAAXIgxAAIAAAZIATAAQAWAAAKAMQAKAKAAAQQAAASgMAKQgLALgTAAgAgTAoIAUAAQAHABAGgFQAFgFAAgHQAAgHgEgEQgHgFgHAAIgUAAg");
	this.shape_11.setTransform(-23.8,11.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AguAvQgUgUAAgbQAAgZAUgVQASgTAcAAQAcAAATATQAUAUgBAaQABAcgUATQgTASgcABQgbgBgTgSgAgegeQgMAMAAASQAAASAMAMQAMAMASAAQASAAAMgMQANgNAAgRQAAgSgNgMQgMgMgSAAQgSAAgMAMg");
	this.shape_12.setTransform(-36.35,11.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAtBLIAAgYIhZAAIAAAYIgYAAIAAgvIAMAAIAvhmIATAAIAvBmIAMAAIAAAvgAgeAcIA9AAIgfhFg");
	this.shape_13.setTransform(-50.475,13.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgYA/IAPggIgwhdIAdAAIAfBCIAehCIAZAAIg5B9g");
	this.shape_14.setTransform(-60.8,11.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AATA/IAAgxIghAxIgbAAIAiguQgPgDgJgJQgJgKAAgQQAAgSAMgMQALgLAXAAIAkAAIAAB9gAgLgjQgGAFAAAKQAAAIAGAFQAFAFALAAIAOAAIAAglIgOAAQgLAAgFAEg");
	this.shape_15.setTransform(-76.075,11.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAiA/IgihcIghBcIgaAAIAyh9IATAAIAyB9g");
	this.shape_16.setTransform(-87.05,11.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAtBLIAAgYIhZAAIAAAYIgYAAIAAgvIANAAIAuhmIATAAIAvBmIAMAAIAAAvgAgeAcIA9AAIgfhFg");
	this.shape_17.setTransform(-100.125,13.025);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AARA/Iglg4IAAA4IgYAAIAAh9IAYAAIAAA3IAlg3IAcAAIguA+IAuA/g");
	this.shape_18.setTransform(116.15,-11.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgVAyQgRgRgFgXIgUAAIAAA0IgXAAIAAh8IAXAAIAAAyIAVAAQAEgZATgOQASgOAXABQAbgBATAUQATATAAAaQAAAcgTASQgUAUgagBQgYAAgTgPgAgIgdQgMAMAAARQAAARAMANQAMANARAAQARAAANgNQAMgNAAgRQAAgRgMgMQgMgNgRAAQgTAAgLANg");
	this.shape_19.setTransform(101.3,-11.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAiA/IgihdIghBdIgaAAIAyh9IAUAAIAxB9g");
	this.shape_20.setTransform(85.3,-11.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAcBOIAAhXIg3BXIgYAAIAAh9IAYAAIAABYIA3hYIAXAAIAAB9gAgUg8QgIgHgCgKIAUAAQABAEACACQAEACADAAQAFAAADgCQACgCABgEIATAAQgBAKgJAHQgIAGgMAAQgMAAgIgGg");
	this.shape_21.setTransform(68.95,-12.675);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_22.setTransform(56.375,-11.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AASA/Igng4IAAA4IgXAAIAAh9IAXAAIAAA3IAng3IAbAAIguA+IAuA/g");
	this.shape_23.setTransform(45.2,-11.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AguAuQgUgSABgcQAAgbATgSQASgUAcABQAcgBATAUQATATAAAaQAAAcgTASQgTAUgcgBQgbABgTgUgAgegdQgMAMAAARQAAASAMAMQAMANASAAQASAAAMgNQANgNAAgRQAAgRgNgMQgMgNgSAAQgSAAgMANg");
	this.shape_24.setTransform(32.4244,-11.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAUAAAMALQAMAKAAATQAAAQgMALQgLAKgVAAIgMAAIAAAwgAgQgGIAOAAQAIAAAFgFQAFgDABgJQAAgIgGgEQgEgEgJAAIgOAAg");
	this.shape_25.setTransform(20.9,-11.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_26.setTransform(9.425,-11.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AhJA/IAAh9IAYAAIAABmIAmAAIAAhmIAWAAIAABmIAnAAIAAhmIAXAAIAAB9g");
	this.shape_27.setTransform(-5.35,-11.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgYAAIAAh9IAYAAIAABXIA3hXIAYAAIAAB9g");
	this.shape_28.setTransform(-24.1,-11.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAcBOIAAhXIg3BXIgYAAIAAh9IAYAAIAABYIA3hYIAYAAIAAB9gAgUg8QgIgHgBgKIATAAQAAADADADQADACAEAAQAFAAADgCQACgCABgEIATAAQgBAKgJAHQgIAGgMAAQgMAAgIgGg");
	this.shape_29.setTransform(-40.65,-12.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgXAAIAAh9IAXAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_30.setTransform(-53.225,-11.15);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AARA/Igmg4IAAA4IgXAAIAAh9IAXAAIAAA3IAmg3IAcAAIguA+IAuA/g");
	this.shape_31.setTransform(-64.4,-11.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AguAuQgTgSAAgcQAAgaATgTQATgUAbABQAdgBASAUQATATAAAaQAAAcgTASQgTAUgcgBQgbABgTgUgAgegdQgMAMAAARQAAASAMAMQAMANASAAQASAAAMgNQANgNAAgRQAAgRgNgMQgMgNgSAAQgSAAgMANg");
	this.shape_32.setTransform(-77.2,-11.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgqAuQgTgSAAgcQAAgbATgSQATgUAaABQAVgBAOALQAPAJAJASIgaAAQgHgIgIgDQgJgEgIAAQgSAAgLANQgNAMAAARQAAAQANAOQAMANARAAQAJgBAIgDQAHgDAGgIIAbAAQgIAQgPALQgQAKgTAAQgaABgTgUg");
	this.shape_33.setTransform(-90.9,-11.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAlA/IAAh9IAXAAIAAB9gAg7A/IAAh9IAYAAIAAAxIASAAQATAAAKAKQALAIAAATQAAASgLAKQgMALgRAAgAgjAoIASAAQAJAAAEgEQAEgFAAgHQAAgHgEgEQgFgFgIAAIgSAAg");
	this.shape_34.setTransform(-104.75,-11.15);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgoA/IAAh9IAeAAQAWAAAKAJQALAJAAAPQAAAIgEAHQgEAGgGADQALAEAFAGQAGAJAAAKQAAATgNAKQgNAKgXAAgAgRAoIAQAAQAIABAFgFQAGgEAAgIQAAgHgGgEQgFgFgIAAIgQAAgAgRgNIALAAQAIgBAEgDQAEgEAAgGQAAgGgEgDQgEgDgIAAIgLAAg");
	this.shape_35.setTransform(-116.525,-11.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2_Слой_1, null, null);


(lib.t1_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLA/IAAhnIgXAAIAAgWIBFAAIAAAWIgXAAIAABng");
	this.shape.setTransform(66.25,22.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXA/IAOggIgwhdIAdAAIAgBCIAdhCIAZAAIg5B9g");
	this.shape_1.setTransform(56.7,22.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAyIAtAAIAAgyIAXAAIAAB9g");
	this.shape_2.setTransform(44.975,22.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAcA/IAAhXIg3BXIgYAAIAAh9IAYAAIAABXIA3hXIAXAAIAAB9g");
	this.shape_3.setTransform(32.9,22.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AArA/IAAheIghBeIgTAAIghheIAABeIgYAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_4.setTransform(18.775,22.95);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgbBAIAcgrIgDABIgEAAQgPAAgLgMQgLgKABgTQgBgTAMgMQANgNASAAQATAAAMANQAMANAAASQAAAJgCAGQgBAEgIANIghAzgAgOgkQgGAGAAAKQAAALAGAFQAGAFAIAAQAKAAAFgFQAGgGAAgKQAAgKgGgGQgFgFgKgBQgJAAgFAGg");
	this.shape_5.setTransform(2.2,22.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdA1QgMgMgBgRIAWAAQACAJAFAEQAGAGAHAAQAJAAAGgHQAGgFAAgLQAAgKgGgFQgGgGgJAAQgEAAgFABQgFAEgCADIgUgGIALhBIA5AAIgBAWIgnAAIgEAXIAIgCIAHgBQASAAALAMQALANAAASQAAATgMAMQgNAMgSAAQgRAAgMgLg");
	this.shape_6.setTransform(-7.525,23.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAWIgrAAIAAAdIApAAIAAAXIgpAAIAAAcIArAAIAAAXg");
	this.shape_7.setTransform(-20.325,22.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAWIgrAAIAAAdIApAAIAAAXIgpAAIAAAcIArAAIAAAXg");
	this.shape_8.setTransform(-29.175,22.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAyIAtAAIAAgyIAXAAIAAB9g");
	this.shape_9.setTransform(-39.475,22.95);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAWIgrAAIAAAdIApAAIAAAXIgpAAIAAAcIArAAIAAAXg");
	this.shape_10.setTransform(-49.575,22.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AArA/IAAheIghBeIgTAAIghheIAABeIgYAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_11.setTransform(-61.925,22.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgVAxQgSgQgDgXIgVAAIAAA1IgXAAIAAh9IAXAAIAAAxIAVAAQAFgXASgOQASgPAXAAQAbAAATATQATAVAAAZQAAAbgTAUQgTASgbABQgYgBgTgQgAgIgeQgMAMAAASQAAARAMANQAMAMASAAQARABAMgNQANgNAAgRQAAgSgNgMQgMgMgRAAQgSAAgMAMg");
	this.shape_12.setTransform(99.65,0);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgpA/IAAh9IAYAAIAAAwIARAAQAUAAALALQALAJAAASQAAASgMAKQgMALgSAAgAgRAoIARAAQAJAAAFgEQAFgFAAgHQAAgHgGgFQgEgEgJAAIgRAAg");
	this.shape_13.setTransform(85.275,-0.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgYAAIAABmg");
	this.shape_14.setTransform(76.4,-0.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgqAvQgTgUAAgbQAAgaATgUQASgTAcAAQAUABAPAJQAPAKAIATIgbAAQgGgJgHgDQgIgEgKAAQgSAAgMAMQgMANAAARQAAARANANQANANAQgBQAKABAHgEQAHgCAGgJIAbAAQgHARgPALQgRAJgSABQgbgBgTgSg");
	this.shape_15.setTransform(66.25,0);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AguAvQgTgTAAgcQAAgaATgUQASgTAcAAQAcAAATATQATAVAAAZQAAAbgTAUQgTASgcABQgbgBgTgSgAgegeQgMANAAARQAAARAMANQAMAMASAAQASAAANgMQAMgNAAgRQAAgSgMgMQgNgMgSAAQgSAAgMAMg");
	this.shape_16.setTransform(52.425,0);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAXA/IAAg1IgtAAIAAA1IgXAAIAAh9IAXAAIAAAzIAtAAIAAgzIAXAAIAAB9g");
	this.shape_17.setTransform(39.475,-0.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgpA/IAAh9IAXAAIAAAwIASAAQAUAAALALQALAJAAASQAAASgMAKQgMALgSAAgAgSAoIASAAQAJAAAEgEQAGgFAAgHQgBgHgFgFQgFgEgIAAIgSAAg");
	this.shape_18.setTransform(29.175,-0.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAjA/IgjhcIghBcIgaAAIAyh9IATAAIAyB9g");
	this.shape_19.setTransform(17.7,-0.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgrAAIAAAdIApAAIAAAVIgpAAIAAAdIArAAIAAAXg");
	this.shape_20.setTransform(7.275,-0.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_21.setTransform(-0.8,-0.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAcA/IAAhYIg3BYIgXAAIAAh9IAXAAIAABYIA3hYIAXAAIAAB9g");
	this.shape_22.setTransform(-10.675,-0.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAwA/Igkg3IAAA3IgXAAIAAg3IgkA3IgcAAIAthAIgsg9IAbAAIAkA2IAAg2IAXAAIAAA2IAkg2IAbAAIgsA9IAtBAg");
	this.shape_23.setTransform(-24.975,-0.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAjA/IgjhcIghBcIgaAAIAyh9IATAAIAyB9g");
	this.shape_24.setTransform(-39.1,-0.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AguAvQgTgTAAgcQAAgZATgVQASgTAcAAQAcAAATATQATAVAAAZQAAAbgTAUQgTASgcABQgagBgUgSgAgegeQgMANAAARQAAARAMANQANAMARAAQASAAANgMQAMgOAAgQQAAgRgMgNQgNgMgSAAQgRAAgNAMg");
	this.shape_25.setTransform(-52.325,0);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAuBLIAAgYIhaAAIAAAYIgYAAIAAgvIANAAIAuhmIAUAAIAuBmIAMAAIAAAvgAgeAcIA9AAIgfhFg");
	this.shape_26.setTransform(-66.475,1.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgvAvQgSgUAAgbQAAgZASgVQATgTAcAAQAdAAASATQATAUABAaQgBAcgTATQgTASgcABQgbgBgUgSgAgdgeQgNAMAAASQAAASANAMQALAMASAAQASAAANgMQAMgNAAgRQAAgSgMgMQgNgMgSAAQgSAAgLAMg");
	this.shape_27.setTransform(-80.55,0);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVAAALAKQAMALAAASQAAARgLALQgLAKgWAAIgMAAIAAAwgAgQgHIAOAAQAIAAAGgDQAFgEAAgJQAAgJgFgDQgFgFgJABIgOAAg");
	this.shape_28.setTransform(-92.075,-0.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_29.setTransform(-103.025,-0.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AArA/IAAheIghBeIgTAAIghheIAABeIgYAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_30.setTransform(119.875,-23.05);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAsA/IAAheIgiBeIgTAAIghheIAABeIgYAAIAAh9IAgAAIAiBfIAjhfIAgAAIAAB9g");
	this.shape_31.setTransform(104.225,-23.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAkA/IgNggIgtAAIgNAgIgaAAIA1h9IARAAIA1B9gAgNAHIAbAAIgOgjg");
	this.shape_32.setTransform(90.125,-23.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVAAALALQAMAKAAATQAAAQgLALQgLAKgWAAIgMAAIAAAwgAgQgGIAOAAQAIAAAGgFQAFgDAAgJQAAgIgFgEQgFgEgJAAIgOAAg");
	this.shape_33.setTransform(80.875,-23.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgeA/IAAh9IA9AAIAAAXIgmAAIAABmg");
	this.shape_34.setTransform(72.525,-23.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AguAuQgUgSABgcQgBgaAUgTQASgUAcABQAcgBATAUQATATABAaQgBAcgTASQgTAUgcgBQgbABgTgUgAgdgdQgNAMAAARQAAASANAMQALANASAAQASAAANgNQAMgNAAgRQAAgRgMgMQgNgNgSAAQgSAAgLANg");
	this.shape_35.setTransform(61.1,-23);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAVAAAMALQALAKAAATQAAAQgLALQgLAKgWAAIgMAAIAAAwgAgQgGIAOAAQAIAAAGgFQAFgDAAgJQAAgIgFgEQgFgEgJAAIgOAAg");
	this.shape_36.setTransform(49.575,-23.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAXA/IAAhmIgtAAIAABmIgXAAIAAh9IBbAAIAAB9g");
	this.shape_37.setTransform(38.625,-23.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAeA/IgegrIgdArIgbAAIArg/Igrg+IAbAAIAdArIAegrIAbAAIgrA+IArA/g");
	this.shape_38.setTransform(23.125,-23.05);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAlA/IAAh9IAXAAIAAB9gAg7A/IAAh9IAYAAIAAAxIASAAQATAAALAKQALAIAAATQAAASgMAKQgMALgRAAgAgjAoIASAAQAJAAAFgEQAEgFAAgHQAAgHgFgEQgEgFgJAAIgSAAg");
	this.shape_39.setTransform(10.175,-23.05);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgnA/IAAh9IAjAAQAUAAAMALQAMAKAAATQAAAQgMALQgLAKgVAAIgMAAIAAAwgAgQgGIAOAAQAIAAAFgFQAFgDABgJQAAgIgGgEQgEgEgJAAIgOAAg");
	this.shape_40.setTransform(-1.3,-23.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgLA/IAAhmIgXAAIAAgXIBFAAIAAAXIgXAAIAABmg");
	this.shape_41.setTransform(-10.05,-23.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgqAuQgTgSAAgcQAAgbATgSQASgUAcABQAUgBAPALQAOAJAJASIgbAAQgGgHgHgEQgIgEgKAAQgSAAgMANQgMANAAAQQAAARAMANQANANARAAQAJgBAIgDQAHgDAGgIIAbAAQgHAQgQALQgQAKgSAAQgbABgTgUg");
	this.shape_42.setTransform(-20.15,-23);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAlA/IAAh9IAXAAIAAB9gAg7A/IAAh9IAXAAIAAAxIATAAQATAAALAKQALAIAAATQAAARgMALQgMALgRAAgAgkAoIATAAQAJAAAEgEQAFgFAAgHQgBgIgEgDQgEgFgJAAIgTAAg");
	this.shape_43.setTransform(-34.025,-23.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgqA/IAAh9IBJAAIAAAXIgxAAIAAAaIATAAQAWgBAJALQAKALAAAQQAAARgLALQgMALgSAAgAgSAoIATAAQAHAAAGgEQAFgFAAgHQAAgGgFgFQgEgFgJAAIgTAAg");
	this.shape_44.setTransform(-45.95,-23.05);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgbBAIAcgrIgDABIgDAAQgRAAgKgMQgLgLAAgSQAAgTAMgMQAMgNATAAQAUAAALANQANANAAASQAAAHgDAJQgCAGgHALIghAygAgOgkQgGAGAAAKQAAAKAGAHQAGAEAIAAQAJAAAGgFQAGgFAAgLQAAgKgGgGQgFgFgKgBQgJAAgFAGg");
	this.shape_45.setTransform(-60.125,-23.15);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAeA/IgegrIgdArIgbAAIAsg/Igsg+IAbAAIAdArIAegrIAbAAIgrA+IArA/g");
	this.shape_46.setTransform(-74.6,-23.05);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAlA/IAAh9IAXAAIAAB9gAg7A/IAAh9IAYAAIAAAxIASAAQATAAALAKQALAIAAATQAAASgMAKQgMALgRAAgAgjAoIASAAQAJAAAEgEQAFgFAAgHQgBgIgEgDQgEgFgJAAIgSAAg");
	this.shape_47.setTransform(-87.525,-23.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAiA/IgihdIghBdIgaAAIAyh9IATAAIAyB9g");
	this.shape_48.setTransform(-100.8,-23.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AghA/IAAh9IBDAAIAAAXIgrAAIAAAcIApAAIAAAXIgpAAIAAAcIArAAIAAAXg");
	this.shape_49.setTransform(-111.225,-23.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAeBLIAAgYIhTAAIAAh9IAYAAIAABmIAtAAIAAhmIAXAAIAABmIAOAAIAAAvg");
	this.shape_50.setTransform(-121.15,-21.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1_Слой_1, null, null);


(lib.p4_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._4();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4_Слой_1, null, null);


(lib.p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p3, new cjs.Rectangle(0,0,300,120), null);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2, new cjs.Rectangle(0,0,300,120), null);


(lib.p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1, new cjs.Rectangle(0,0,300,120), null);


(lib.Монтажный_кадр_1_logo_png = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logo_png
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(19,34);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(369));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_border = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Eg4ygG8MBxlAAAIAAN5MhxlAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(369));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AvwCQQhJhCArhiQAmhYB4gzQCHg4DZAAQAwABAsAFIA5AIIAWAFIgfA3QhEgTg5AAQhuAAhaAgQh6AsgTBWQgLA0AlAuQAxA7BpgEQAigCBAgWQBOgbAtgjIBuhgIAHgFQAIgGAHgDQAOgGARAAIB2AAIAmCjIBKihICDAAIBLB8IA4h8IB3AAIhpDjIh6AAIhPiDIg7CDIhLAAIAAABIiNAAIgFgoIiBAAIgrAlIhTAAQhiAkh/AAQi4AAhPhIgAlZBhIBLgCIgGhAgAKkDLIBMhLIhMitIB1AAIAhBdIBghfICFAAIjmDmQgMAMgIADIgcAFgAG4C2IjBAAIBpjjIDBAAQBcAAAhAsQAcAjgVAtQgTAqgxAbQhAAihmAAIgDAAgAGSB9IAiAAQAoAAAegJQAxgPAKglQAIgfgfgNQgUgJgjAAIgiAAg");
	this.shape.setTransform(631.1315,32.751,0.7,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgGAaQgDAAgCgDIgEgEIgCgGIAFgBIACABIABACIACADIADACIAEABIAFgBIADgCIACgDIABgDIgBgFIgCgCIgEgCIgGgBIAAgEIAFgBIAEgCIACgDIABgDIgBgEIgCgDIgDgCIgDAAIgDAAIgDACIgCADIgCAEIgDAAIgDAAIACgHIAEgEQACgDADAAIAFgBIAGABIAFADIADAEQACADAAADIgBAEIgCAEIgDACIgDABQAFABACADQADAEAAAEQAAAEgCADIgDAFIgGADIgHABg");
	this.shape_1.setTransform(708.2123,81.3462,1.0799,1.0799);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGAaIgDgBIgHgEIACgDIACgBIAHADIAFABIADgBIAEgDIACgDIABgFIAAgFIgDgDIgEgBIgDgBIgIABIgFgBIAEgZIAZAAIAAADIgCADIgDABIgPAAIgDANIAHgBQAEAAAEACQADABABACIAEAEIABAGQAAAFgBADIgFAGQgCADgEAAIgGACg");
	this.shape_2.setTransform(703.5959,81.3732,1.0799,1.0799);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAGAaIAAgNIgYAAIgBgGIAZghIAGAAIAAAhIAIAAIAAAFIgBABIgHAAIAAANgAgLAHIARAAIAAgWIABgDg");
	this.shape_3.setTransform(698.9525,81.3462,1.0799,1.0799);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHAZQgDgBgCgDQgDgEgCgFIgBgMIABgLQACgFADgEQACgDADgCQAEgBADAAIAHABQADACAEADQACADABAGQACAFAAAGQAAAHgCAFQgBAFgCAEQgEADgDABIgHACQgDAAgEgCgAgDgTQgCAAgDAEIgCAGIgBAJIABAKQAAADACADQADADACABIADABIAFgBIADgEQACgDABgDIABgKIgBgJIgDgGIgDgEIgFgBIgDABg");
	this.shape_4.setTransform(694.417,81.3462,1.0799,1.0799);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgNAaIAYgtIgaAAIgBgBIgBgBIAAgFIAjAAIAAAEIAAACIgBABIgVArIgBABIgCABg");
	this.shape_5.setTransform(689.8816,81.3462,1.0799,1.0799);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgGAZQgEgBgCgDQgEgEgBgFQgBgFAAgHQAAgGABgFQABgEAEgFQACgDAEgCIAGgBIAHABQAEACADADQADAEABAFIABALIgBAMQgBAFgDAEQgDADgEABIgHACgAgDgTQgCAAgDAEIgCAGIgBAJIABAKQABADABADQADADACABIADABIAFgBIADgEQACgDABgDIABgKIgBgJIgDgGIgDgEIgFgBIgDABg");
	this.shape_6.setTransform(685.1842,81.3462,1.0799,1.0799);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHAZQgCAAgDgDIgEgGIgBgHIACgIIAFgHIAMgSIACgBIACgBIAGAAIgPAUIgBACIgCABIAFgCIADAAIAGABQADAAADADIADAEIABAGIgBAHIgEAGQgDADgDAAIgHACQgDAAgEgCgAgDAAIgEACIgCAEIgBAEIABAEIACAEIADACIAEABIAFgBIADgCIACgEIABgEIgBgFIgCgDIgDgCIgFAAg");
	this.shape_7.setTransform(680.5948,81.3732,1.0799,1.0799);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLAbIARgXIABgCIgEACIgFABIgFgBIgFgDIgDgEIgBgGIABgHIAEgFQADgDACAAQADgCADAAQAEAAADACQADAAADADQACADABACIABAHIAAAFIgBAEIgCADIgPAWIgBABIgCABgAgDgTIgDACIgDADIAAAEQAAAFACADQAEACADAAIAEAAIAEgCIACgEIABgDIgBgFIgCgDIgEgCIgEgBg");
	this.shape_8.setTransform(675.9244,81.3192,1.0799,1.0799);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgNAaIAYgtIgaAAIgBgBIgBgBIAAgFIAjAAIAAAEIAAACIgBABIgVArIgBABIgCABg");
	this.shape_9.setTransform(671.4159,81.3462,1.0799,1.0799);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgMAaIAXgtIgaAAIgCgBIAAgBIAAgFIAjAAIAAAGIgBABIgVArIgBABIgCABg");
	this.shape_10.setTransform(666.7725,81.3462,1.0799,1.0799);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAGAaIAAgNIgYAAIAAgCIgBgEIAZghIAGAAIAAAhIAIAAIAAAGIgIAAIAAANgAgLAHIARAAIAAgZg");
	this.shape_11.setTransform(662.0481,81.3462,1.0799,1.0799);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHAZQgDgBgDgDQgCgEgCgFQgBgFAAgHQAAgGABgFQACgGACgDQADgDADgCIAHgBQAEAAADABIAHAFIAEAJQABAFAAAGQAAAHgBAFIgEAJIgHAEQgDACgEAAgAgEgTIgEAEIgCAGIgBAJIABAKQAAADACADIAEAEIAEABIAEgBQACgBACgDQACgDABgDIABgKIgBgJIgDgGQgCgEgCAAIgEgBIgEABg");
	this.shape_12.setTransform(657.5127,81.3462,1.0799,1.0799);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMAaIAAgFIAMAAIAAgmIgJAIIgBABIgBAAIgBgBIgBAAIgCgDIAPgOIAGAAIAAAvIAKAAIAAAFg");
	this.shape_13.setTransform(652.9233,81.3462,1.0799,1.0799);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAOAaIAAgXIgbAAIAAAXIgHAAIAAg0IAHAAIAAAYIAbAAIAAgYIAHAAIAAA0g");
	this.shape_14.setTransform(645.4992,81.3462,1.0799,1.0799);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgRAaIAAg0IAQAAQAEAAAEACQAEABACACQADADABADQABACAAAEQAAAEgBADIgFAEQgCADgEAAQgDACgEAAIgJAAIAAATgAgKABIAJAAIAEgBIAEgBIADgDIAAgFIAAgEIgDgEIgEgCIgEgBIgJAAg");
	this.shape_15.setTransform(640.3158,81.3462,1.0799,1.0799);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPAaIAAg0IAfAAIAAAGIgXAAIAAAug");
	this.shape_16.setTransform(635.8344,81.3462,1.0799,1.0799);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKAZQgGgDgCgDIgFgIIgCgLIACgKIAFgJQACgCAGgDQAFgCAFAAQAHAAAEACIAIAFIAFAJQACAEAAAGQAAAGgCAFIgFAIIgIAGQgEACgHAAQgFAAgFgCgAgHgSIgFAEIgEAGIgBAIIABAIIAEAHIAFAEIAHACIAIgCIAFgEQADgDABgEIABgIIgBgIQgBgEgDgCIgFgEIgIgCIgHACg");
	this.shape_17.setTransform(630.1921,81.3462,1.0799,1.0799);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgGAaIgEgBIgEgCIgCgCIACgDIACgBIACABIAFACIAEABIAEgBIAEgDIACgDIABgFIgBgFIgCgDIgEgBIgDgBIgJABIgFgBIAFgZIAYAAIAAADIgBADIgDABIgPAAIgDANIAHgBQAEAAADACQADAAACADIAEAEQABADAAADQAAAFgBADIgFAGQgEADgCAAQgDACgDAAg");
	this.shape_18.setTransform(622.6601,81.3732,1.0799,1.0799);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgMAaIAAgFIAMAAIAAgmIgJAIIgBABIgBAAIgBgBIgBAAIgCgDIAPgOIAGAAIAAAvIAKAAIAAAFg");
	this.shape_19.setTransform(618.0976,81.3462,1.0799,1.0799);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgHAZIgGgEIgEgJQgBgFAAgHQAAgGABgFIAEgJIAGgFIAHgBQAEAAAEABIAGAFIAEAJQABAFAAAGQAAAHgBAFIgEAJIgGAEQgEACgEAAgAgEgTIgDAEIgDAGIgBAJIABAKIADAGIADAEIAEABIAEgBQACgBACgDQACgDABgDIABgKIgBgJIgDgGQgCgEgCAAQAAAAAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAIgEABg");
	this.shape_20.setTransform(613.4542,81.3462,1.0799,1.0799);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgRAbIAAgDIABgBIABgCIATgVIADgDIACgDIABgFIgBgEIgCgDIgDgBIgEgBIgCABIgDABIgCADIgDAFIgCAAIgEgBIACgGIAEgFQADgCACgBIAGgBIAGABIAFADQADACAAADQACADAAADIgBAFIgDAFIgDAEIgRASIADgBIATAAIACABIABABIAAAFg");
	this.shape_21.setTransform(608.8108,81.3192,1.0799,1.0799);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgMAaIAAgFIALAAIAAgiIABgEIgJAIIgCABIAAAAIgBgBIgBAAIgCgDIAPgOIAFAAIAAAvIALAAIAAAFg");
	this.shape_22.setTransform(604.2754,81.3462,1.0799,1.0799);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgGAaIgEgBIgGgEIADgDIABgBIACABIAFACIAEABIAEgBIAEgDIACgDIABgFIgBgFIgCgDIgDgBIgEgBIgJABIgEgBIAEgZIAYAAIAAADIAAADIgDABIgQAAIgCANIAGgBQAEAAADACQAEABACACIADAEIABAGQAAAFgCADQgBAEgCACQgEADgCAAIgHACg");
	this.shape_23.setTransform(599.5509,81.3732,1.0799,1.0799);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAGAaIAAgNIgYAAIgBgGIAZghIAHAAIAAAhIAHAAIAAAFIAAABIgHAAIAAANgAgLAHIARAAIAAgUIAAgCIAAgDg");
	this.shape_24.setTransform(594.9075,81.3462,1.0799,1.0799);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgHAZQgDgBgDgDQgCgEgCgFQgBgFAAgHQAAgGABgFQACgGACgDQADgDADgCIAHgBQAEAAADABQADACADADQADAEACAFQABAFAAAGQAAAHgBAFQgCAFgDAEQgDADgDABQgDACgEAAgAgEgTIgEAEIgCAGIgBAJIABAKQAAADACADIAEAEIAEABIAEgBQACgBACgDQACgDABgDIABgKIgBgJIgDgGQgCgEgCAAIgEgBIgEABg");
	this.shape_25.setTransform(590.3991,81.3462,1.0799,1.0799);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgMAaIAWgtIgaAAIgBgBIAAgBIAAgFIAjAAIAAAEIgBACIAAABIgUArIgCABIgDABg");
	this.shape_26.setTransform(585.8367,81.3462,1.0799,1.0799);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgMAaIAXgtIgaAAIgCgBIAAgBIAAgFIAjAAIAAAGIgBABIgUArIgBABIgDABg");
	this.shape_27.setTransform(581.1933,81.3462,1.0799,1.0799);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAOAaIAAgXIgbAAIAAAXIgHAAIAAg0IAHAAIAAAYIAbAAIAAgYIAIAAIAAA0g");
	this.shape_28.setTransform(573.7962,81.3462,1.0799,1.0799);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAOAaIAAgXIgbAAIAAAXIgIAAIAAg0IAIAAIAAAYIAbAAIAAgYIAIAAIAAA0g");
	this.shape_29.setTransform(567.6949,81.3462,1.0799,1.0799);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAOAaIAAgmIAAgFIgCAGIgYAjIgBABIgCABIgGAAIAAg0IAIAAIAAArIABgDIABgCIAXgjIACgCIACgBIAFAAIAAA0g");
	this.shape_30.setTransform(561.5937,81.3462,1.0799,1.0799);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgGAaIgGgEQgCgBgCgDIgBgGQAAgGADgCQACgEAFgBQgEgCgCgCQgCgEAAgDIABgGIADgEQADgDACAAIAGgBIAHABQACAAADADIADAEIABAGQAAADgCAEQgCADgEABQAFABACAEQADACAAAGIgBAGQgCADgCABIgGAEIgHABgAgDACIgDACIgDADIgBAFIABADIACADIAEADIADABIAFgBIADgDIACgDIABgDIgBgFIgCgDIgEgCIgEAAgAgDgUIgDABIgCAEIAAADIAAADIACADIADADIADAAIAEAAIADgDIACgDIAAgDIAAgDIgCgEIgDgBIgEgBg");
	this.shape_31.setTransform(703.0179,70.7635,1.0799,1.0799);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgBAEIgCgBIgBgBIAAgDIABgCIACgBIABAAIACAAIABABIABACIABABIgBACIgBABIgBABIgCABg");
	this.shape_32.setTransform(697.7805,73.1392,1.0799,1.0799);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAPAZIAAgNIgdAAIAAALIgBACIgBAAIgFAAIAAgSIACAAIACAAIADgCIACgEIACgEIACgVIAXAAIAAAfIAHAAIAAAQIgBACIgBAAgAgFgBIgCAEIgCAEIARAAIAAgZIgKAAg");
	this.shape_33.setTransform(694.3249,72.2753,1.0799,1.0799);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgCAIIgBAAIAAgBIABgBIABgBIABgBIAAgEIgBAAIgBgBIgBgDIABgDQAAgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAIACABIABABIABACIAAACIAAADIgBADIgEAHg");
	this.shape_34.setTransform(688.9526,73.6521,1.0799,1.0799);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgPAaIAAgkIAHAAIAAAbIACgEIAQgWIABgBIABAAIAEAAIAAAkIgHAAIAAgaIABgBIgBABIgBABIgDADIgCAEIgLAQIgBABIgCABgAgDgQIgDgCIgDgCIAAgDIAAgCIABgBIAEAAIABAFIACABIAEAAIACgBIABgBIAAgEIAEAAIABABIABACIgBADIgCACIgEACIgEABg");
	this.shape_35.setTransform(685.74,70.7635,1.0799,1.0799);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgIADIAAgFIARAAIAAAFg");
	this.shape_36.setTransform(681.9875,71.1954,1.0799,1.0799);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgRAbIAAgEIABgCIAUgVIADgDIACgEIAAgDIAAgFIgCgCIgDgCIgEgBIgCABIgDACIgCACIgCADIgBACIgCAAIgEAAQAAgEACgDIAEgFIAFgDIAGAAIAGAAIAFADIADAFIABAGIAAAFIgDAGIgDADIgRASIAGgBIAQAAIACABIABABIAAAFg");
	this.shape_37.setTransform(678.181,70.7095,1.0799,1.0799);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgPAaIAAgkIAHAAIAAAZIgBACIACgDIABgBIAFgHIACgDIAIgMIABgBIACAAIAEAAIAAAkIgHAAIAAgYIAAgCIAAgBIAAABIgBABIAAABIgDACIgDAEIgLAQIgBABIgBABgAgDgQIgEgCIgCgCIgBgDIABgCIABgBIAEAAIABAEIABABIABABIAEAAIACgBIABgBIAAgEIAEAAIABABIAAACIgBADIgCACIgDACIgFABg");
	this.shape_38.setTransform(671.5668,70.7635,1.0799,1.0799);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgPATIAAglIAHAAIAAAZIAAACIABgCIABgBIAFgGIACgEIAIgMIABgBIACgBIAEAAIAAAkIgHAAIAAgXIAAgCIAAgCIAAACIgBABIAAABIgDADIgDADIgKAQIgBABIgCABg");
	this.shape_39.setTransform(666.9774,71.6004,1.0799,1.0799);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgPATIAAglIAHAAIAAAQIADAAIADgBIACgBIAGgMIACgBIACgBIAFAAIgJAOIgCADIgDABIADAAIADADIAJAPIgFAAIgDAAIgBgCIgHgLIgBgCIgDgBIgEAAIAAARg");
	this.shape_40.setTransform(662.8469,71.6004,1.0799,1.0799);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgEASIgFgEQgDgDgBgDQgBgDAAgFQAAgEABgDQABgDACgDIAGgEIAHgBIAHABIAFADIgCAEIgBAAIgCgBIgBgBIgDgBIgDAAIgEABIgDADIgCAEIgBAFIABAGIACAEQAAAAABABQAAAAAAABQABAAAAAAQABABAAAAIAEABIAEgBIAFgDIABABIACACIgCADIgEACIgIABQgCAAgDgBg");
	this.shape_41.setTransform(658.6894,71.6004,1.0799,1.0799);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AAJATIAAgRIgRAAIAAARIgHAAIAAgkIAHAAIAAAOIARAAIAAgOIAHAAIAAAkg");
	this.shape_42.setTransform(654.478,71.5734,1.0799,1.0799);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgPATIAAglIAHAAIAAAbIAEgGIAOgTIABgBIABgBIAEAAIAAAkIgHAAIAAgZIABgCIgBACIgBABIgQAXIgBABIgCABg");
	this.shape_43.setTransform(649.9425,71.6004,1.0799,1.0799);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAWAZIAAgNIgxAAIAAgkIAGAAIAAAfIAPAAIAAgfIAGAAIAAAfIAPAAIAAgfIAHAAIAAAfIAHAAIAAAQIgBACIgBAAg");
	this.shape_44.setTransform(644.4082,72.2753,1.0799,1.0799);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgGASIgGgEIgEgGIgBgIIABgHIAEgGIAGgEIAGgBIAIABIAFAEIAEAGIABAHIgBAIIgEAGIgFAEIgIABQgDAAgDgBgAgHgJQgDAEAAAFQAAAGADAEQADAEAEAAQAFAAADgEQADgEAAgGQAAgFgDgEQgDgEgFAAQgEAAgDAEg");
	this.shape_45.setTransform(638.496,71.6004,1.0799,1.0799);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgRAaIAAgzIAQAAIAIABIAGADIAEAFIABAHIgBAHIgEAEIgGAEIgIABIgIAAIAAATgAgJABIAIAAIAEgBIAEgBIADgEIAAgEIAAgEIgDgEIgEgCIgEAAIgIAAg");
	this.shape_46.setTransform(634.2845,70.7365,1.0799,1.0799);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAPAZIAAgNIgeAAIAAALIAAACIgCAAIgEAAIAAgSIACAAIACAAIACgCIADgEIABgEIADgVIAXAAIAAAfIAHAAIAAAQIgBACIgCAAgAgEgJQAAAFgBADIgCAEIgCAEIARAAIAAgZIgLAAg");
	this.shape_47.setTransform(627.1574,72.2753,1.0799,1.0799);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgDATIgEgBIgDgCIgDgDIACgCIABgBIACABIAEACIAEABIADgBIACgBIACgCIAAgDQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgCgCgEAAIgEAAIAAgDIAEAAQAEAAACgCQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBIgBgCIgBgCIgCgBIgDAAIgEAAIgCABIgCABIgBABIgCgBIgBgDIAFgDIAHgBIAFAAQADABACACQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABIABADIAAADIgBACIgCACIgDACQADAAACACIACAGQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAABQAAAAgBABQAAAAAAAAQgBABAAAAIgFACIgFABg");
	this.shape_48.setTransform(622.8379,71.6004,1.0799,1.0799);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgFASIgGgEIgDgGIgBgIIABgHIADgGIAGgEIAGgBIAGABQACAAADADIADAFIABAHIAAACIgBAAIgXAAIAAAGIADAEIADADIAEABIAHgCIAEgCIABABIACACIgDADIgDACIgIABIgHgBgAgFgLQgDADAAAFIATAAIgBgEIgCgEIgDgCIgEAAQgDAAgDACg");
	this.shape_49.setTransform(619.0314,71.6004,1.0799,1.0799);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgGASIgGgEQgDgDAAgDQgCgEAAgEIACgHQAAgDADgDIAGgEIAGgBIAHABIAGAEQADADAAADIACAHQAAAEgCAEQAAADgDADIgGAEIgHABIgGgBgAgHgJQgDAEAAAFQAAAHADADQADAEAEAAQAFAAADgEQACgDABgHQgBgGgCgDQgDgEgFAAQgEAAgDAEg");
	this.shape_50.setTransform(614.6579,71.6004,1.0799,1.0799);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgPAZIAAgwIADAAQABAAAAAAQAAAAABAAQAAAAAAAAQAAABAAAAIABAEQACgDADgBQAEgCADAAQADAAACABQADABACACQACADAAAEIABAIIgBAHIgDAFQgCADgDACIgGABQgDAAgDgBIgEgDIAAAQgAgFgSIgEAFIAAARIAEADIAFABQADAAADgEQAEgDAAgGIgBgHIgCgDIgDgDIgEgBg");
	this.shape_51.setTransform(610.2845,72.2213,1.0799,1.0799);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AANAaIAAgtIgZAAIAAAtIgIAAIAAgzIAoAAIAAAzg");
	this.shape_52.setTransform(605.0472,70.7365,1.0799,1.0799);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgEAIIAAgBIABgBIADgCIAAgCIAAgCIgBAAIgCgBIgBgBIAAgCIABgDQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAIACABIABABIABAEIAAADIgDAGIgDAEg");
	this.shape_53.setTransform(599.2159,73.6521,1.0799,1.0799);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgHATIgEgCIgCgEIgBgDIABgFIAEgDIAHgCIAKgCIAAgCQAAgFgCgCQgBgCgEAAIgEABIgEADIgCAAIgBAAIgBgBIgBgDQADgDAEgBIAHgBIAFABIAFACIACAFIABAGIAAAXIgFAAIgBgCIgBgDIgFAEIgDABIgEAAgAgEAEIgCADIgBACIAAACIACACIABABIACAAIADAAIACgBIAFgDIAAgIg");
	this.shape_54.setTransform(596.1923,71.5734,1.0799,1.0799);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgNATIAAgkIATAAIAEACQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAIABAEIAAACIgCACIgCACIgDACQAEAAACACQACACAAAEQAAABAAABQAAAAAAABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAIgEACIgGABgAgGAOIAGAAQAEAAACgCQACgBAAgDIAAgDIgCgCIgCgBIgEAAIgGAAgAgGgCIAGAAIACAAIADgCIABgBIABgCIgBgCIgBgDIgCgBIgDAAIgGAAg");
	this.shape_55.setTransform(592.4397,71.5734,1.0799,1.0799);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgPATIAAglIAHAAIAAAQIADAAIADgBIACgBIAHgMQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIACgBIAFAAIgJAOIgCADIgCABIADAAIALASIgEAAIgDAAIgCgCIgHgLIgBgCIgDgBIgEAAIAAARg");
	this.shape_56.setTransform(588.4982,71.6004,1.0799,1.0799);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgEASIgGgEIgDgGIgBgIIABgHIADgGIAGgEIAGgBIAHABIAGADIgCADIgBABIgBAAIgBgBIgBgBIgDgBIgDAAIgEABIgDADIgDAEIAAAFIAAAGIADAEIADADIADABIAEgBIAGgDIABABIACACIgDADIgDACIgEABIgEAAQgCAAgDgBg");
	this.shape_57.setTransform(584.3947,71.6004,1.0799,1.0799);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgGASIgGgEQgDgDAAgDQgCgEAAgEIACgHQAAgDADgDIAGgEIAGgBIAHABIAGAEQADADAAADIACAHQAAAEgCAEQAAADgDADIgGAEIgHABQgDAAgDgBgAgHgJQgDAEAAAFQAAAHADADQACAEAFAAQAFAAADgEQACgDABgHQgBgGgCgDQgDgEgFAAQgFAAgCAEg");
	this.shape_58.setTransform(580.1563,71.6004,1.0799,1.0799);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAVAaIAAgoIgRAfIgCACIgBAAIgBAAQAAAAAAAAQAAAAgBAAQAAgBgBAAQAAAAAAgBIgSgfIAAACIAAAmIgHAAIAAgzIAIAAIABABIASAfIAAAEIAUgjIABgBIAHAAIAAAzg");
	this.shape_59.setTransform(574.298,70.7365,1.0799,1.0799);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgBAEIgBgBIgBgBIgBgCIABgBIABgCIABgBIABAAIACAAIABABIABACIABABIgBACIgBABIgBABIgCABg");
	this.shape_60.setTransform(567.6568,73.1392,1.0799,1.0799);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgLATIAAgkIAXAAIAAAEIgQAAIAAAgg");
	this.shape_61.setTransform(565.7131,71.5734,1.0799,1.0799);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgDAIIAAAAIgBgBIABgBIABgBIACgBIAAgCIAAgCIgBAAIgCgBIgBgBIAAgCIABgDQABgBAAAAQABAAAAAAQABgBAAAAQAAAAAAAAIACABIABABIABACIAAACIAAADQAAAAAAAAQAAABAAAAQgBABAAAAQAAAAgBABIgBADIgDAEg");
	this.shape_62.setTransform(689.5347,63.4021,1.0799,1.0799);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgLAbIAQgVIABgCIABgCIgEACIgEABIgGgBIgFgDQgCgBgBgDIgBgGQAAgEABgDQABgCADgDIAFgEIAGAAIAHAAIAGAEIADAFIABAIIAAAEIgBAEIgCADIgPAWIgBACgAgDgTIgDACIgCADIgBAFQAAAEACADQADACAEAAIAEAAIAEgDIACgDIABgDIgBgFIgCgDIgEgCIgEgBg");
	this.shape_63.setTransform(686.2681,60.4595,1.0799,1.0799);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgMAaIAAgFIAMAAIAAglIgJAHIgBABQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBAAIgBgBIgCgDIAPgNIAGAAIAAAuIAKAAIAAAFg");
	this.shape_64.setTransform(681.7327,60.4865,1.0799,1.0799);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AAGAaIAAgNIgWAAIgBgBIgBgBIgBgDIAZghIAGAAIAAAgIAIAAIAAAEIgBABIgBABIgGAAIAAANgAgMAHIASAAIAAgWIABgCg");
	this.shape_65.setTransform(677.0083,60.4865,1.0799,1.0799);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgGAaIgHgDIgDgCIACgDIACgBIABAAIAGADIAEABIAEgBIAEgDIACgEIABgFIAAgEIgDgDIgEgBIgEgBIgHABIgFgBIAEgZIAYAAIAAADIgBADIgCABIgQAAIgCANIAGgBIAHABIAFAEIAEAEIABAGIgCAIIgDAGIgHADIgGACg");
	this.shape_66.setTransform(672.4188,60.5405,1.0799,1.0799);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgLAaIAAgFIALAAIAAgiIAAgDIgJAHIgBABQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIgBAAIAAgBIgDgDIAPgNIAGAAIAAAuIAKAAIAAAFg");
	this.shape_67.setTransform(667.8834,60.4865,1.0799,1.0799);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgMAaIAAgFIAMAAIAAglIgJAHIgBABIgBAAIgBAAIgBgBIgCgDIAPgNIAGAAIAAAuIAKAAIAAAFg");
	this.shape_68.setTransform(663.267,60.4865,1.0799,1.0799);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AABAOIgBgCIAAgBIAFgKIABAAIAAgBIgBAAIgFgKIAAgCIABgBIACgBIAJAOIAAAAIgJAPgAgKAOIgBgCIAAgBIAHgKIAAAAIAAgBIAAAAIgHgKIAAgCIABgBIADgBIAIAOIAAAAIgIAPg");
	this.shape_69.setTransform(657.2467,61.2424,1.0799,1.0799);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgBAEIgBgBIgBgBIgBgCIABgBIABgCIABgBIABAAIACAAIABABIABACIABABIgBACIgBABIgBABIgCABg");
	this.shape_70.setTransform(654.5201,62.8892,1.0799,1.0799);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgPAaIAAgzIAfAAIAAAGIgYAAIAAAtg");
	this.shape_71.setTransform(652.5493,60.4865,1.0799,1.0799);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgBAEIgBgBIgBgBIgBgCIABgBIABgCIABgBIABAAIACAAIACABIABACIAAADIgBABIgCABIgCABg");
	this.shape_72.setTransform(649.1208,62.8892,1.0799,1.0799);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAOAaIAAgXIgbAAIAAAXIgHAAIAAgzIAHAAIAAAXIAbAAIAAgXIAIAAIAAAzg");
	this.shape_73.setTransform(645.1523,60.4865,1.0799,1.0799);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgBAEIgBgBIgBgBIgBgCIABgBIABgCIABgBIABAAIACAAIABABIABACIABABIgBACIgBABIgBABIgCABg");
	this.shape_74.setTransform(641.1838,62.8892,1.0799,1.0799);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgGAZIgIgFIgGgJQgBgFAAgGQAAgGABgEQADgGADgDQADgEAFgBQAFgCAFAAQAGAAADACIAJAEIgDAEIgCABIgEgDIgDgBIgGgBQgEABgDABQgDABgDADIgDAGQgCAEABAEQgBAFACADIADAHIAGAEQADABAEABIADgBIAEgBIADgCIACgCIABAAIABAAIABAAIADAEQgDAEgFABQgFADgGAAQgEAAgFgCg");
	this.shape_75.setTransform(637.7012,60.5135,1.0799,1.0799);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AAOAaIAAgnIABgDIgEAFIgXAjIgBACIgCAAIgFAAIAAgzIAHAAIAAAnIgBADIACgDIAagnIACAAIAFAAIAAAzg");
	this.shape_76.setTransform(629.8722,60.4865,1.0799,1.0799);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AAVAhIAAgNIgpAAIAAALIgBABIgBABIgFAAIAAgTIAGAAIACgCIACgDIACgGIACgIIACgbIAfAAIAAAuIAIAAIAAARIAAABIgDABgAgHAAIgDAIIgDAGIAZAAIAAgoIgQAAg");
	this.shape_77.setTransform(623.609,61.1884,1.0799,1.0799);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AAOAaIAAgXIgbAAIAAAXIgIAAIAAgzIAIAAIAAAXIAbAAIAAgXIAHAAIAAAzg");
	this.shape_78.setTransform(617.5077,60.4865,1.0799,1.0799);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AATAaIgBAAIgBgBIgGgNIgWAAIgFANIAAABIgCAAIgGAAIAVgzIAGAAIAWAzgAgJAHIATAAIgJgWIgBgDg");
	this.shape_79.setTransform(611.7844,60.4865,1.0799,1.0799);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAOAaIgCAAIgBgCIgNgTIgCgCIgDgBIgGAAIAAAYIgHAAIAAgzIAHAAIAAAXIAGAAIABgBIABAAIABgBIACgBIANgUIACAAIAHAAIgQAVIgEAEIADABQAAAAABAAQAAABAAAAQABAAAAABQAAAAAAABIAQAWg");
	this.shape_80.setTransform(606.7361,60.4865,1.0799,1.0799);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAIgOIADABIABABIgBACIgFAKIgBAAIAGALIABABIgBACIgDABgAgLAAIAAAAIAJgOIACABIABABIgBACIgEAKIgBAAIAFALIABABIgBACIgCABg");
	this.shape_81.setTransform(601.9307,61.2424,1.0799,1.0799);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgKAZQgEgCgEgEQgDgEgCgEQgCgFAAgGQAAgGACgEQABgDAEgGQAEgEAEgBQAFgCAFAAQAGAAAFACQAEABAEAEQADAEACAFQACAEAAAGQAAAGgCAFQgCAGgDACQgEAEgEACQgHACgEAAQgDAAgHgCgAgGgSQgEABgDADIgDAGIgCAIQAAAFACADIADAHIAHAEIAGABIAHgBIAGgEIAEgHQACgDAAgFIgCgIQgBgDgDgDQgCgDgEgBQgDgBgEgBQgDABgDABg");
	this.shape_82.setTransform(595.0465,60.5135,1.0799,1.0799);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgJAZQgFgCgEgEQgDgCgDgGQgBgFAAgGQAAgGABgEIAGgJQAEgEAFgBQADgCAGAAQAGAAAEACQAFABAEAEIAGAJQABAEAAAGQAAAGgBAFQgCAFgEADQgEAEgFACQgFACgFAAQgEAAgFgCgAgHgSQgDABgDADQgDADAAADIgCAIQABAFABADIADAHIAGAEIAHABIAIgBIAGgEIADgHQABgDAAgFIgBgIIgDgGQgDgDgDgBQgDgBgFgBQgEABgDABg");
	this.shape_83.setTransform(588.6753,60.5135,1.0799,1.0799);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgJAZQgFgCgEgEQgDgCgCgGQgCgHAAgEQAAgEACgGIAFgJQAFgEAEgBQAEgCAFAAQAHAAAEACQAEABAEAEQAEAGABADQACAEAAAGQAAAGgCAFQgBAEgEAEQgEAEgEACQgGACgFAAQgDAAgGgCgAgGgSQgEABgCADQgDADgBADIgBAIQAAAFABADIAEAHIAGAEIAGABIAIgBIAGgEIADgHQACgDAAgFIgCgIIgDgGQgEgDgCgBQgDgBgFgBQgDABgDABg");
	this.shape_84.setTransform(582.2771,60.5135,1.0799,1.0799);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#00A7E0").s().p("EgXXAvFMAAAheJMAuuAAAMAAABeJg");
	this.shape_85.setTransform(364.0612,44.9708,2.434,0.1494);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(369));

}).prototype = p = new cjs.MovieClip();


(lib.t4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t4_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(-88.8,-19.4,177.6,38.9), null);


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t3_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(-112.2,-41,224.5,82.1), null);


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t2_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(-120.6,-20.5,241.3,41), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t1_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(-126.5,-29.5,253.1,59.1), null);


(lib.p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.p4_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(150,60,1,1,0,0,0,150,60);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4, new cjs.Rectangle(0,0,300,120), null);


(lib.Монтажный_кадр_1_t4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t4
	this.instance = new lib.t4();
	this.instance.parent = this;
	this.instance.setTransform(212.5,46.55,0.6842,0.6842,0,0,0,0.2,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(273).to({_off:false},0).to({regX:0.1,scaleX:0.8553,scaleY:0.8553,y:46.6,alpha:1},6,cjs.Ease.get(1)).wait(83).to({x:215.5},0).to({regX:0.2,scaleX:0.6842,scaleY:0.6842,y:46.55,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t3
	this.instance = new lib.t3();
	this.instance.parent = this;
	this.instance.setTransform(212.5,46.55,0.6842,0.6842,0,0,0,0.2,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({regX:0.1,scaleX:0.8553,scaleY:0.8553,y:46.6,alpha:1},6,cjs.Ease.get(1)).wait(83).to({regX:0.2,scaleX:0.6842,scaleY:0.6842,y:46.55,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t2
	this.instance = new lib.t2();
	this.instance.parent = this;
	this.instance.setTransform(212.5,46.55,0.6842,0.6842,0,0,0,0.2,0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(91).to({_off:false},0).to({regX:0.1,scaleX:0.8553,scaleY:0.8553,y:46.6,alpha:1},6,cjs.Ease.get(1)).wait(83).to({regX:0.2,scaleX:0.6842,scaleY:0.6842,y:46.55,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t1
	this.instance = new lib.t1();
	this.instance.parent = this;
	this.instance.setTransform(212.5,46.55,0.6842,0.6842,0,0,0,0.2,0.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,scaleX:0.8553,scaleY:0.8553,y:46.6,alpha:1},6,cjs.Ease.get(1)).wait(83).to({regX:0.2,scaleX:0.6842,scaleY:0.6842,y:46.55,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p4
	this.instance = new lib.p4();
	this.instance.parent = this;
	this.instance.setTransform(442.55,112.65,0.8002,0.8002,0,0,0,156.6,141);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(273).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(83).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p3
	this.instance = new lib.p3();
	this.instance.parent = this;
	this.instance.setTransform(437.35,108.6,0.8002,0.8002,0,0,0,150.1,135.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(182).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(92));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p2
	this.instance = new lib.p2();
	this.instance.parent = this;
	this.instance.setTransform(437.35,108.6,0.8002,0.8002,0,0,0,150.1,135.9);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(91).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(92));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p1
	this.instance = new lib.p1();
	this.instance.parent = this;
	this.instance.setTransform(437.35,108.6,0.8002,0.8002,0,0,0,150.1,135.9);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},6,cjs.Ease.get(1)).wait(92));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib._728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_368 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(368).call(this.frame_368).wait(1));

	// border_obj_
	this.border = new lib.Монтажный_кадр_1_border();
	this.border.name = "border";
	this.border.parent = this;
	this.border.setTransform(364,45,1,1,0,0,0,364,45);
	this.border.depth = 0;
	this.border.isAttachedToCamera = 0
	this.border.isAttachedToMask = 0
	this.border.layerDepth = 0
	this.border.layerIndex = 0
	this.border.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.border).wait(369));

	// logo_png_obj_
	this.logo_png = new lib.Монтажный_кадр_1_logo_png();
	this.logo_png.name = "logo_png";
	this.logo_png.parent = this;
	this.logo_png.setTransform(53.5,45.5,1,1,0,0,0,53.5,45.5);
	this.logo_png.depth = 0;
	this.logo_png.isAttachedToCamera = 0
	this.logo_png.isAttachedToMask = 0
	this.logo_png.layerDepth = 0
	this.logo_png.layerIndex = 1
	this.logo_png.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.logo_png).wait(369));

	// t4_obj_
	this.t4 = new lib.Монтажный_кадр_1_t4();
	this.t4.name = "t4";
	this.t4.parent = this;
	this.t4.depth = 0;
	this.t4.isAttachedToCamera = 0
	this.t4.isAttachedToMask = 0
	this.t4.layerDepth = 0
	this.t4.layerIndex = 2
	this.t4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t4).wait(369));

	// t3_obj_
	this.t3 = new lib.Монтажный_кадр_1_t3();
	this.t3.name = "t3";
	this.t3.parent = this;
	this.t3.depth = 0;
	this.t3.isAttachedToCamera = 0
	this.t3.isAttachedToMask = 0
	this.t3.layerDepth = 0
	this.t3.layerIndex = 3
	this.t3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t3).wait(277).to({_off:true},1).wait(91));

	// t2_obj_
	this.t2 = new lib.Монтажный_кадр_1_t2();
	this.t2.name = "t2";
	this.t2.parent = this;
	this.t2.depth = 0;
	this.t2.isAttachedToCamera = 0
	this.t2.isAttachedToMask = 0
	this.t2.layerDepth = 0
	this.t2.layerIndex = 4
	this.t2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t2).wait(186).to({_off:true},1).wait(182));

	// t1_obj_
	this.t1 = new lib.Монтажный_кадр_1_t1();
	this.t1.name = "t1";
	this.t1.parent = this;
	this.t1.setTransform(212.3,46.5,1,1,0,0,0,212.3,46.5);
	this.t1.depth = 0;
	this.t1.isAttachedToCamera = 0
	this.t1.isAttachedToMask = 0
	this.t1.layerDepth = 0
	this.t1.layerIndex = 5
	this.t1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t1).wait(95).to({_off:true},1).wait(273));

	// Слой_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AvfHeIAAu7Ie/AAIAAO7g");
	mask.setTransform(437.275,47.625);

	// p4_obj_
	this.p4 = new lib.Монтажный_кадр_1_p4();
	this.p4.name = "p4";
	this.p4.parent = this;
	this.p4.depth = 0;
	this.p4.isAttachedToCamera = 0
	this.p4.isAttachedToMask = 0
	this.p4.layerDepth = 0
	this.p4.layerIndex = 6
	this.p4.maskLayerName = 0

	var maskedShapeInstanceList = [this.p4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.p4).wait(369));

	// p3_obj_
	this.p3 = new lib.Монтажный_кадр_1_p3();
	this.p3.name = "p3";
	this.p3.parent = this;
	this.p3.depth = 0;
	this.p3.isAttachedToCamera = 0
	this.p3.isAttachedToMask = 0
	this.p3.layerDepth = 0
	this.p3.layerIndex = 7
	this.p3.maskLayerName = 0

	var maskedShapeInstanceList = [this.p3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.p3).wait(188).to({_off:true},92).wait(89));

	// p2_obj_
	this.p2 = new lib.Монтажный_кадр_1_p2();
	this.p2.name = "p2";
	this.p2.parent = this;
	this.p2.depth = 0;
	this.p2.isAttachedToCamera = 0
	this.p2.isAttachedToMask = 0
	this.p2.layerDepth = 0
	this.p2.layerIndex = 8
	this.p2.maskLayerName = 0

	var maskedShapeInstanceList = [this.p2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.p2).wait(97).to({_off:true},92).wait(180));

	// p1_obj_
	this.p1 = new lib.Монтажный_кадр_1_p1();
	this.p1.name = "p1";
	this.p1.parent = this;
	this.p1.setTransform(437.2,54.2,1,1,0,0,0,437.2,54.2);
	this.p1.depth = 0;
	this.p1.isAttachedToCamera = 0
	this.p1.isAttachedToMask = 0
	this.p1.layerDepth = 0
	this.p1.layerIndex = 9
	this.p1.maskLayerName = 0

	var maskedShapeInstanceList = [this.p1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.p1).wait(6).to({_off:true},92).wait(271));

	// bg_obj_
	this.bg = new lib.Монтажный_кадр_1_bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(364.1,45,1,1,0,0,0,364.1,45);
	this.bg.depth = 0;
	this.bg.isAttachedToCamera = 0
	this.bg.isAttachedToMask = 0
	this.bg.layerDepth = 0
	this.bg.layerIndex = 10
	this.bg.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(369));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(363.5,44.5,365,51);
// library properties:
lib.properties = {
	id: 'DF624D91B59A1445B55218DEF0718224',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_atlas_P_.png", id:"728x90_atlas_P_"},
		{src:"images/728x90_atlas_NP_.jpg", id:"728x90_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['DF624D91B59A1445B55218DEF0718224'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x300_atlas_P_", frames: [[0,0,176,159],[0,161,69,23]]},
		{name:"300x300_atlas_NP_", frames: [[137,0,135,300],[0,0,135,300],[274,0,135,300]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["300x300_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["300x300_atlas_NP_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._3 = function() {
	this.initialize(ss["300x300_atlas_NP_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._4 = function() {
	this.initialize(ss["300x300_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["300x300_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.t4_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AANAsIAAgiIAAAAIgXAiIgTAAIAZggQgLgCgHgHQgGgFAAgMQAAgOAIgIQAJgHAPAAIAaAAIAABXgAgHgYQgFADAAAHQAAAGAFAEQAEADAHAAIAJAAIAAgaIgJAAQgIAAgDADg");
	this.shape.setTransform(15.25,25.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAfAsIAAhBIgYBBIgNAAIgYhBIAABBIgQAAIAAhXIAWAAIAYBDIAZhDIAWAAIAABXg");
	this.shape_1.setTransform(6.325,25.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAQIgfAAIAAAUIAdAAIAAAPIgdAAIAAAVIAfAAIAAAPg");
	this.shape_2.setTransform(-2.225,25.075);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbAsIAAhXIAZAAQAOAAAIAHQAIAIAAAMQAAANgIAGQgHAIgPAAIgJAAIAAAhgAgLgEIAKAAQAFAAAEgDQADgCABgHQAAgFgEgDQgDgDgGAAIgKAAg");
	this.shape_3.setTransform(-8.525,25.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgcAsIAAhXIAWAAQAOAAAIAGQAHAHAAAKQAAAHgCADQgCAEgFADQAHADAEAEQAEAHAAAGQAAAOgJAGQgIAHgSAAgAgLAdIAKAAQAGAAAEgDQADgDAAgGQAAgFgDgDQgEgDgGAAIgKAAgAgLgJIAHAAQAFAAADgDQADgCAAgEQAAgFgDgCQgDgCgFAAIgHAAg");
	this.shape_4.setTransform(-15.425,25.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAsIAAhXIARAAIAAAiIANAAQANAAAIAHQAHAHABAMQAAAMgIAIQgJAHgMAAgAgMAdIANAAQAFAAAEgDQADgDAAgGQAAgGgDgCQgEgDgFAAIgNAAg");
	this.shape_5.setTransform(39.55,9.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHAsIAAhHIgRAAIAAgQIAxAAIAAAQIgRAAIAABHg");
	this.shape_6.setTransform(33.275,9.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhXIAQAAIAAA9IAng9IAQAAIAABXg");
	this.shape_7.setTransform(26.325,9.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAeAsIAAhBIgXBBIgNAAIgYhBIAABBIgQAAIAAhXIAWAAIAYBDIAZhDIAWAAIAABXg");
	this.shape_8.setTransform(16.35,9.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgVQgIAJgBAMQABAMAIAJQAJAJAMAAQANAAAJgJQAJgJAAgMQAAgMgJgJQgJgIgNAAQgMAAgJAIg");
	this.shape_9.setTransform(5.8,9.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQAsIAAglIgfAAIAAAlIgRAAIAAhXIARAAIAAAjIAfAAIAAgjIARAAIAABXg");
	this.shape_10.setTransform(-3.325,9.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AghAhQgNgOAAgTQAAgSANgOQAOgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgSAAgPgNgAgVgVQgJAJAAAMQAAAMAJAJQAJAJAMAAQANAAAIgJQAJgJAAgMQAAgMgJgJQgIgIgNAAQgMAAgJAIg");
	this.shape_11.setTransform(-12.4259,9.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAMAsIgagmIAAAmIgRAAIAAhXIARAAIAAAmIAagmIAUAAIggArIAgAsg");
	this.shape_12.setTransform(-20.175,9.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgaAnQgKgHgGgMIATAAQAEAFAGADQAGACAHAAQAKAAAHgGQAJgHABgKIgnAAIAAgOIAnAAQgCgLgIgGQgIgFgJAAQgHAAgHACQgGAEgEAFIgTAAQAGgNALgHQALgHAOAAQASAAANANQANANABATQgBAUgNANQgMANgTAAQgOAAgLgHg");
	this.shape_13.setTransform(-28.9,9.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgeAhQgNgNAAgUQAAgSANgOQAOgNASAAQAOAAALAHQALAHAGANIgTAAQgEgGgGgDQgGgCgGAAQgMAAgJAJQgJAJAAALQAAAMAJAJQAJAJAMAAQAFAAAGgCQAGgDAEgFIATAAQgGAMgKAHQgLAHgOAAQgSAAgOgNg");
	this.shape_14.setTransform(-38.075,9.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgdAsIAAhXIAzAAIAAAQIgjAAIAAASIAOAAQAOAAAIAIQAHAHAAALQAAAMgIAIQgIAHgNAAgAgNAdIAOAAQAGAAADgDQADgDAAgGQAAgFgCgDQgFgDgFAAIgOAAg");
	this.shape_15.setTransform(23.7,-6.925);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AghAhQgNgOAAgTQAAgSANgOQAOgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgSAAgPgNgAgVgVQgJAJAAAMQAAAMAJAJQAJAJAMAAQANAAAIgJQAJgJAAgMQAAgMgJgJQgIgIgNAAQgMAAgJAIg");
	this.shape_16.setTransform(14.8741,-6.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgdAhQgOgOAAgTQAAgSAOgOQANgNATAAQANAAALAHQAMAHAFANIgTAAQgFgGgFgDQgGgCgGAAQgMAAgJAJQgIAJAAALQAAAMAJAJQAIAJAMAAQAFAAAHgCQAGgEADgEIATAAQgFAMgLAHQgLAHgNAAQgTAAgNgNg");
	this.shape_17.setTransform(5.175,-6.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgVQgIAJAAAMQAAANAIAIQAJAJAMAAQANAAAJgJQAIgJAAgMQAAgLgIgKQgKgIgMAAQgLAAgKAIg");
	this.shape_18.setTransform(-4.575,-6.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAQAsIAAhHIgfAAIAABHIgRAAIAAhXIBBAAIAABXg");
	this.shape_19.setTransform(-13.725,-6.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgdAhQgOgOAAgTQAAgSAOgOQANgNATAAQANAAALAHQAMAHAFANIgTAAQgFgGgFgDQgGgCgGAAQgMAAgJAJQgIAJAAALQAAAMAIAJQAJAJAMAAQAFAAAHgCQAGgEADgEIATAAQgFAMgLAHQgLAHgOAAQgSAAgNgNg");
	this.shape_20.setTransform(-22.425,-6.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAUA3IAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYgAgOgqQgGgFgBgHIAOAAQAAAAAAABQABAAAAABQAAABAAAAQABABAAAAQACACADAAQADAAACgCIADgEIANAAQAAAHgHAFQgFAFgJAAQgIAAgGgFg");
	this.shape_21.setTransform(28.775,-24);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAaAsIAAhXIAQAAIAABXgAgpAsIAAhXIAQAAIAAAiIANAAQANAAAIAHQAIAHAAAMQAAAMgIAIQgIAHgNAAgAgZAdIAOAAQAFAAAEgDQACgDAAgGQAAgFgCgDQgEgDgFAAIgOAAg");
	this.shape_22.setTransform(19.275,-22.925);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AARAsIAAglIggAAIAAAlIgRAAIAAhXIARAAIAAAjIAgAAIAAgjIAQAAIAABXg");
	this.shape_23.setTransform(10.15,-22.925);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAOAsIAAghIgOAAQgKAAgDgBQgGgCgDgDQgEgDgCgEQgCgEAAgJIAAgcIARAAIAAAhIADADIAEACIAUABIAAgnIAQAAIAABXg");
	this.shape_24.setTransform(2.2,-22.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhXIAQAAIAAA9IAng9IAQAAIAABXg");
	this.shape_25.setTransform(-5.825,-22.925);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAYAsIgYhBIgXBBIgSAAIAjhXIANAAIAjBXg");
	this.shape_26.setTransform(-14.575,-22.925);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgHAsIAAhHIgRAAIAAgQIAxAAIAAAQIgRAAIAABHg");
	this.shape_27.setTransform(-20.975,-22.925);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgVQgIAKAAALQAAAMAIAJQAJAJAMAAQANAAAJgJQAIgIAAgNQAAgMgIgJQgKgIgMAAQgLAAgKAIg");
	this.shape_28.setTransform(-28.225,-22.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t4_Слой_1, null, null);


(lib.t3_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAsIAAhYIAvAAIAAAQIgfAAIAAAVIAeAAIAAAPIgeAAIAAAUIAfAAIAAAQg");
	this.shape.setTransform(37.25,32);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYg");
	this.shape_1.setTransform(29.625,32);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAQAsIAAglIggAAIAAAlIgQAAIAAhYIAQAAIAAAkIAgAAIAAgkIAQAAIAABYg");
	this.shape_2.setTransform(21.1,32);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAsIAAhYIAvAAIAAAQIgeAAIAAAVIAcAAIAAAPIgcAAIAAAUIAeAAIAAAQg");
	this.shape_3.setTransform(13.975,32);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAiAsIgagmIAAAmIgPAAIAAgmIgaAmIgUAAIAggsIgfgsIATAAIAaAnIAAgnIAPAAIAAAnIAagnIATAAIgfArIAgAtg");
	this.shape_4.setTransform(5.125,32);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghAhQgNgNAAgUQAAgSANgOQAOgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgSAAgPgNgAgVgUQgJAJAAALQAAANAJAJQAJAIAMAAQANAAAIgJQAJgIAAgNQAAgLgJgJQgIgJgNAAQgMAAgJAJg");
	this.shape_5.setTransform(-5.5259,32.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAYAsIgYhAIgXBAIgSAAIAjhYIANAAIAjBYg");
	this.shape_6.setTransform(-14.525,32);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYg");
	this.shape_7.setTransform(-23.275,32);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbAsIAAhYIAZAAQAOAAAIAIQAIAHAAANQAAANgIAGQgHAIgPAAIgJAAIAAAhgAgLgEIAKAAQAGAAADgDQADgCABgHQAAgFgEgEQgDgDgGAAIgKAAg");
	this.shape_8.setTransform(-30.825,32);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAQAsIAAhIIgfAAIAABIIgRAAIAAhYIBBAAIAABYg");
	this.shape_9.setTransform(-38.525,32);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgHAsIAAhIIgRAAIAAgPIAxAAIAAAPIgRAAIAABIg");
	this.shape_10.setTransform(27.375,16);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAPIgfAAIAAAVIAeAAIAAAPIgeAAIAAAVIAfAAIAAAPg");
	this.shape_11.setTransform(21.8,16);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgbAsIAAhXIAZAAQAOgBAIAIQAIAHAAAOQAAAMgIAGQgIAIgOAAIgJAAIAAAhgAgLgEIAKAAQAGAAADgDQAEgDAAgFQAAgHgEgCQgDgEgGAAIgKAAg");
	this.shape_12.setTransform(15.525,16);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAPIgeAAIAAAVIAdAAIAAAPIgdAAIAAAVIAeAAIAAAPg");
	this.shape_13.setTransform(8.825,16);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgdAsIAAhXIAzAAIAAAPIgiAAIAAATIAMAAQAQAAAHAIQAHAHAAALQAAAMgIAIQgIAIgOgBgAgMAdIANAAQAFAAAEgEQAEgDAAgFQgBgEgDgEQgDgDgGAAIgNAAg");
	this.shape_14.setTransform(2.25,16);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAgA1IAAgRIg/AAIAAARIgRAAIAAghIAJAAIAhhIIAOAAIAgBIIAIAAIAAAhgAgVAUIArAAIgVgxg");
	this.shape_15.setTransform(-6.5,16.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAIAAAMQAAANAIAJQAKAIALAAQANAAAJgJQAIgIAAgNQAAgLgIgJQgJgJgNAAQgMAAgJAJg");
	this.shape_16.setTransform(-16.425,16.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAQAsIAAhIIgfAAIAABIIgRAAIAAhXIBBAAIAABXg");
	this.shape_17.setTransform(-25.575,16);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgQAtIAKgXIgihBIAUAAIAWAuIAVguIASAAIgoBYg");
	this.shape_18.setTransform(54.325,0);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAeAtIAAhCIgXBCIgNAAIgYhCIAABCIgQAAIAAhYIAWAAIAYBCIAYhCIAXAAIAABYg");
	this.shape_19.setTransform(44.6,0);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAeAtIAAhCIgXBCIgNAAIgYhCIAABCIgQAAIAAhYIAWAAIAYBCIAZhCIAWAAIAABYg");
	this.shape_20.setTransform(33.55,0);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAZAtIgJgYIggAAIgJAYIgSAAIAmhYIALAAIAlBYgAgKAFIAUAAIgKgZg");
	this.shape_21.setTransform(23.6,0);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgbAtIAAhYIAYAAQAPAAAIAHQAIAIAAANQAAALgIAHQgIAIgPAAIgIAAIAAAigAgLgEIAKAAQAGAAADgDQAEgEAAgEQAAgHgEgCQgDgDgGAAIgKAAg");
	this.shape_22.setTransform(17.075,0);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgVAtIAAhYIArAAIAAAQIgbAAIAABIg");
	this.shape_23.setTransform(11.175,0);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgOANgTAAQgTAAgNgNgAgVgUQgJAJAAALQAAANAJAJQAJAIAMAAQANAAAJgJQAJgIAAgNQAAgLgJgJQgJgJgNAAQgMAAgJAJg");
	this.shape_24.setTransform(3.1,0.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgbAtIAAhYIAZAAQAOAAAIAHQAIAIAAANQAAALgIAHQgIAIgOAAIgJAAIAAAigAgLgEIAKAAQAGAAADgDQAEgDAAgFQAAgHgEgCQgDgDgGAAIgKAAg");
	this.shape_25.setTransform(-5.025,0);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAQAtIAAhIIgfAAIAABIIgQAAIAAhYIA/AAIAABYg");
	this.shape_26.setTransform(-12.75,0);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgHAIQADAAACgCQACgCAAgCIAAgCIgHAAIAAgPIAPAAIAAAPQAAAFgCACQAAACgCADIgFADIgGACg");
	this.shape_27.setTransform(-21.3,4.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgXAtIAAhYIAvAAIAAAQIgeAAIAAAUIAcAAIAAAPIgcAAIAAAVIAeAAIAAAQg");
	this.shape_28.setTransform(-26.025,0);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgdAtIAAhYIARAAIAAAiIAMAAQAOAAAIAHQAIAHAAAMQAAANgJAHQgIAIgNAAgAgMAdIAMAAQAGAAADgDQAEgEAAgFQAAgFgEgDQgDgDgGAAIgMAAg");
	this.shape_29.setTransform(-32.425,0);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAYAtIgYhCIgXBCIgSAAIAjhYIANAAIAjBYg");
	this.shape_30.setTransform(-40.525,0);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgXAtIAAhYIAvAAIAAAQIgeAAIAAAUIAcAAIAAAPIgcAAIAAAVIAeAAIAAAQg");
	this.shape_31.setTransform(-47.875,0);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgdAtIAAhYIAyAAIAAAQIghAAIAAASIAMAAQAQAAAHAIQAHAHAAALQAAANgJAHQgHAIgOAAgAgMAdIAMAAQAGAAAEgDQAEgEAAgFQAAgFgEgDQgDgDgHAAIgMAAg");
	this.shape_32.setTransform(-54.45,0);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgXAtIAAhZIAvAAIAAARIgfAAIAAAUIAdAAIAAAPIgdAAIAAAUIAfAAIAAARg");
	this.shape_33.setTransform(56.225,-16);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgHAtIAAhIIgRAAIAAgRIAxAAIAAARIgRAAIAABIg");
	this.shape_34.setTransform(50.5,-16);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAUA3IAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYgAgOgqQgFgEgCgIIAOAAQAAADADABQACACACAAQADAAACgCQADgBAAgDIAOAAQgCAIgFAEQgGAFgJAAQgIAAgGgFg");
	this.shape_35.setTransform(43.525,-17.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgQAtIAKgXIgihCIAUAAIAWAvIAVgvIASAAIgoBZg");
	this.shape_36.setTransform(34.9,-16);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgbAtIAAhZIAYAAQAPABAIAHQAIAIAAAMQAAAMgIAHQgIAIgPAAIgIAAIAAAigAgLgEIAKAAQAGAAADgDQAEgEAAgFQAAgFgEgEQgDgCgGAAIgKAAg");
	this.shape_37.setTransform(27.625,-16);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAUAtIAAg+IgnA+IgQAAIAAhZIAQAAIAAA+IAng+IAQAAIAABZg");
	this.shape_38.setTransform(19.525,-16);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgHAyIAAgMQgRAAgMgLQgLgLAAgQQAAgQALgLQALgKASgBIAAgLIAPAAIAAALQASABALAKQALALAAAQQAAAQgLALQgMALgRAAIAAAMgAAIAWQALAAAGgHQAHgGAAgJQAAgJgHgHQgGgGgLAAgAgYgQQgHAHAAAJQAAAIAHAHQAGAHALAAIAAgsQgLAAgGAGg");
	this.shape_39.setTransform(9.925,-16.125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAZAtIgJgYIgfAAIgJAYIgTAAIAlhZIANAAIAlBZgAgJAGIATAAIgKgZg");
	this.shape_40.setTransform(0.725,-16);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgcAtIAAhZIAZAAQAPABAIAHQAJAIAAAMQgBAMgHAHQgJAIgPAAIgIAAIAAAigAgLgEIAKAAQAFAAAEgDQAEgDAAgGQAAgFgEgEQgDgCgGAAIgKAAg");
	this.shape_41.setTransform(-5.8,-16);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgVAtIAAhZIArAAIAAARIgbAAIAABIg");
	this.shape_42.setTransform(-11.7,-16);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAJAAALQAAAMAIAKQAKAIALAAQANAAAJgJQAIgIAAgNQAAgMgIgIQgJgJgNAAQgMAAgJAJg");
	this.shape_43.setTransform(-19.775,-15.975);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgHAtIAAhIIgQAAIAAgRIAvAAIAAARIgQAAIAABIg");
	this.shape_44.setTransform(-27.05,-16);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAJAAALQAAAMAIAKQAKAIALAAQANAAAJgJQAIgIAAgNQAAgLgIgJQgJgJgNAAQgMAAgJAJg");
	this.shape_45.setTransform(-34.275,-15.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgHAyIAAgMQgRAAgLgLQgMgLAAgQQAAgQAMgLQAKgKASgBIAAgLIAQAAIAAALQARABALAKQALALAAAQQAAAQgLALQgMALgQAAIAAAMgAAJAWQAKAAAGgHQAHgHAAgIQAAgIgHgIQgGgGgKAAgAgYgQQgGAHgBAJQABAJAGAGQAGAHALAAIAAgsQgLAAgGAGg");
	this.shape_46.setTransform(-44.5,-16.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgdAhQgOgOAAgTQAAgSAOgOQANgNATAAQAOAAAKAHQAMAHAFANIgTAAQgEgFgGgDQgGgDgGAAQgMAAgJAJQgIAJAAALQAAAMAIAJQAJAJAMAAQAHAAAFgCQAGgDADgFIATAAQgFANgLAGQgKAHgPAAQgSAAgNgNg");
	this.shape_47.setTransform(-54.275,-15.975);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAJAAALQAAAMAIAKQAKAIALAAQANAAAJgJQAIgIAAgNQAAgLgIgJQgJgJgNAAQgMAAgJAJg");
	this.shape_48.setTransform(19.675,-31.975);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgHAsIAAhHIgRAAIAAgRIAxAAIAAARIgRAAIAABHg");
	this.shape_49.setTransform(12.4,-32);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgeAhQgNgOAAgTQAAgSANgOQAOgNATAAQAOAAAKAHQALAHAGANIgTAAQgEgFgGgDQgGgDgGAAQgMAAgJAJQgJAJAAALQABAMAIAJQAIAJANAAQAHAAAEgCQAGgCAEgGIATAAQgFANgLAGQgKAHgOAAQgTAAgOgNg");
	this.shape_50.setTransform(5.25,-31.975);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAJAAALQAAAMAIAKQAKAIALAAQANAAAJgJQAIgIAAgNQAAgLgIgJQgJgJgNAAQgMAAgJAJg");
	this.shape_51.setTransform(-4.525,-31.975);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgcAsIAAhYIAZAAQAPAAAIAIQAJAHAAANQgBAMgHAHQgJAIgPAAIgIAAIAAAhgAgLgEIAKAAQAGAAADgDQAEgDAAgGQAAgFgEgEQgDgDgGABIgKAAg");
	this.shape_52.setTransform(-12.65,-32);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAQAsIAAhHIgfAAIAABHIgRAAIAAhYIBBAAIAABYg");
	this.shape_53.setTransform(-20.375,-32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3_Слой_1, null, null);


(lib.t2_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhXIAQAAIAAA9IAng9IAQAAIAABXg");
	this.shape.setTransform(24.575,25.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAMAsIgbgnIAAAnIgQAAIAAhXIAQAAIAAAmIAbgmIAUAAIggArIAfAsg");
	this.shape_1.setTransform(16.7,25.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAmQgJgHABgOIAQAAQAAAGAEADQAEAEAFAAQAGAAAEgDQAEgDAAgFQAAgFgEgEQgDgDgGAAIgHAAIAAgPIAGAAQAFAAADgDQADgDAAgEQAAgFgDgDQgDgDgFAAQgDAAgDADQgEACAAAEIgQAAQAAgKAHgIQAHgHAMAAQAMAAAIAHQAHAHAAALQAAAFgDAGQgEAGgGACQAIABAEAGQAEAGAAAIQgBANgIAGQgHAHgOAAQgNAAgIgIg");
	this.shape_2.setTransform(9.4393,25.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgRAsIALgWIgihBIAUAAIAWAuIAVguIASAAIgpBXg");
	this.shape_3.setTransform(2.25,25.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgbAsIAAhXIAYAAQAPgBAIAIQAIAHAAAOQAAALgIAHQgIAIgPAAIgIAAIAAAhgAgLgEIAKAAQAGAAADgDQAEgDAAgGQAAgFgEgDQgDgEgGAAIgKAAg");
	this.shape_4.setTransform(-5.025,25.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgVAsIAAhXIArAAIAAAPIgbAAIAABIg");
	this.shape_5.setTransform(-10.925,25.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAaAsIgJgWIggAAIgJAWIgSAAIAkhXIAMAAIAmBXgAgJAFIATAAIgKgZg");
	this.shape_6.setTransform(-18.4,25.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAmQgJgHABgOIARAAQAAAGADADQAEAEAFAAQAHAAADgDQAEgDAAgFQAAgGgEgDQgDgDgGAAIgHAAIAAgPIAGAAQAFAAADgDQADgDAAgEQAAgFgDgDQgCgDgGAAQgDAAgDADQgDACgBAEIgQAAQAAgKAHgIQAHgHAMAAQAMAAAIAHQAHAHAAALQAAAGgDAFQgEAGgFACQAHABAEAGQAEAGAAAIQAAAMgIAHQgJAHgNAAQgNAAgIgIg");
	this.shape_7.setTransform(-26.1107,25.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAUA3IAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYgAgOgqQgFgEgCgIIAOAAQAAADADABQABACADAAQADAAACgCQACgBABgDIAOAAQgCAHgFAFQgGAFgJAAQgIAAgGgFg");
	this.shape_8.setTransform(39.925,7.975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgJAIAAAMQAAANAJAIQAJAJAMAAQANAAAJgJQAJgJAAgMQAAgMgJgIQgJgJgNAAQgMAAgJAJg");
	this.shape_9.setTransform(30.45,9.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAQAtIAAgmIgfAAIAAAmIgRAAIAAhYIARAAIAAAkIAfAAIAAgkIARAAIAABYg");
	this.shape_10.setTransform(21.325,9.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdAtIAAhYIAzAAIAAAPIgiAAIAAATIAMAAQAQAAAHAHQAHAIAAALQAAANgIAHQgIAIgOAAgAgMAdIANAAQAFAAAEgDQAEgDAAgGQgBgEgDgEQgDgDgGAAIgNAAg");
	this.shape_11.setTransform(13.85,9.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AghAhQgNgNAAgUQAAgSANgOQAOgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgSAAgPgNgAgVgUQgJAIAAAMQAAANAJAIQAJAJAMAAQANAAAIgJQAJgJAAgMQAAgMgJgIQgIgJgNAAQgMAAgJAJg");
	this.shape_12.setTransform(5.0241,9.075);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAgA1IAAgRIg/AAIAAARIgQAAIAAghIAIAAIAhhIIANAAIAhBIIAJAAIAAAhgAgVAUIArAAIgWgxg");
	this.shape_13.setTransform(-4.95,9.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgQAtIAKgXIgihBIAUAAIAWAuIAVguIASAAIgoBYg");
	this.shape_14.setTransform(-12.25,9.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AANAtIAAgjIgXAjIgTAAIAZgiQgKAAgIgIQgGgFAAgMQAAgOAIgHQAIgJAQABIAaAAIAABYgAgIgYQgEAEAAAGQAAAHAEACQAEAEAIAAIAJAAIAAgbIgJAAQgIAAgEAEg");
	this.shape_15.setTransform(-23.025,9.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAYAtIgYhCIgXBCIgSAAIAjhYIANAAIAjBYg");
	this.shape_16.setTransform(-30.775,9.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAgA1IAAgRIg/AAIAAARIgRAAIAAghIAJAAIAhhIIAOAAIAgBIIAIAAIAAAhgAgVAUIArAAIgWgxg");
	this.shape_17.setTransform(-40,9.875);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAMAtIgagnIAAAnIgRAAIAAhZIARAAIAAAnIAagnIAUAAIggAsIAgAtg");
	this.shape_18.setTransform(49.725,-6.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgPAjQgMgLgDgRIgOAAIAAAlIgQAAIAAhYIAQAAIAAAkIAPAAQADgQANgLQANgKAPAAQAUAAANANQANAOAAASQAAAUgNANQgNANgUAAQgRAAgNgLgAgFgUQgJAIAAAMQAAAMAJAJQAIAJAMAAQANAAAIgJQAJgIAAgNQAAgMgJgIQgIgJgNAAQgMAAgIAJg");
	this.shape_19.setTransform(39.225,-6.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAYAtIgYhBIgXBBIgSAAIAjhZIANAAIAjBZg");
	this.shape_20.setTransform(27.95,-6.95);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAUA3IAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYgAgOgqQgGgFgBgHIAOAAQAAAAAAABQABABAAAAQAAABAAAAQABABAAAAQADACACAAQADAAACgCQACgCABgCIANAAQAAAHgHAFQgFAFgJAAQgJAAgFgFg");
	this.shape_21.setTransform(16.425,-8.025);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAUAtIAAg+IgnA+IgQAAIAAhZIAQAAIAAA+IAng+IAQAAIAABZg");
	this.shape_22.setTransform(7.525,-6.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAMAtIgagnIAAAnIgRAAIAAhZIARAAIAAAnIAagnIAUAAIghAsIAhAtg");
	this.shape_23.setTransform(-0.35,-6.95);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AghAhQgNgNAAgUQAAgSANgOQAOgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgSAAgPgNgAgVgUQgJAIAAAMQAAANAJAIQAJAJAMAAQANAAAIgJQAJgJAAgMQAAgMgJgIQgIgJgNAAQgMAAgJAJg");
	this.shape_24.setTransform(-9.3759,-6.925);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgbAtIAAhZIAZAAQAOABAIAHQAIAIAAAMQAAAMgIAHQgHAIgPAAIgJAAIAAAigAgLgEIAKAAQAGAAADgDQAEgDAAgGQAAgGgEgDQgDgCgGAAIgKAAg");
	this.shape_25.setTransform(-17.525,-6.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAUAtIAAg+IgnA+IgQAAIAAhZIAQAAIAAA+IAng+IAQAAIAABZg");
	this.shape_26.setTransform(-25.625,-6.95);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgzAtIAAhZIARAAIAABIIAbAAIAAhIIAPAAIAABIIAcAAIAAhIIAQAAIAABZg");
	this.shape_27.setTransform(-36.05,-6.95);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAUAtIAAg+IgnA+IgQAAIAAhZIAQAAIAAA+IAng+IAQAAIAABZg");
	this.shape_28.setTransform(-49.275,-6.95);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAUA3IAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYgAgOgqQgFgEgCgIIAOAAQAAADADABQABACADAAQADAAACgCQADgBAAgDIAOAAQgCAHgFAFQgGAFgJAAQgIAAgGgFg");
	this.shape_29.setTransform(26.125,-24.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhYIAQAAIAAA+IAng+IAQAAIAABYg");
	this.shape_30.setTransform(17.225,-22.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAMAsIgbgmIAAAmIgQAAIAAhYIAQAAIAAAnIAbgnIAUAAIghAsIAhAsg");
	this.shape_31.setTransform(9.375,-22.95);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AggAhQgOgNAAgUQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAAUgOANQgNANgUAAQgTAAgNgNgAgVgUQgIAIAAAMQAAANAIAIQAJAJAMAAQANAAAJgJQAIgIAAgNQAAgMgIgIQgJgJgNAAQgMAAgJAJg");
	this.shape_32.setTransform(0.325,-22.925);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgeAhQgNgNAAgUQAAgTANgNQAOgNASAAQAOAAALAHQALAHAGANIgTAAQgEgFgGgDQgFgDgHAAQgMAAgJAJQgJAJAAALQAAAMAJAJQAJAJAMAAQAHAAAEgCQAGgCAEgGIATAAQgGANgKAGQgLAHgOAAQgSAAgOgNg");
	this.shape_33.setTransform(-9.325,-22.925);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAaAsIAAhYIAQAAIAABYgAgpAsIAAhYIAQAAIAAAjIANAAQANAAAIAHQAIAHAAAMQAAANgIAHQgIAHgNAAgAgZAcIAOAAQAFAAAEgDQACgCAAgGQAAgFgCgDQgEgDgFAAIgOAAg");
	this.shape_34.setTransform(-19.125,-22.95);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgcAsIAAhYIAWAAQAOAAAIAHQAHAGAAALQAAAGgCAFQgEAEgDACQAHACAEAFQAEAGAAAHQAAANgJAHQgKAIgQgBgAgLAcIAKAAQAGAAAEgDQADgDAAgFQAAgFgDgDQgEgDgGAAIgKAAgAgLgJIAHAAQAEAAAEgCQADgEAAgEQAAgDgDgDQgEgCgEgBIgHAAg");
	this.shape_35.setTransform(-27.425,-22.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2_Слой_1, null, null);


(lib.t1_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHAsIAAhIIgRAAIAAgPIAxAAIAAAPIgRAAIAABIg");
	this.shape.setTransform(47.475,24);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgQAsIAKgWIgihBIAUAAIAXAuIAUguIASAAIgoBXg");
	this.shape_1.setTransform(40.75,24);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAQAsIAAglIgfAAIAAAlIgRAAIAAhXIARAAIAAAjIAfAAIAAgjIARAAIAABXg");
	this.shape_2.setTransform(32.475,24);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAUAsIAAg9IgnA9IgQAAIAAhXIAQAAIAAA9IAng9IAQAAIAABXg");
	this.shape_3.setTransform(23.925,24);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAfAsIAAhBIgYBBIgNAAIgYhBIAABBIgQAAIAAhXIAWAAIAYBCIAYhCIAXAAIAABXg");
	this.shape_4.setTransform(14,24);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgTAtIATgeIgBAAIgDAAQgKAAgIgIQgIgHAAgNQAAgNAJgJQAIgJANAAQANAAAJAJQAJAJAAANQAAAGgCAFIgGAMIgXAjgAgKgZQgEAFAAAHQAAAHAFAEQADADAGAAQAHAAAEgDQAEgFAAgGQAAgHgEgFQgEgEgHAAQgGAAgEAEg");
	this.shape_5.setTransform(2.275,23.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgUAmQgIgJgCgMIAQAAQABAGAFAEQAEADAEAAQAHAAAEgEQADgEAAgIQAAgHgDgEQgEgEgHAAQgCAAgEACQgEACgBACIgOgEIAIgtIAoAAIgBAOIgbAAIgDARIAFgCIAFAAQANgBAHAKQAJAHgBANQAAANgIAKQgJAIgNABQgMgBgIgHg");
	this.shape_6.setTransform(-4.6,24.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAPIgeAAIAAAVIAdAAIAAAPIgdAAIAAAVIAeAAIAAAPg");
	this.shape_7.setTransform(-13.625,24);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAPIgfAAIAAAVIAeAAIAAAPIgeAAIAAAVIAfAAIAAAPg");
	this.shape_8.setTransform(-19.85,24);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAQAsIAAglIgfAAIAAAlIgRAAIAAhXIARAAIAAAjIAfAAIAAgjIARAAIAABXg");
	this.shape_9.setTransform(-27.125,24);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgXAsIAAhXIAvAAIAAAPIgeAAIAAAVIAdAAIAAAPIgdAAIAAAVIAeAAIAAAPg");
	this.shape_10.setTransform(-34.275,24);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAfAsIAAhBIgYBBIgNAAIgXhBIAABBIgRAAIAAhXIAWAAIAYBCIAZhCIAWAAIAABXg");
	this.shape_11.setTransform(-43,24);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgPAjQgNgMgCgQIgOAAIAAAlIgQAAIAAhYIAQAAIAAAkIAPAAQADgQANgLQANgKAPAAQATAAAOANQANAOAAASQAAATgNAOQgOANgTAAQgRAAgNgLgAgFgUQgJAIAAAMQAAAMAJAJQAIAJAMAAQAMAAAJgJQAJgJAAgMQAAgMgJgIQgJgJgMAAQgMAAgIAJg");
	this.shape_12.setTransform(71.075,8.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgcAtIAAhYIAQAAIAAAiIAMAAQAPAAAGAHQAIAHAAAMQABANgJAHQgIAIgNAAgAgMAcIAMAAQAGAAADgCQAEgEAAgFQAAgFgEgDQgDgEgGAAIgMAAg");
	this.shape_13.setTransform(60.95,8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgIAtIAAhIIgQAAIAAgQIAxAAIAAAQIgRAAIAABIg");
	this.shape_14.setTransform(54.65,8);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgeAhQgNgOAAgTQAAgSANgOQAOgNATAAQANAAAMAHQAKAHAGANIgTAAQgEgFgGgDQgFgDgHAAQgMAAgJAJQgJAJABALQAAAMAJAJQAIAJAMAAQAGAAAFgCQAHgCADgGIATAAQgFALgLAIQgLAHgNAAQgTAAgOgNg");
	this.shape_15.setTransform(47.5,8.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgUQgIAIAAAMQAAAMAIAJQAJAJAMAAQANAAAJgJQAIgJAAgMQAAgMgIgIQgJgJgNAAQgMAAgJAJg");
	this.shape_16.setTransform(37.725,8.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAQAtIAAgmIgfAAIAAAmIgRAAIAAhYIARAAIAAAjIAfAAIAAgjIAQAAIAABYg");
	this.shape_17.setTransform(28.6,8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgdAtIAAhYIARAAIAAAiIANAAQAOAAAHAHQAIAGAAANQAAANgIAHQgJAIgMAAgAgMAcIANAAQAFAAAEgCQADgEAAgFQAAgGgDgCQgEgEgFAAIgNAAg");
	this.shape_18.setTransform(21.3,8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAYAtIgYhCIgXBCIgSAAIAjhYIANAAIAjBYg");
	this.shape_19.setTransform(13.225,8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgXAtIAAhYIAvAAIAAAQIgeAAIAAAUIAcAAIAAAPIgcAAIAAAUIAeAAIAAARg");
	this.shape_20.setTransform(5.875,8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgHAtIAAhIIgQAAIAAgQIAvAAIAAAQIgQAAIAABIg");
	this.shape_21.setTransform(0.15,8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAUAtIAAg+IgnA+IgQAAIAAhYIAQAAIAAA9IAng9IAQAAIAABYg");
	this.shape_22.setTransform(-6.825,8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAiAtIgagoIAAAoIgPAAIAAgoIgaAoIgUAAIAggtIgfgrIATAAIAaAmIAAgmIAPAAIAAAmIAagmIATAAIgfArIAgAtg");
	this.shape_23.setTransform(-16.925,8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAYAtIgYhCIgXBCIgSAAIAjhYIANAAIAjBYg");
	this.shape_24.setTransform(-26.875,8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgUQgIAIAAAMQAAAMAIAJQAJAJAMAAQANAAAJgJQAIgIAAgNQAAgMgIgIQgJgJgNAAQgMAAgJAJg");
	this.shape_25.setTransform(-36.225,8.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAgA1IAAgRIg/AAIAAARIgRAAIAAghIAJAAIAhhIIANAAIAhBIIAJAAIAAAhgAgVAUIArAAIgVgxg");
	this.shape_26.setTransform(-46.2,8.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgUQgIAIAAAMQAAANAIAIQAJAJAMAAQANAAAIgJQAJgJAAgMQAAgMgJgIQgIgJgNAAQgMAAgJAJg");
	this.shape_27.setTransform(-56.1259,8.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgbAtIAAhYIAZAAQAOAAAIAHQAIAIAAAMQAAAMgIAHQgHAHgPAAIgJAAIAAAjgAgLgEIAKAAQAGAAADgDQADgCABgHQAAgGgEgDQgDgCgGAAIgKAAg");
	this.shape_28.setTransform(-64.275,8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AARAtIAAhIIggAAIAABIIgRAAIAAhYIBAAAIAABYg");
	this.shape_29.setTransform(-72,8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AAeAsIAAhBIgXBBIgNAAIgYhBIAABBIgQAAIAAhYIAWAAIAYBEIAYhEIAXAAIAABYg");
	this.shape_30.setTransform(28.7,-8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AAeAsIAAhBIgXBBIgNAAIgXhBIAABBIgRAAIAAhYIAWAAIAYBEIAZhEIAWAAIAABYg");
	this.shape_31.setTransform(17.65,-8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAZAsIgJgXIgfAAIgJAXIgSAAIAlhYIALAAIAlBYgAgJAGIATAAIgKgZg");
	this.shape_32.setTransform(7.7,-8);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgbAsIAAhYIAYAAQAPABAIAHQAIAHAAANQAAAMgIAHQgIAHgPAAIgIAAIAAAigAgLgEIAKAAQAGAAADgDQAEgEAAgFQAAgGgEgDQgDgCgGAAIgKAAg");
	this.shape_33.setTransform(1.175,-8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgVAsIAAhYIArAAIAAARIgbAAIAABHg");
	this.shape_34.setTransform(-4.725,-8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AggAhQgOgOAAgTQAAgSAOgOQANgNATAAQAUAAANANQAOAOAAASQAAATgOAOQgNANgUAAQgTAAgNgNgAgVgUQgIAIgBAMQABAMAIAJQAJAJAMAAQANAAAIgJQAKgJgBgMQABgMgKgIQgIgJgNAAQgMAAgJAJg");
	this.shape_35.setTransform(-12.8,-7.975);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgbAsIAAhYIAZAAQAOABAIAHQAIAHAAANQAAAMgIAHQgIAHgOAAIgJAAIAAAigAgLgEIAKAAQAGAAADgDQAEgDAAgGQAAgGgEgDQgDgCgGAAIgKAAg");
	this.shape_36.setTransform(-20.925,-8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAQAsIAAhHIgfAAIAABHIgQAAIAAhYIA/AAIAABYg");
	this.shape_37.setTransform(-28.65,-8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAVAsIgVgeIgUAeIgTAAIAegsIgegsIATAAIAUAgIAVggIATAAIgeAsIAeAsg");
	this.shape_38.setTransform(51.925,-24);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAaAsIAAhYIAQAAIAABYgAgpAsIAAhYIAQAAIAAAjIAOAAQANAAAHAHQAIAHAAAMQAAANgIAHQgIAHgMAAgAgZAcIAOAAQAGAAADgDQADgDAAgFQgBgGgCgCQgDgEgGABIgOAAg");
	this.shape_39.setTransform(42.775,-24);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgbAsIAAhYIAZAAQAOAAAIAIQAIAHAAANQAAAMgIAHQgIAIgOgBIgJAAIAAAigAgLgEIAKAAQAGAAADgDQAEgDAAgGQAAgGgEgDQgDgDgGAAIgKAAg");
	this.shape_40.setTransform(34.675,-24);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgHAsIAAhIIgRAAIAAgQIAxAAIAAAQIgRAAIAABIg");
	this.shape_41.setTransform(28.525,-24);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgeAhQgNgOAAgTQAAgSANgOQAOgNATAAQANAAALAHQALAHAGANIgTAAQgDgFgHgDQgGgDgGAAQgMAAgJAJQgIAIAAAMQAAANAIAIQAJAJAMAAQAFAAAGgCQAGgCAEgGIATAAQgFALgLAIQgLAHgOAAQgSAAgOgNg");
	this.shape_42.setTransform(21.375,-23.975);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAaAsIAAhYIAQAAIAABYgAgpAsIAAhYIAQAAIAAAjIANAAQAOAAAHAHQAIAHAAAMQAAANgIAHQgIAHgNAAgAgZAcIAOAAQAFAAAEgDQACgDAAgFQAAgFgCgDQgEgEgFABIgOAAg");
	this.shape_43.setTransform(11.575,-24);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgdAsIAAhYIAzAAIAAAQIgjAAIAAATIAOAAQAOAAAIAIQAHAHAAALQAAANgIAHQgIAHgNAAgAgNAcIAOAAQAGAAADgDQAEgDgBgFQAAgEgDgEQgDgCgGgBIgOAAg");
	this.shape_44.setTransform(3.15,-24);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgTAtIATgeIgBAAIgDAAQgLAAgHgIQgIgHAAgNQAAgOAJgIQAIgJANAAQAOAAAIAJQAJAJAAANQAAAGgCAFQgCAEgFAIIgWAjgAgKgZQgEAEAAAIQAAAHAEAEQAEADAGAAQAGAAAFgDQAEgFAAgGQAAgHgEgFQgFgEgGAAQgGAAgEAEg");
	this.shape_45.setTransform(-6.825,-24.075);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AAVAsIgVgeIgUAeIgTAAIAegsIgegsIATAAIAUAgIAVggIATAAIgfAsIAfAsg");
	this.shape_46.setTransform(-17.025,-24);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAaAsIAAhYIAQAAIAABYgAgpAsIAAhYIAQAAIAAAjIANAAQAOAAAHAHQAIAHAAAMQAAANgIAHQgIAHgNAAgAgZAcIANAAQAGAAAEgDQACgDAAgFQAAgFgCgDQgEgEgGABIgNAAg");
	this.shape_47.setTransform(-26.175,-24);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAZAsIgZhAIgXBAIgTAAIAkhYIANAAIAkBYg");
	this.shape_48.setTransform(-35.55,-24);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgXAsIAAhYIAvAAIAAAQIgfAAIAAAVIAeAAIAAAPIgeAAIAAAUIAfAAIAAAQg");
	this.shape_49.setTransform(-42.9,-24);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAVA1IAAgRIg6AAIAAhYIARAAIAABIIAfAAIAAhIIARAAIAABIIAKAAIAAAhg");
	this.shape_50.setTransform(-49.925,-23.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1_Слой_1, null, null);


(lib.p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._4();
	this.instance.parent = this;
	this.instance.setTransform(0,30);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p4, new cjs.Rectangle(0,30,176,159), null);


(lib.p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._3();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p3, new cjs.Rectangle(0,0,135,300), null);


(lib.p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p2, new cjs.Rectangle(0,0,135,300), null);


(lib.p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.p1, new cjs.Rectangle(0,0,135,300), null);


(lib.Монтажный_кадр_1_bg_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00A7E0").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,149.9996,1,1.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(385));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// bg
	this.instance = new lib.logo();
	this.instance.parent = this;
	this.instance.setTransform(184,24);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApGBTQgqgmAYg4QAWgzBGgdQBNghB+AAQAcABAaADIAgAEIANADIgSAgQglgLgjAAQhAAAg0ATQhGAZgLAyQgHAeAWAaQAcAiA9gCQAUgBAkgNQAtgQAbgUIA/g3QAGgFAHgDIAMgDIAGgBIBEAAIAWBeIArhdIBLAAIArBIIAhhIIBEAAIg8CDIhHAAIgthLIgiBLIgrAAIAAABIhRAAIgEgXIhKAAIgZAWIgwAAQg5AUhJAAQhqAAgugqgAjHA4IAsgBIgEglgAGHB2IAsgsIgshkIBEAAIATA2IA3g3IBNABIiFCEIgEAEQgFAEgDABIgQADgAD+BpIhvAAIA9iDIBvAAQA2AAATAaQAQATgMAbQgMAYgcAQQgkATg7AAIgDAAgADpBIIATAAQBBAAAJgjQAFgSgRgIQgMgFgUAAIgUAAg");
	this.shape.setTransform(217.5237,223.7246);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAVIgFgCQAAAAgBgBQAAAAgBgBQAAAAAAgBQAAAAgBgBIgBgEIACgBIACAAIABABIACACIABACIACABIADACIAEgCIADgBIABgDIABgCIgBgEIgBgCIgDgCIgFAAIAAgEIAEAAIADgCIABgCIABgDIgBgDIgBgCIgCgBIgDgBIgCABIgCABIgCACIgBADIgCABIgBAAIgDAAQAAgEABgCIADgDIAFgDIAEgBIAFABIAEADIADADIABAEIgBAEQAAAAAAABQAAAAAAABQgBAAAAAAQAAAAAAAAIgDACIgDACQAFAAACADQABACAAAFIAAAFIgDAEIgFACIgGABg");
	this.shape_1.setTransform(271.9,282);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEAWIgEgBIgCgCIgDgCIACgCIACgBIAFADIAEAAIADgBIADgCIACgDIAAgEIAAgDIgCgDIgDgBIgDAAIgHAAIgDAAIADgVIAUAAIAAADIgBACIgDABIgMAAIgCALIAFgBIAGABIAEADIADADIABAFIgBAGQgCAEgCABQgBACgDABIgGABg");
	this.shape_2.setTransform(268.425,282.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAFAWIAAgMIgSAAIgCgBIAAgDIAUgbIAFAAIAAAbIAGAAIAAAEIgGAAIAAAMgAgJAGIAOAAIAAgUg");
	this.shape_3.setTransform(264.925,282.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgFAVIgFgEIgEgHIgBgKIABgIIAEgHIAFgFIAFgBQAEAAACABIAFAFIADAHQACAEAAAEQAAAGgCAEIgDAHQgCACgDACIgGABIgFgBgAgDgPQAAAAgBAAQAAABgBAAQAAAAAAABQgBAAAAAAIgCAGIgBAHIABAJIACAEQAAABABABQAAAAAAAAQABABAAAAQABAAAAAAIADACIAEgCIADgDIACgEIABgJIgBgHIgCgGIgDgCIgEgBg");
	this.shape_4.setTransform(261.525,282);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgKAWIARgjIACgCIgVAAIgBgBIgBgBIAAgEIAdAAIAAADIgBACIgRAkIgBABIgCABg");
	this.shape_5.setTransform(258.075,282.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAVQgEgCgBgCIgEgHIAAgKIAAgIIAEgHIAFgFQADgBACAAIAGABIAFAFIADAHIABAIIgBAKIgDAHIgFAEIgGABIgFgBgAgDgPIgDACIgCAGIgBAHIABAJIACAEQAAABABABQAAAAABAAQAAABABAAQAAAAAAAAIADACIADgCQABAAAAAAQABAAAAgBQABAAAAAAQABgBAAgBIACgEIABgJIgBgHIgCgGIgEgCIgDgBg");
	this.shape_6.setTransform(254.55,282);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgFAVQgDgBgCgCQgBgCgBgDIgBgGIABgGIADgGIAKgOIACgBIACgBIAEAAIgLARIgBABIgBABQAAAAAAAAQABgBAAAAQABAAAAAAQABAAAAAAIADgBIAEABIAFACIADADIABAGIgBAFQgBADgDACIgEADIgGABIgFgBgAgDAAIgCACIgDADIAAADIAAAEIACADIADACIADAAIAEAAIACgCIACgDIABgEIgBgDIgCgDIgCgCIgEAAg");
	this.shape_7.setTransform(251.1,282.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgIAWIALgSIACgBIABgBIgEABIgDABIgFgBIgDgCIgDgDIgBgFIABgGIADgEIAEgDIAGgBIAFABIAEADIADAEIABAGIAAAEIgBADIgNAUIgBABIgCABgAgDgPIgCABIgCADIAAAEQAAADACACQADACACAAIADAAIAEgCIABgDIABgCIgBgEIgBgDIgEgBIgDgBg");
	this.shape_8.setTransform(247.55,282);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKAWIARgjIACgCIgVAAIgCgBIAAgFIAdAAIAAAFIgRAkIgEACg");
	this.shape_9.setTransform(244.15,282.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgKAWIARgjIACgCIgVAAIgBgBIgBgBIAAgEIAdAAIAAADIgBACIgRAkIgBABIgCABg");
	this.shape_10.setTransform(240.675,282.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAFAWIAAgMIgSAAIgCgBIAAgDIAUgbIAFAAIAAAbIAGAAIAAAEIgGAAIAAAMgAgJAGIAOAAIAAgUg");
	this.shape_11.setTransform(237.075,282.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgFAVIgFgEIgEgHIgBgKIABgIIAEgHIAFgFIAFgBQADAAADABIAFAFQADADAAAEQACAEAAAEQAAAGgCAEQAAADgDAEIgFAEIgGABIgFgBgAgDgPQAAAAgBAAQAAABAAAAQgBAAAAABQAAAAgBAAIgCAGIgBAHIABAJIACAEQABABAAABQAAAAABAAQAAABAAAAQABAAAAAAIADACIAEgCIADgDIACgEIABgJIgBgHIgCgGIgDgCIgEgBg");
	this.shape_12.setTransform(233.675,282);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgJAWIAAgFIAJAAIAAgeIgIAGIAAABIgBAAIgBgBIgCgDIAMgLIAFAAIAAAmIAIAAIAAAFg");
	this.shape_13.setTransform(230.2,282.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AALAWIAAgUIgVAAIAAAUIgHAAIAAgrIAHAAIAAAUIAVAAIAAgUIAHAAIAAArg");
	this.shape_14.setTransform(224.625,282.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgNAWIAAgrIAMAAIAGABIAGADIACAEIABAGIgBAFQAAACgCACIgGADIgGABIgGAAIAAAQgAgHABIAGAAIAEgBIADgBIABgDIABgDIgBgEIgBgCIgDgCIgEgBIgGAAg");
	this.shape_15.setTransform(220.7,282.025);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgMAWIAAgrIAZAAIAAAFIgTAAIAAAmg");
	this.shape_16.setTransform(217.3,282.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgIAUQgEgCgCgCQgDgDgCgEQgBgDAAgGQAAgDABgEIAFgHQACgDAEgCQAFgCADAAQAEAAAFACQAEACACADQAEADABAEQABAEAAADQAAAGgBADQgBAEgEADQgCACgEACQgEACgFAAQgEAAgEgCgAgFgOIgFADQgCADgBADQgBACAAADQAAAEABADQABADACACQACADADAAIAFACQADAAADgCQADgBACgCQACgCABgDIABgHIgBgFQgBgDgCgDIgFgDIgGgBg");
	this.shape_17.setTransform(213.075,282);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgEAWIgEgBIgDgCIgCgCIACgCIABgBIACABIAEACIAEAAIACgBIADgCIACgDIABgEIgBgDIgBgDIgDgBIgDAAIgHAAIgEAAIAEgVIATAAIAAADIAAACIgDABIgMAAIgCALIAFgBIAGABIAEADIADADIABAFIgBAGQgCAEgCABQgCACgDABIgFABg");
	this.shape_18.setTransform(207.375,282.025);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgKAWIAAgFIAKAAIAAgeIgIAGIgBABIAAAAIgBgBIgCgDIAMgLIAFAAIAAAmIAIAAIAAAFg");
	this.shape_19.setTransform(203.95,282.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgFAVIgFgEQgDgEAAgDQgCgEAAgGQAAgEACgEQAAgEADgDIAFgFQADgBACAAIAGABIAFAFIAEAHIABAIIgBAKIgEAHIgFAEIgGABIgFgBgAgDgPIgDACIgCAGIgBAHIABAJIACAEIADADIADACIAEgCQAAAAABAAQAAAAABgBQAAAAAAAAQABgBAAgBIACgEIABgJIgBgHIgCgGQgBAAAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAIgEgBg");
	this.shape_20.setTransform(200.425,282);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgOAWIAAgDIARgSIACgDIACgDIAAgDIAAgEIgCgCIgCgBIgDgBIgCABIgCABIgCACIgBADIgBABIgCAAIgDAAQABgEABgCIADgDIAEgDIAFgBIAEABIAFADQAAAAABAAQAAABABAAQAAABAAAAQAAABAAAAIABAGIgBADIgBAFIgDACIgNAPIACgBIAPAAIACABIAAACIAAADg");
	this.shape_21.setTransform(196.95,282);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgJAWIAAgFIAJAAIAAgeIgIAGIAAABIgBAAIgBgBIgCgDIAMgLIAFAAIAAAmIAIAAIAAAFg");
	this.shape_22.setTransform(193.5,282.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgFAWIgDgBIgDgCIgCgCIACgCIABgBIACABIAEACIADAAIADgBIADgCIACgDIABgEIgBgDIgBgDIgDgBIgDAAIgHAAIgEAAIAEgVIATAAIAAADIAAACIgDABIgMAAIgCALIAFgBIAGABIAEADIADADIABAFIgBAGQgCAEgCABQgCACgDABIgFABg");
	this.shape_23.setTransform(189.975,282.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAFAWIAAgMIgSAAIgBAAIgBgBIAAgDIAUgbIAFAAIAAAbIAGAAIAAADIAAABIgGAAIAAAMgAgJAGIAOAAIAAgSIAAgCg");
	this.shape_24.setTransform(186.475,282.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgFAVIgFgEIgDgHQgCgEAAgGQAAgEACgEIADgHIAFgFQADgBACAAIAGABIAFAFIAEAHIABAIIgBAKIgEAHIgFAEIgGABIgFgBgAgDgPIgDACIgCAGIgBAHIABAJIACAEIADADIADACIAEgCIADgDIACgEIABgJIgBgHIgCgGIgDgCIgEgBg");
	this.shape_25.setTransform(183.025,282);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgKAWIARgjIACgCIgWAAIgBgBIAAgFIAcAAIAAAFIgRAkIgDACg");
	this.shape_26.setTransform(179.6,282.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgKAWIARgjIACgCIgVAAIgBgBIgBgBIAAgEIAdAAIAAADIgBACIgRAkIgBABIgCABg");
	this.shape_27.setTransform(176.125,282.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AALAWIAAgUIgVAAIAAAUIgGAAIAAgrIAGAAIAAAUIAVAAIAAgUIAHAAIAAArg");
	this.shape_28.setTransform(170.5,282.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AALAWIAAgUIgVAAIAAAUIgHAAIAAgrIAHAAIAAAUIAVAAIAAgUIAHAAIAAArg");
	this.shape_29.setTransform(165.925,282.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AALAWIAAggIAAgDIgBACIgTAfIgBABIgCABIgFAAIAAgrIAHAAIAAAgIgBADIACgCIAAgDIATgcIABgBIACgBIAEAAIAAArg");
	this.shape_30.setTransform(161.35,282.025);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgFAVIgFgCIgDgEIAAgFQAAgEABgDQADgDAEAAQgEgBgCgDQgBgCAAgDIABgFIACgDIAFgDIAEgBIAFABIAFADIACADIABAFQAAADgBACIgGAEQAEAAADADQABADAAAEIgBAFIgCAEIgFACIgGABgAgDACIgCABIgCADIgBAEIABADIACACIACACIADABIAEgBIACgCIACgCIAAgDIAAgEIgCgDIgCgBIgEgBgAgDgQIgBABIgCADIAAADIAAACIABADIACABIADABIAEgBIACgBIABgDIAAgCIAAgDIgCgDIgBgBIgEAAg");
	this.shape_31.setTransform(253.55,274);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgBAEIgCgCIAAgCIABgCIABgBIADAAIABABIABACIAAACIgCACg");
	this.shape_32.setTransform(249.575,275.825);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AANAUIAAgKIgYAAIAAAJIgBABIgBAAIgEAAIAAgOIACAAIACgBIACgBIABgDIACgEIACgQIASAAIAAAZIAGAAIAAANIgBABIgBAAgAgCgHIgDAKIgCADIAOAAIAAgVIgJAAg");
	this.shape_33.setTransform(246.975,275.175);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgCAGIAAAAIAAgBIABgBIABgDIAAgBIAAAAIgCgBIAAgBIgBgBIABgDIACgBIACABIABAAIABACIAAAEIgDAFIgCADg");
	this.shape_34.setTransform(242.925,276.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAHAWIAAgVIABgBIAAAAIgBABIgBABIgNASIgBABIgBABIgDAAIAAgeIAGAAIAAATIgBACIAAABIABgCIABgBIANgRIABgBIABgBIADAAIAAAegAgCgNIgDgBIgCgCIgBgDIABgBIABgBIADAAIAAADIABABIABABIABABIACgBIACgBIAAgBIABgDIADAAIABABIAAABIAAADIgCACIgDABIgEABg");
	this.shape_35.setTransform(240.525,274.025);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgGACIAAgDIANAAIAAADg");
	this.shape_36.setTransform(237.675,274.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgNAWIAAgCIAAgBIABgBIAMgPIAEgCIADgGIAAgDIAAgEIgBgCIgDgBIgDgBIgBABIgDABIgCACIgBADIgBABIgCAAIgCAAQAAgDABgDIADgDIAFgDIADgBIAGABIAEADIADADIABAGIgBADIgCAFIgDACIgOAPIADAAIAQAAIABAAIABACIAAADg");
	this.shape_37.setTransform(234.8,274);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAHAWIAAgVIABgBIAAAAIgBABIgBABIgNASIgBABIgBABIgDAAIAAgeIAGAAIAAATIgBACIAAABIABgCIABgBIANgRIABgBIABgBIADAAIAAAegAgCgNIgDgBIgCgCIgBgDIABgBIABgBIADAAIAAADIABABIABABIABABIACgBIACgBIAAgBIABgDIADAAIABABIAAABIAAADIgCACIgDABIgEABg");
	this.shape_38.setTransform(229.825,274.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AAHAPIAAgUIABgCIgBABIgBABIAAABIgNASIgBABIgBAAIgDAAIAAgdIAFAAIAAAVIACgDIACgCIACgCIAJgNIAAgBIACAAIADAAIAAAdg");
	this.shape_39.setTransform(226.375,274.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAJAPIgCAAIgBgCIgGgJQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgCgBIgDAAIAAAOIgGAAIAAgdIAGAAIAAANIACAAIADgBIABgBIAFgKIACgBIAGAAIgIALIgCACIgCABIADAAIACACIAHANg");
	this.shape_40.setTransform(223.225,274.675);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AABAQIgEgBIgFgEIgCgEIgBgHIAAgGIADgEIAFgEIAFgBIAGABIAEAEIgBABIgBABIgBAAIgBgBIgBAAIgCgBIgDAAIgDABIgCACIgCAEIgBADIABAFIACADIACACIADABIADAAIACgBIACgBIABgBIABABIABACIgCACIgDACIgDABg");
	this.shape_41.setTransform(220.125,274.65);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AAHAPIAAgOIgNAAIAAAOIgGAAIAAgdIAGAAIAAAMIANAAIAAgMIAGAAIAAAdg");
	this.shape_42.setTransform(216.925,274.675);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAHAPIAAgUIABgCIgBABIgBABIAAABIgNASIgBABIgBAAIgDAAIAAgdIAFAAIAAAVIABgCIABgBIAEgEIAJgNIAAgBIACAAIADAAIAAAdg");
	this.shape_43.setTransform(213.525,274.675);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AASAUIAAgKIgoAAIAAgdIAFAAIAAAZIAMAAIAAgZIAFAAIAAAZIAMAAIAAgZIAGAAIAAAZIAFAAIAAAOIgBAAg");
	this.shape_44.setTransform(209.325,275.175);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgFAPIgFgEIgDgEIgBgHIABgGIADgEIAFgEIAFgBIAGABIAFAEIADAEIABAGIgBAHIgDAEIgFAEIgGABIgFgBgAgGgIQgCADAAAFQAAAGACACQACADAEAAQAFAAACgDQACgCAAgGQAAgFgCgDQgDgCgEAAQgDAAgDACg");
	this.shape_45.setTransform(204.875,274.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgNAWIAAgrIAMAAIAGABIAGADIADAEIAAAGIAAAFQgBACgCACIgGADIgGABIgHAAIAAAQgAgIABIAHAAIAEgBIADgBIACgDIAAgDIAAgEIgCgCIgDgCIgEgBIgHAAg");
	this.shape_46.setTransform(201.7,274.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAMAUIAAgKIgYAAIAAAJIAAABIgBAAIgEAAIAAgOIABAAIACgBIACgBIACgDQABgBAAgDIACgHIAAgJIATAAIAAAZIAGAAIAAANIgBABIgBAAgAgEgBIgBAEIgCADIANAAIAAgVIgIAAg");
	this.shape_47.setTransform(196.325,275.175);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgCAQIgDgBIgDgCIgDgCIACgCIABgBIABABIACABIADABIACAAIADAAIACgBIABgCIAAgCQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAAAgBIgFgBIgDAAIAAgCIADAAQACgBACgBQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBIAAgCIgCgBIgCgBIgCAAIgCAAIgCABIgCAAIgBABIgBAAIgBgBIgBgCIAFgDIAFgBIAFABIADACIACADIABACIgBAEIgCACIgCABQACAAACACQAAAAABABQAAAAAAABQAAAAAAABQABABAAABIgCADIgCADIgDACIgFABg");
	this.shape_48.setTransform(193.05,274.65);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AABAQIgFgBIgEgEQgDgCgBgCIgBgHIABgGIADgEIAEgEIAGgBIAFABIAEADIACAEIABAGIAAABIgUAAIABAFIABADIADACIAEABIADAAIACgBIACgBIACgBIABABIABACIgCACIgEACIgDABgAgEgJIgDAHIAQAAIgBgEIgCgCIgCgCIgDAAQgDAAgCABg");
	this.shape_49.setTransform(190.2,274.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgFAPQgDgBgBgDQgDgCgBgCIgBgHIABgGQABgCADgCQABgDADgBIAFgBIAGABQADABABADQADACAAACIACAGIgCAHQAAACgDACQgBADgDABIgGABIgFgBgAgGgIQgCAEAAAEQAAAFACADQACADAEAAQAFAAACgDQACgCAAgGQAAgFgCgDQgDgCgEAAQgDAAgDACg");
	this.shape_50.setTransform(186.9,274.65);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgMAVIAAgoIACAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAIAAAEIAFgFIAFgBIAEABQABABAAAAQABAAAAAAQABABAAAAQABABAAABQACABABADIABAHIgBAFIgDAFIgEAEIgGABIgDgBIgEgDIAAAOgAgDgOIgEADIAAAOIADACIAEABQAEAAACgDQABgCAAgFIAAgFIgBgEIgDgBIgDgBg");
	this.shape_51.setTransform(183.6,275.15);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AAKAWIAAgmIgUAAIAAAmIgGAAIAAgrIAhAAIAAArg");
	this.shape_52.setTransform(179.675,274.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgDAGIAAAAIACgCIAAgBIABgCIAAgBIgBAAIgCgCIAAgBIABgDIACgBIADABIABAEIgBACIgBACIgCADIgBADg");
	this.shape_53.setTransform(272.125,268.225);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AAKAQIgCgBIAAgBIgBgDIgCACIgDACIgCABIgDAAIgDgBIgDgBIgBgDIgBgEIABgDIADgDIAGgBIAIgBIAAgCQAAgDgCgDQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgDABIgCAAIgBABIgCABIgCgBIgBgCIAGgDIAFgCIAFABIADADIACADIABAFIAAATgAAAACIgDACIgCABIgBACIABACIABABIABABIACABIACgBIAEgCIACgBIAAgHg");
	this.shape_54.setTransform(269.825,266.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgLAPIAAgdIALAAIAEAAIAEACIACACIAAADIgBAEIgCACIgDABIAGABIACAFIgBAEIgDADQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAIgFABgAgFALIAFAAQABAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAgBAAAAQAAgBAAAAIAAgCIgBgBIgCgBIgDgBIgFAAgAgFgBIAFAAIACgBIACgBIABgBIAAgCIAAgCIgBgBIgCgBIgCgBIgFAAg");
	this.shape_55.setTransform(267.025,266.675);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AAJAPIgCAAIgBgCIgGgJQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAIgCgBIgDAAIAAAOIgGAAIAAgdIAGAAIAAANIACAAIADgBIABgBIAFgKIACgBIAGAAIgIALIgCACIgCABIADAAIACACIAHANg");
	this.shape_56.setTransform(264.025,266.675);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AABAQIgEgBIgFgEIgCgEIgBgHIAAgGIADgEIAFgDIAFgCIAGACIAEADIgBABIgBABIgBAAIgEgCIgDAAIgDABIgCACIgCAEIgBADIABAFIACADIACACIADABIADAAIACgBIACgBIABgBIABABIABACIgCACIgDACIgDABg");
	this.shape_57.setTransform(260.925,266.65);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgFAPQgCgBgDgDIgDgEIgBgHIABgGIADgEQADgDACAAQACgCADAAIAGACQADABACACIADAEIABAGIgBAHIgDAEQgCACgDACIgGABIgFgBgAgGgIQgCAFAAADQAAAFACADQACADAEAAQAFAAACgDQACgCAAgGQAAgFgCgDQgDgCgEAAQgDAAgDACg");
	this.shape_58.setTransform(257.725,266.65);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AARAWIAAghIgOAZIgBABIgCAAIgCgBIgOgaIAAAiIgGAAIAAgrIAFAAIABABIABABIAPAcIABgCIAPgaIABgBIABgBIAFAAIAAArg");
	this.shape_59.setTransform(253.325,266.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgBAEIgBgCIgBgCIABAAIABgCIAAgBIACAAIACABIABACIAAACIgBABIgCABg");
	this.shape_60.setTransform(248.3,267.825);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgJAPIAAgdIATAAIAAAEIgNAAIAAAZg");
	this.shape_61.setTransform(246.85,266.675);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgCAGIAAAAIAAgBIABgBIABgDIAAgBIAAAAIAAAAIgCgBIAAgBIgBgBIABgDIACgBIACABIABAAIABACIAAACIgBACIgBACIgBADIgCADg");
	this.shape_62.setTransform(243.225,268.225);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgIAWIAOgVIgEACIgDABIgFgBIgDgCIgDgDIgBgFQAAgDABgDIADgEIAFgCQACgCACAAIAGABIAEADIADAEIABAGIAAAEIgBADIgEAFIgJAPIgBABIgCABgAgCgQIgDACIgCADIAAADQAAAEACADQACABADAAIAEAAIACgBIACgEIABgDIgBgDIgCgDIgCgCIgEAAg");
	this.shape_63.setTransform(240.775,266);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgJAWIAAgFIAJAAIAAgeIgHAGIgBABIgBAAIgBgBIgCgDIAMgLIAEAAIAAAmIAJAAIAAAFg");
	this.shape_64.setTransform(237.35,266.025);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AAFAWIAAgMIgSAAIgBAAIAAgBIgBgDIAUgbIAFAAIAAAbIAGAAIAAAEIgGAAIAAAMgAgJAGIAOAAIAAgUg");
	this.shape_65.setTransform(233.775,266.025);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgEAWIgEgBIgCgCIgDgCIACgCIABgBIACABIAEACIAEAAIADgBIADgCIACgDIAAgEIAAgDIgCgDIgDgBIgDAAIgHAAIgDAAIADgVIAUAAIAAADIgBACIgDABIgMAAIgCALIAFgBIAGABIAEADIADADIABAFIgBAGQgCAEgCABQgBACgEABIgFABg");
	this.shape_66.setTransform(230.325,266.025);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgJAWIAAgFIAJAAIAAgeIgIAGIAAABIgBAAIgBgBIgCgDIAMgLIAFAAIAAAmIAIAAIAAAFg");
	this.shape_67.setTransform(226.9,266.025);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgJAWIAAgFIAJAAIAAgbIAAgDIgIAGIgBABIAAAAIgBgBIAAAAIgCgDIAMgLIAFAAIAAAmIAIAAIAAAFg");
	this.shape_68.setTransform(223.45,266.025);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAAALIAAgBIAAgBIAEgIIABgBIAAAAIgBgBIgEgHIAAgCIAAgBIACAAIAIALIAAAAIgIAMgAgIALIgBgBIABgBIAEgIIABgBIAAAAIgBgBIgEgHIgBgCIABgBIACAAIAHALIAAAAIgHAMg");
	this.shape_69.setTransform(218.875,266.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAAAEIgCgBIgBgBIAAgCIABgCIACgBIACAAIABABIABACIAAACIgCACg");
	this.shape_70.setTransform(216.825,267.825);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgMAWIAAgrIAZAAIAAAFIgSAAIAAAmg");
	this.shape_71.setTransform(215.3,266.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgBAEIgCgCIAAgCIABgCIABgBIADAAIABABIABACIAAACIgCACg");
	this.shape_72.setTransform(212.775,267.825);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AALAWIAAgUIgVAAIAAAUIgGAAIAAgrIAGAAIAAAUIAVAAIAAgUIAHAAIAAArg");
	this.shape_73.setTransform(209.75,266.025);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgBAEIgCgCIAAgCIABgCIABgBIACAAIACABIABACIgBACIAAABIgCABg");
	this.shape_74.setTransform(206.775,267.825);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgFAUQgFgCgCgCQgDgDAAgEQgCgDAAgGQAAgEACgEIADgHQADgDAEgBQAFgCADAAQAFAAADACIAGADIgCADIgBACIgCgCIgFgCIgEgBIgFABIgEAEIgEAFIgBAGQAAAEABAEQABACADACIAEAEIAFABIAGgBIADgBIABgCIABAAIAAgBIABABIADADQgDADgDABQgEACgFAAQgEAAgEgCg");
	this.shape_75.setTransform(204.15,266);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AALAWIAAgdIAAgDIAAgDIgCAEIgSAdIgBABIgCABIgFAAIAAgrIAHAAIAAAgIgBADIACgCIAAgDIATgcIABgBIACgBIAEAAIAAArg");
	this.shape_76.setTransform(198.25,266.025);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AARAbIAAgKIghAAIAAAIIgBABIgBABIgEAAIAAgPIAFAAIACgCIABgDIACgEIABgGIACgXIAZAAIAAAmIAHAAIAAANIgBABIgBABgAgGAAIgCAHIgCAFIAUAAIAAghIgNAAg");
	this.shape_77.setTransform(193.525,266.525);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AALAWIAAgUIgVAAIAAAUIgHAAIAAgrIAHAAIAAAUIAVAAIAAgUIAGAAIAAArg");
	this.shape_78.setTransform(188.9,266.025);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAQAWIgCgBIgBgBIgDgKIgTAAIgDAKIgBABIgBABIgFAAIARgrIAFAAIARArgAAAgMIAAACIgHAPIAPAAIgHgPIgBgFg");
	this.shape_79.setTransform(184.575,266.025);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAMAWIgCgBIgLgRIgCgCIgCAAIgFAAIAAAUIgGAAIAAgrIAGAAIAAATIAFAAIACgBIABgBIALgQIACgBIAFAAIgNASIgDADIACAAIADADIAMATg");
	this.shape_80.setTransform(180.775,266.025);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIAHgLIACAAIABABIAAACIgGAIIABABIAFAIIAAABIgBABIgCABgAgIAAIAAAAIAHgLIABAAIABABIAAACIgFAHIAAABIAAABIAFAIIAAABIgBABIgBABg");
	this.shape_81.setTransform(177.15,266.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgIAUQgEgCgCgCQgDgDgCgEQgBgDAAgGQAAgEABgEIAFgHQACgCAEgCQAFgCADAAQAEAAAFACQAEACACACQAEAEABADQABAEAAAEQAAAGgBADQgBAEgEADQgCACgEACQgEACgFAAQgEAAgEgCgAgFgPIgFAEQgCACgBADQgBADAAADQAAAEABADQABADACACQACADADABIAFABQADAAADgBQADgCACgCQACgCABgDIABgHIgBgGQgBgDgCgCIgFgEIgGgBg");
	this.shape_82.setTransform(171.975,266);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgIAUQgEgBgDgDIgEgHQgBgDAAgGQAAgEABgEIAEgHQADgDAEgBQAFgCADAAIAJACQADABADADQAEAEABADQABAEAAAEQAAAGgBADQgBAEgEADQgDADgDABIgJACQgEAAgEgCgAgFgPIgFAEIgDAFIgBAGIABAHIADAFQACADADABIAFABQADAAADgBIAFgEQACgCABgDIABgHIgBgGQgBgDgCgCIgFgEIgGgBg");
	this.shape_83.setTransform(167.175,266);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgIAUQgDgBgEgDIgEgHQgCgDABgGQgBgEACgEIAEgHIAHgEQAFgCADAAQAEAAAEACQAEABAEADIAEAHQACAEAAAEQAAAGgCADIgEAHQgEADgEABQgDACgFAAQgDAAgFgCgAgFgPIgFAEIgDAFIgBAGIABAHIADAFQADADACABQACABADAAQAEAAACgBQADgBACgDIADgFIABgHIgBgGIgDgFIgFgEIgGgBg");
	this.shape_84.setTransform(162.35,266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(385));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_Слой_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("A3W3WMAutAAAMAAAAutMgutAAAg");
	this.shape.setTransform(150,150);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(385));

}).prototype = p = new cjs.MovieClip();


(lib.t4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t4_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t4, new cjs.Rectangle(-42.4,-29.5,84.9,59), null);


(lib.t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t3_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t3, new cjs.Rectangle(-58.6,-36.6,117.2,73.30000000000001), null);


(lib.t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t2_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t2, new cjs.Rectangle(-52.9,-29.5,105.8,59.1), null);


(lib.t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.t1_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(1,0,1,1,0,0,0,1,0);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.t1, new cjs.Rectangle(-75.2,-28.6,152.4,57.3), null);


(lib.Монтажный_кадр_1_t4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t4
	this.instance = new lib.t4();
	this.instance.parent = this;
	this.instance.setTransform(215.35,123.95,0.8,0.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(285).to({_off:false},0).to({scaleX:1,scaleY:1,x:215.4,y:124,alpha:1},6,cjs.Ease.get(1)).wait(87).to({scaleX:0.8,scaleY:0.8,x:215.35,y:123.95,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t3
	this.instance = new lib.t3();
	this.instance.parent = this;
	this.instance.setTransform(215.4,123.95,0.8,0.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(190).to({_off:false},0).to({scaleX:1,scaleY:1,x:215.45,y:124,alpha:1},6,cjs.Ease.get(1)).wait(87).to({scaleX:0.8,scaleY:0.8,x:215.4,y:123.95,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t2
	this.instance = new lib.t2();
	this.instance.parent = this;
	this.instance.setTransform(215.35,123.95,0.8,0.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(95).to({_off:false},0).to({scaleX:1,scaleY:1,x:215.4,y:124,alpha:1},6,cjs.Ease.get(1)).wait(87).to({scaleX:0.8,scaleY:0.8,x:215.35,y:123.95,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_t1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// t1
	this.instance = new lib.t1();
	this.instance.parent = this;
	this.instance.setTransform(215.35,123.95,0.8,0.8);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:215.4,y:124,alpha:1},6,cjs.Ease.get(1)).wait(87).to({scaleX:0.8,scaleY:0.8,x:215.35,y:123.95,alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p4
	this.instance = new lib.p4();
	this.instance.parent = this;
	this.instance.setTransform(79.5,129.5,1,1,0,0,0,88,79.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(285).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(87).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p3
	this.instance = new lib.p3();
	this.instance.parent = this;
	this.instance.setTransform(67.5,125,1,1,0,0,0,67.5,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(190).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(89).to({alpha:0},6,cjs.Ease.get(1)).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p2
	this.instance = new lib.p2();
	this.instance.parent = this;
	this.instance.setTransform(67.5,125,1,1,0,0,0,67.5,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(95).to({_off:false},0).to({alpha:1},6,cjs.Ease.get(1)).wait(96));

}).prototype = p = new cjs.MovieClip();


(lib.Монтажный_кадр_1_p1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// p1
	this.instance = new lib.p1();
	this.instance.parent = this;
	this.instance.setTransform(67.5,125,1,1,0,0,0,67.5,125);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},6,cjs.Ease.get(1)).wait(96));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib._300x300 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_384 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(384).call(this.frame_384).wait(1));

	// Слой_2_obj_
	this.Слой_2 = new lib.Монтажный_кадр_1_Слой_2();
	this.Слой_2.name = "Слой_2";
	this.Слой_2.parent = this;
	this.Слой_2.setTransform(150,150,1,1,0,0,0,150,150);
	this.Слой_2.depth = 0;
	this.Слой_2.isAttachedToCamera = 0
	this.Слой_2.isAttachedToMask = 0
	this.Слой_2.layerDepth = 0
	this.Слой_2.layerIndex = 0
	this.Слой_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_2).wait(385));

	// p4_obj_
	this.p4 = new lib.Монтажный_кадр_1_p4();
	this.p4.name = "p4";
	this.p4.parent = this;
	this.p4.depth = 0;
	this.p4.isAttachedToCamera = 0
	this.p4.isAttachedToMask = 0
	this.p4.layerDepth = 0
	this.p4.layerIndex = 1
	this.p4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.p4).wait(385));

	// p3_obj_
	this.p3 = new lib.Монтажный_кадр_1_p3();
	this.p3.name = "p3";
	this.p3.parent = this;
	this.p3.depth = 0;
	this.p3.isAttachedToCamera = 0
	this.p3.isAttachedToMask = 0
	this.p3.layerDepth = 0
	this.p3.layerIndex = 2
	this.p3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.p3).wait(291).to({_off:true},1).wait(93));

	// p2_obj_
	this.p2 = new lib.Монтажный_кадр_1_p2();
	this.p2.name = "p2";
	this.p2.parent = this;
	this.p2.depth = 0;
	this.p2.isAttachedToCamera = 0
	this.p2.isAttachedToMask = 0
	this.p2.layerDepth = 0
	this.p2.layerIndex = 3
	this.p2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.p2).wait(101).to({_off:true},96).wait(188));

	// p1_obj_
	this.p1 = new lib.Монтажный_кадр_1_p1();
	this.p1.name = "p1";
	this.p1.parent = this;
	this.p1.setTransform(67.5,150,1,1,0,0,0,67.5,150);
	this.p1.depth = 0;
	this.p1.isAttachedToCamera = 0
	this.p1.isAttachedToMask = 0
	this.p1.layerDepth = 0
	this.p1.layerIndex = 4
	this.p1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.p1).wait(6).to({_off:true},96).wait(283));

	// t4_obj_
	this.t4 = new lib.Монтажный_кадр_1_t4();
	this.t4.name = "t4";
	this.t4.parent = this;
	this.t4.depth = 0;
	this.t4.isAttachedToCamera = 0
	this.t4.isAttachedToMask = 0
	this.t4.layerDepth = 0
	this.t4.layerIndex = 5
	this.t4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t4).wait(385));

	// t3_obj_
	this.t3 = new lib.Монтажный_кадр_1_t3();
	this.t3.name = "t3";
	this.t3.parent = this;
	this.t3.depth = 0;
	this.t3.isAttachedToCamera = 0
	this.t3.isAttachedToMask = 0
	this.t3.layerDepth = 0
	this.t3.layerIndex = 6
	this.t3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t3).wait(289).to({_off:true},1).wait(95));

	// t2_obj_
	this.t2 = new lib.Монтажный_кадр_1_t2();
	this.t2.name = "t2";
	this.t2.parent = this;
	this.t2.depth = 0;
	this.t2.isAttachedToCamera = 0
	this.t2.isAttachedToMask = 0
	this.t2.layerDepth = 0
	this.t2.layerIndex = 7
	this.t2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t2).wait(194).to({_off:true},1).wait(190));

	// t1_obj_
	this.t1 = new lib.Монтажный_кадр_1_t1();
	this.t1.name = "t1";
	this.t1.parent = this;
	this.t1.setTransform(216.1,124,1,1,0,0,0,216.1,124);
	this.t1.depth = 0;
	this.t1.isAttachedToCamera = 0
	this.t1.isAttachedToMask = 0
	this.t1.layerDepth = 0
	this.t1.layerIndex = 8
	this.t1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.t1).wait(99).to({_off:true},1).wait(285));

	// bg_obj_
	this.bg = new lib.Монтажный_кадр_1_bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(217.5,154.1,1,1,0,0,0,217.5,154.1);
	this.bg.depth = 0;
	this.bg.isAttachedToCamera = 0
	this.bg.isAttachedToMask = 0
	this.bg.layerDepth = 0
	this.bg.layerIndex = 9
	this.bg.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(385));

	// bg_obj_
	this.bg_1 = new lib.Монтажный_кадр_1_bg_1();
	this.bg_1.name = "bg_1";
	this.bg_1.parent = this;
	this.bg_1.setTransform(150,150,1,1,0,0,0,150,150);
	this.bg_1.depth = 0;
	this.bg_1.isAttachedToCamera = 0
	this.bg_1.isAttachedToMask = 0
	this.bg_1.layerDepth = 0
	this.bg_1.layerIndex = 10
	this.bg_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bg_1).wait(385));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(141.5,149.5,159,151);
// library properties:
lib.properties = {
	id: '0DDF71B09E19F048BC115CCAF9EA40DE',
	width: 300,
	height: 300,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x300_atlas_P_.png", id:"300x300_atlas_P_"},
		{src:"images/300x300_atlas_NP_.jpg", id:"300x300_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0DDF71B09E19F048BC115CCAF9EA40DE'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
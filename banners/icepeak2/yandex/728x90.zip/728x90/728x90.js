(function (lib, img, cjs, ss, an) {

var p; // shortcut to reference prototypes
lib.ssMetadata = [
		{name:"728x90_atlas_NP_", frames: [[0,420,728,135],[0,211,728,207],[0,0,728,209]]}
];


// symbols:



(lib._0 = function() {
	this.spriteSheet = ss["728x90_atlas_NP_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._1 = function() {
	this.spriteSheet = ss["728x90_atlas_NP_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.spriteSheet = ss["728x90_atlas_NP_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Символ15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AABAsQgGgDgDgHQgEgGAAgLIAAgMIgPAAIAAAoIgRAAIAAhYIARAAIAAAjIAPAAIAAgHQAAgLAEgHQADgGAGgDQAHgDAJAAQAIAAAHADQAGADAEAGQADAHABALIAAAgQgBALgDAGQgEAGgGAEQgIACgHAAQgJAAgHgCgAAIgcQgEAEAAAHIAAAjQAAAHAEAEQACAEAHAAQAFAAADgEQADgFAAgGIAAgjQAAgFgDgGQgDgDgFAAQgHAAgCADg");
	this.shape.setTransform(82.8,0,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAsIAAgNIABAAIABABIADAAQAFAAACgHIgYhFIATAAIAMAuIAOguIATAAIgdBSQgEAEgBACQgDABgFAAQgGAAgEgBg");
	this.shape_1.setTransform(67.2,0.2,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AALAtIAAgqIgVAAIAAAqIgRAAIAAhZIARAAIAAAjIAVAAIAAgjIARAAIAABZg");
	this.shape_2.setTransform(54.7,0,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAeAtIgPgkIgGAIIAAAcIgQAAIAAgcIgHgIIgPAkIgTAAIAYgyIgXgnIATAAIAVAnIAAgnIAQAAIAAAnIAUgnIATAAIgWAnIAXAyg");
	this.shape_3.setTransform(39.3,0,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAZAtIAAhZIARAAIAABZgAgpAtIAAhZIARAAIAAAkIAPAAQAFAAAEACQAEADACADIAFAHQABAEAAAFQAAANgGAIQgEAHgKABgAgYAgIAKAAQAFAAADgEQACgDAAgHQAAgHgDgDQgCgDgGAAIgJAAg");
	this.shape_4.setTransform(21.3,0,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgfAsIAAgMIAGAAIADgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIABgKIAAg9IAzAAIAABYIgRAAIAAhLIgRAAIAAAhQAAAMgCANQgBAJgFAFQgEAEgHAAIgKgBg");
	this.shape_5.setTransform(5.3,0.2,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgcAQIAAgeQAAgMAEgGQADgHAHgDQAHgDAHAAQAJAAAGADQAGACAEAIQAEAGAAAMIAAAeQAAAMgEAGQgDAHgHADQgGACgJAAQgcAAAAgegAgLgQIAAAjQAAAOALAAQAGAAADgEQACgDAAgHIAAgjQAAgIgCgDQgDgEgGAAQgLAAAAAPg");
	this.shape_6.setTransform(-7.1,0,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AALAtIAAgqIgVAAIAAAqIgRAAIAAhZIARAAIAAAjIAVAAIAAgjIARAAIAABZg");
	this.shape_7.setTransform(-19.6,0,1.819,1.819);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgbAtIAAhZIAfAAQAIABAFADQAEADAEAGQADAGAAAHQAAAIgDAGQgEAGgFADQgFADgHAAIgOAAIAAAlgAgKgEIAJAAQALAAAAgOQAAgMgLAAIgJAAg");
	this.shape_8.setTransform(-31.7,0,1.819,1.819);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgcAQIAAgeQAAgMAEgGQADgGAHgEQAHgDAHAAQAJAAAHADQAGADADAHQAEAGAAAMIAAAeQAAAMgEAGQgCAGgHAEQgIACgIAAQgcAAAAgegAgKgQIAAAjQAAAOAKAAQAGAAADgEQADgDAAgHIAAgjQAAgHgDgEQgDgEgGAAQgKAAAAAPg");
	this.shape_9.setTransform(-44.2,0,1.819,1.819);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgXAtIAAhZIAvAAIAAAOIgeAAIAABLg");
	this.shape_10.setTransform(-55,0,1.819,1.819);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAOAtIgEgYIgSAAIgGAYIgSAAIAXhZIAWAAIATBZgAgGAIIAOAAIgHgpg");
	this.shape_11.setTransform(-72.1,0,1.819,1.819);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AALAtIAAgqIgVAAIAAAqIgRAAIAAhZIARAAIAAAjIAVAAIAAgjIARAAIAABZg");
	this.shape_12.setTransform(-84.4,0,1.819,1.819);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E76720").s().p("AnkBaQglAAgagaQgbgbAAglQAAgkAbgaQAagbAlAAIPJAAQAlAAAaAbQAbAaAAAkQAAAlgbAbQgaAaglAAg");
	this.shape_13.setTransform(0,0,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ15, new cjs.Rectangle(-104.5,-16.3,209.1,32.8), null);


(lib.Символ14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AABBFQgJgEgGgLQgGgLAAgRIAAgTIgYAAIAAA/IgbAAIAAiMIAbAAIAAA5IAYAAIAAgMQAAgQAGgMQAGgKAJgEQALgFAOAAQAOAAAKAFQAKAEAGAKQAGALAAARIAAAzQAAAQgGAMQgGALgKAEQgKAEgOAAQgOAAgLgEgAALgtQgFAHAAALIAAA3QAAALAFAGQAGAHAJgBQAJABAEgHQAFgFAAgMIAAg3QAAgLgFgHQgEgFgJAAQgJAAgGAFg");
	this.shape.setTransform(78.7,-2.3,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUBGIAAg1QAAgcADgTIgmBkIgdAAIAAiMIAZAAIAABHIgCASIgCANIAnhmIAdAAIAACMg");
	this.shape_1.setTransform(53.5,-2.3,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXBVIAAgdIhHAAIAAiMIAbAAIAAB3IAiAAIAAh3IAbAAIAAB3IAJAAIAAAyg");
	this.shape_2.setTransform(33.8,0.3,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAPBGIgWg3IgKANIAAAqIgbAAIAAiMIAbAAIAAA+IAfg+IAeAAIgjA+IAlBOg");
	this.shape_3.setTransform(14.1,-2.3,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AglBGIAAiMIBLAAIAAAXIgwAAIAAAhIArAAIAAAUIgrAAIAAArIAwAAIAAAVg");
	this.shape_4.setTransform(-4.1,-2.3,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgyBGIAAgUQACABAHAAQAEAAABgBQACgBACgGIACgRIAAhhIBRAAIAACMIgbAAIAAh2IgbAAIAAA1QAAAYgDAPQgDAPgHAHQgGAHgMAAQgJAAgHgCg");
	this.shape_5.setTransform(-24,-2.1,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgyBGIAAgUQACABAGAAQAEAAACgBQACgBABgGIADgRIAAhhIBRAAIAACMIgbAAIAAh2IgbAAIAAA1QAAAYgEAPQgDAPgGAHQgHAHgLAAQgJAAgHgCg");
	this.shape_6.setTransform(-45,-2.1,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgtAZIAAgwQABgTAFgKQAHgLAJgEQAKgFANAAQAPAAAKAFQAKAFAFAKQAGAMgBARIAAAwQABARgGALQgFALgKAFQgKAEgPAAQgsAAgBgwgAgSgbIAAA4QABAXARgBQAJAAAFgFQAEgGAAgLIAAg4QAAgLgEgGQgFgHgJABQgRAAgBAXg");
	this.shape_7.setTransform(-64.6,-2.3,1.819,1.819);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAQBGIgXg3IgLANIAAAqIgbAAIAAiMIAbAAIAAA+IAgg+IAeAAIgkA+IAlBOg");
	this.shape_8.setTransform(-83.4,-2.3,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ14, new cjs.Rectangle(-91.7,-15.6,183.5,31.3), null);


(lib.Символ13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhOCRIB+khIAbAAIh+EhgAAyCCQgNgJgEgPQgDgQAAgUQAAgTADgSQAEgOANgJQANgJAZAAQAaAAAMAJQANAJAEAOQADAOAAAXQAAAXgDANQgEAPgNAJQgMAJgaAAQgZAAgNgJgABGAmQgEAIAAAYQAAAVAEAKQAFAKANAAQAOAAADgKQAFgJAAgWQAAgWgFgKQgEgKgNAAQgOAAgEAKgAh9gJQgNgJgEgPQgDgNAAgXQAAgXADgOQAEgNANgKQANgJAZAAQAaAAAMAJQANAKAEANQADAOAAAXQAAAXgDANQgEAPgNAJQgNAJgZAAQgZAAgNgJgAhlhqQgFAFgBAJQgCAIAAAPQAAAVAEALQAFAJAOAAQAOAAADgJQAEgLAAgVQAAgVgEgLQgEgKgNAAQgKAAgFAFg");
	this.shape.setTransform(10.8,-0.2,1.499,1.499);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmCIQgSgJgLgRQgKgRAAgWIAAiNQAAgWAKgQQALgRASgJQARgKAWAAQAXAAASAJQARAJAKARQAJAQAAAXIAACNQAAAWgJARQgKARgRAJQgSAJgXAAQgVAAgSgJgAgShdQgIAHAAAMIAACVQAAAMAIAIQAIAHALAAQAKAAAIgHQAIgIAAgMIAAiVQAAgMgHgHQgIgHgLAAQgLAAgIAHg");
	this.shape_1.setTransform(-27.6,0.5,1.499,1.499);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag6B8QgTgWAAgiIAAgQIAxAAIAAAKQAAApAbAAQARAAAFgLQAFgKAAgXQAAgagIgLQgGgLgSAAIgWAAIAAglIAPAAQAWAAAHgNQAHgOAAgTQAAgegYAAQgNAAgHAJQgHAJAAAQIAAAJIgwAAIAAgLQAAghAUgUQAVgVAiAAQAVAAASAJQARAIAJAQQAKAQAAAVQAAAbgKAPQgKAPgUAHQAsAKAAA9QAAAegJASQgKATgSAIQgRAJgbAAQgkAAgTgVg");
	this.shape_2.setTransform(-56.6,0.5,1.499,1.499);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E76720").s().p("AjmDOQhIAAg0g0Qg0gzAAhJIAAg7QAAhIA0g0QA0g0BIAAIHNAAQBJAAA0A0QAzAzAABJIAAA7QAABJgzAzQg0A0hJAAg");
	this.shape_3.setTransform(-18,0,1.499,1.499);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ13, new cjs.Rectangle(-79,-30.8,122,61.7), null);


(lib.Символ12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAGIgEAHIgFgEIAFgHIgJgCIADgGIAIADIAAgJIAFAAIAAAJIAIgDIADAGIgJACIAGAGIgGAFg");
	this.shape.setTransform(27.9,-12.1,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgiAUIAAgmQAAgNAEgJQAEgIAIgEQAJgEAJAAQALAAAIAEQAIAEAEAIQAEAJAAANIAAAmQAAANgEAJQgEAIgIADQgHAEgMAAQgiAAAAglgAgNgVIAAAsQAAARANAAQAHAAADgEQAEgFAAgIIAAgrQAAgJgEgFQgDgFgHAAQgNAAAAASg");
	this.shape_1.setTransform(57.6,-1.4,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAXBCIAAgWIgtAAIAAAWIgUAAIAAgnIAHAAIAFgMIADgMIAChEIA9AAIAABcIAHAAIAAAngAgFgXQAAATgCAJIgHAWIAdAAIAAhLIgUAAg");
	this.shape_2.setTransform(41.4,0.6,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AASA3IgGgdIgWAAIgHAdIgWAAIAbhtIAcAAIAYBtgAgHAKIARAAIgJgyg");
	this.shape_3.setTransform(18.9,-1.4,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAMA3IgRgsIgIALIAAAhIgVAAIAAhtIAVAAIAAAwIAYgwIAXAAIgcAwIAdA9g");
	this.shape_4.setTransform(4.4,-1.4,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAXBCIAAgWIgtAAIAAAWIgUAAIAAgnIAHAAIAFgMIADgMQABgFAAgJIABg2IA9AAIAABcIAHAAIAAAngAgFgXQAAATgCAJQgCALgFALIAdAAIAAhLIgUAAg");
	this.shape_5.setTransform(-11.9,0.6,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAPA3IAAgqQAAgWADgPIgeBPIgWAAIAAhtIAUAAIAAA3IgDAYIAehPIAWAAIAABtg");
	this.shape_6.setTransform(-28.2,-1.4,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAMA3IgRgsIgIALIAAAhIgVAAIAAhtIAVAAIAAAwIAYgwIAXAAIgcAwIAdA9g");
	this.shape_7.setTransform(-42.9,-1.4,1.819,1.819);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgZAvQgHgJAAgRIAAgnQAAgTAIgKQAJgJAQAAQAJAAAJAEQAGAEAFAHQAEAHgBALIAAAFIgUAAIAAgDQgBgJgCgFQgDgEgGAAQgHAAgCAEQgDAFAAAJIAAAqQAAALACAEQAEAFAGgBQAFABAEgFQADgEAAgLIAAgGIAUAAIAAAGQAAALgCAHQgDAJgIAEQgHAFgMAAQgSAAgIgKg");
	this.shape_8.setTransform(-57.8,-1.4,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ12, new cjs.Rectangle(-63.9,-14.5,127.9,27), null);


(lib.Символ11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgLAAAAgRQAAgQALAAQALAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape.setTransform(134.7,-4.8,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgLAAQAAgQALAAQAMAAAAAQQAAARgMAAQgLAAAAgRgAgFAAQAAANAFAAQAHAAAAgNQAAgMgHAAQgFAAAAAMg");
	this.shape_1.setTransform(134.7,-4.8,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKgPIAAAfIgEAAIAAgbIgLAAIAAAbIgEAAIAAgfg");
	this.shape_2.setTransform(129.5,-4.8,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAGAQIAAgbIgLAAIAAAbIgEAAIAAgfIATAAIAAAfg");
	this.shape_3.setTransform(129.5,-4.8,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMgUIAAAEQgMAPgCAWIgFAAQACgUANgRIgUAAIAAgEg");
	this.shape_4.setTransform(121.7,-5.7,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgGAVQABgUANgRIgTAAIAAgEIAXAAIAAAEQgMAPgCAWg");
	this.shape_5.setTransform(121.6,-5.7,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgJIgJAAIAAgEQAGAAABgBQACgCABgFIADAAIAAArIgEAAg");
	this.shape_6.setTransform(115.8,-5.8,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AACAWIAAgfIgIAAIAAgEQAFAAABgBQADgCAAgFIAEAAIAAArg");
	this.shape_7.setTransform(115.8,-5.8,1.819,1.819);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_8.setTransform(112.5,-2.4,1.819,1.819);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_9.setTransform(112.5,-2.4,1.819,1.819);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAAASQAHAAAAgSQAAgRgHAAQgGAAAAARQAAASAGAAgAgLAAQAAgVALAAQAMAAAAAVQAAAKgCAFQgDAHgHAAQgLAAAAgWg");
	this.shape_10.setTransform(108.6,-5.7,1.819,1.819);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgLAAQAAgVALAAQAMAAAAAVQAAAKgCAFQgDAHgHAAQgLAAAAgWgAgGAAQAAASAGAAQAHAAAAgSQAAgQgHAAQgGAAAAAQg");
	this.shape_11.setTransform(108.6,-5.7,1.819,1.819);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgJIgJAAIAAgEQAGAAABgBQACgCABgFIADAAIAAArIgEAAg");
	this.shape_12.setTransform(102.7,-5.8,1.819,1.819);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AACAWIAAgfIgIAAIAAgEQAFAAABgBQADgCAAgFIAEAAIAAArg");
	this.shape_13.setTransform(102.7,-5.8,1.819,1.819);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_14.setTransform(99.4,-2.4,1.819,1.819);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_15.setTransform(99.4,-2.4,1.819,1.819);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAEgSIAFAAIAAAbIADAAIAAAFIgDAAIAAALIgFAAIAAgLIgPAAIAAgFgAgHAJIALAAIAAgTg");
	this.shape_16.setTransform(95.3,-6.3,1.819,1.819);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AADAWIAAgLIgOAAIAAgFIAPgbIAEAAIAAAbIAEAAIAAAFIgEAAIAAALgAgIAGIALAAIAAgTg");
	this.shape_17.setTransform(95.3,-5.8,1.819,1.819);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgKgGIAAgCQAAgNAKAAQALAAAAAMQAAAIgIAGQgGAGgBABQgBACgBADIARAAIAAAFIgWAAQAAgGACgEQACgEAHgGQAGgFAAgGQAAgHgGAAQgGAAAAAKg");
	this.shape_18.setTransform(90.2,-5.8,1.819,1.819);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgLAWQAAgGACgEQACgEAHgGQAGgFAAgGQAAgHgGAAQgGAAABAKIgFAAIAAgCQAAgNAKAAQAMAAAAAMQgBAIgHAGIgHAHIgCAFIARAAIAAAFg");
	this.shape_19.setTransform(90.2,-5.8,1.819,1.819);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFAAQAAANAGAAQAEAAABgIIAFAAQAAAMgKAAQgLAAAAgRQAAgQALAAQAKAAAAALIgFAAQAAgHgFAAQgGAAAAAMg");
	this.shape_20.setTransform(82.7,-4.8,1.819,1.819);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAKAAQAKAAgBALIgEAAQAAgHgFAAQgGAAAAAMQAAANAGAAQAEAAABgIIAEAAQABAMgKAAQgKAAAAgRg");
	this.shape_21.setTransform(82.7,-4.8,1.819,1.819);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgVIAAAYIgBAEIABgEIAKgYIAGAAIAAAgIgFAAIAAgYIABgEIgBAAIgBAEIgJAYIgGAAIAAggg");
	this.shape_22.setTransform(74.9,-3.8,1.819,1.819);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgBAAIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIgBAEIABgEIAKgXIAGAAIAAAfg");
	this.shape_23.setTransform(74.9,-4.8,1.819,1.819);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIAAgEIAKgXIAGAAIAAAfIgFAAIAAgXIAAgEIAAAEIgKAXIgGAAIAAgfg");
	this.shape_24.setTransform(69.5,-4.8,1.819,1.819);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIAAgEIAAAEIgKAXIgGAAIAAgfIAFAAIAAAXIAAAEIABgEIAJgXIAFAAIAAAfg");
	this.shape_25.setTransform(69.5,-4.8,1.819,1.819);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGAIIAKAAIAAgcIAFAAIAAAcIADAAIAAAMIgEAAIAAgIIgTAAIAAggIAFAAg");
	this.shape_26.setTransform(64.5,-4,1.819,1.819);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAIAVIAAgJIgTAAIAAggIAFAAIAAAcIAKAAIAAgcIAFAAIAAAcIADAAIAAANg");
	this.shape_27.setTransform(64.5,-4,1.819,1.819);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgIAAIAKgPIAGAAIgJAMIAJATIgFAAIgHgQIgEAFIAAALIgEAAIAAgfIAEAAg");
	this.shape_28.setTransform(59.9,-4.8,1.819,1.819);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAFAQIgHgQIgDAFIAAALIgFAAIAAgfIAFAAIAAAPIAKgPIAFAAIgKAMIALATg");
	this.shape_29.setTransform(59.5,-4.8,1.819,1.819);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAIAAAAAIIAAASQAAADACAAIABAAIAAADIgCAAQgEAAgBgEQgBAFgFAAQgIAAAAgJQAAgHAHgCIAGgCQABgBAAgDQAAgFgEAAQgFAAAAAGgAgFAIQAAAFADAAQAGAAAAgHIAAgGQgDAAgDACQgDACAAAEg");
	this.shape_30.setTransform(54.5,-4.8,1.819,1.819);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAHgCIAGgCQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQgBgFgDAAQgFAAAAAGIgEAAQAAgKAJAAQAIAAAAAIIAAASQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIABAAIAAADIgCAAQgEAAgBgEQgCAFgEAAQgIAAAAgJgAgCACQgDACAAAEQAAAFADAAQAGAAAAgHIAAgGIgGACg");
	this.shape_31.setTransform(54.5,-4.8,1.819,1.819);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADADIgGANIgFAAIAHgOQgGgCAAgGQAAgJAIAAIALAAIAAAfIgFAAIAAgNgAAHgLIgFAAQgEAAAAAFQAAAGAEAAIAFAAg");
	this.shape_32.setTransform(46.5,-4.8,1.819,1.819);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAGAQIAAgNIgFAAIgGANIgEAAIAGgOQgFgCAAgGQAAgJAIAAIAKAAIAAAfgAgEgGQAAAGAFAAIAFAAIAAgLIgFAAQgFAAAAAFg");
	this.shape_33.setTransform(46.7,-4.8,1.819,1.819);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIAAgEIAKgXIAGAAIAAAfIgFAAIAAgXIAAgEIAAAEIgKAXIgGAAIAAgfg");
	this.shape_34.setTransform(41.8,-4.8,1.819,1.819);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgCAEIgJAXIgFAAIAAgfIAEAAIAAAXIgBAEIABgEIAKgXIAFAAIAAAfg");
	this.shape_35.setTransform(41.8,-4.8,1.819,1.819);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgCIALAAIAAgNIAEAAIAAAfIgEAAIAAgPIgLAAIAAAPIgEAAIAAgfIAEAAg");
	this.shape_36.setTransform(36.4,-4.8,1.819,1.819);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAGAQIAAgPIgLAAIAAAPIgEAAIAAgfIAEAAIAAANIALAAIAAgNIAEAAIAAAfg");
	this.shape_37.setTransform(36.4,-4.8,1.819,1.819);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgKAAQgJAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAHAAACQACADACAAQAGAAAAgIgAAFgCQAAgKgFAAQgEAAAAAKg");
	this.shape_38.setTransform(31.4,-4.8,1.819,1.819);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAIAAAJQACADACAAQAGAAAAgIIAEAAQAAAMgKAAQgJAAAAgRgAgEgCIAJAAQAAgKgFAAQgEAAAAAKg");
	this.shape_39.setTransform(31.4,-4.8,1.819,1.819);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgJIAAgLIARAAIAAAcIADAAIAAAMIgFAAIAAgIIgRAAIAAAIIgFAAIAAgMIADAAQAEgIAAgJgAAGgQIgIAAIAAAJQAAAHgDAIIALAAg");
	this.shape_40.setTransform(26.4,-4,1.819,1.819);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAJAVIAAgJIgRAAIAAAJIgFAAIAAgNIADAAQAEgIAAgJIAAgLIARAAIAAAcIADAAIAAANgAgCgGQAAAGgDAIIALAAIAAgXIgIAAg");
	this.shape_41.setTransform(26.4,-4,1.819,1.819);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgJAAQgKAAAAgRQAAgQAJAAQAKAAAAARIgPAAQAAAMAGAAQAFAAAAgIgAAGgCQAAgKgGAAQgFAAAAAKg");
	this.shape_42.setTransform(21.3,-4.8,1.819,1.819);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgPAAQAAAMAGAAQAEAAAAgIIAFAAQAAAMgJAAQgKAAAAgRgAgFgCIAKAAQABgKgGAAQgEAAgBAKg");
	this.shape_43.setTransform(21.3,-4.8,1.819,1.819);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgPIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAJgIAAIgLAAgAgEgCIAEAAQAFAAAAgFQAAgEgFAAIgEAAgAgEAMIAEAAQAFAAAAgFQAAgGgFAAIgEAAg");
	this.shape_44.setTransform(16.5,-4.8,1.819,1.819);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgJAQIAAgfIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAJgIAAgAgEAMIAEAAQAFAAAAgFQAAgGgFAAIgEAAgAgEgCIAEAAQAFAAAAgFQAAgEgFAAIgEAAg");
	this.shape_45.setTransform(16.5,-4.8,1.819,1.819);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgKAAAAgRQAAgQAKAAQALAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_46.setTransform(11.3,-4.8,1.819,1.819);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQAAARgLAAQgKAAAAgRgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_47.setTransform(11.3,-4.8,1.819,1.819);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgRIABAAQABgEAEAAQALAAAAAQQAAARgLAAQgDAAgDgEIAAAOIgEAAIAAgqIAEAAgAgGgFQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_48.setTransform(6.2,-3.8,1.819,1.819);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgKAWIAAgrIAFAAIAAAFIAAAAQACgFAEAAQAKAAAAAQQAAARgKAAQgEAAgCgFIAAAPgAgFgEQAAAMAFAAQAGAAAAgNQAAgNgGAAQgFAAAAAOg");
	this.shape_49.setTransform(6.2,-3.8,1.819,1.819);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKgPIAAAfIgFAAIAAgbIgKAAIAAAbIgEAAIAAgfg");
	this.shape_50.setTransform(0.9,-4.8,1.819,1.819);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AAFAQIAAgbIgKAAIAAAbIgEAAIAAgfIATAAIAAAfg");
	this.shape_51.setTransform(0.9,-4.8,1.819,1.819);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIABgEIAJgXIAGAAIAAAfIgFAAIAAgXIABgEIgBAEIgKAXIgFAAIAAgfg");
	this.shape_52.setTransform(-7.1,-4.8,1.819,1.819);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIAAgEIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIAAAEIABgEIAJgXIAGAAIAAAfg");
	this.shape_53.setTransform(-7.1,-4.8,1.819,1.819);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgIAAIAKgPIAGAAIgJAMIAJATIgFAAIgHgQIgEAFIAAALIgEAAIAAgfIAEAAg");
	this.shape_54.setTransform(-11.4,-4.8,1.819,1.819);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AAGAQIgHgQIgEAFIAAALIgEAAIAAgfIAEAAIAAAPIAKgPIAFAAIgKAMIAKATg");
	this.shape_55.setTransform(-11.9,-4.8,1.819,1.819);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgKAAAAgRQAAgQAKAAQALAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_56.setTransform(-17.2,-4.8,1.819,1.819);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQAAARgLAAQgKAAAAgRgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_57.setTransform(-17.2,-4.8,1.819,1.819);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgRQADgEAEAAQAKAAAAAQQAAARgKAAQgDAAgEgEIAAAOIgEAAIAAgqIAEAAgAgGgFQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_58.setTransform(-22.4,-3.8,1.819,1.819);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgKAWIAAgrIAEAAIAAAFQADgFADAAQALAAAAAQQAAARgLAAQgCAAgEgFIAAAPgAgGgEQAAAMAGAAQAGAAAAgNQAAgNgGAAQgFAAgBAOg");
	this.shape_59.setTransform(-22.4,-3.8,1.819,1.819);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAIgIQAAgJgIAAQgHAAAAARQAAASAHAAQAHAAABgMIAFAAQgBARgMAAQgMAAAAgXQAAgWAMAAQAGAAAEAEQADAEAAAGg");
	this.shape_60.setTransform(-28,-5.8,1.819,1.819);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgMAAQAAgWANAAQAFAAAEAEQADAEAAAGIgFAAQAAgJgHAAQgIAAAAARQAAASAIAAQAGAAABgMIAFAAQgBARgLAAQgNAAAAgXg");
	this.shape_61.setTransform(-28,-5.8,1.819,1.819);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_62.setTransform(-34.9,-2.4,1.819,1.819);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_63.setTransform(-34.9,-2.4,1.819,1.819);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADADIgGANIgFAAIAHgOQgGgCAAgGQAAgEADgDQACgCADAAIALAAIAAAfIgEAAIAAgNgAAIgLIgFAAQgFAAAAAFQAAAGAFAAIAFAAg");
	this.shape_64.setTransform(-39.2,-4.8,1.819,1.819);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AAGAQIAAgNIgFAAIgGANIgEAAIAHgOQgHgCAAgGQABgEACgDQADgCADAAIAKAAIAAAfgAgDgGQgBAGAFAAIAFAAIAAgLIgFAAQgFAAABAFg");
	this.shape_65.setTransform(-38.9,-4.8,1.819,1.819);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIABgEIAJgXIAGAAIAAAfIgFAAIAAgXIABgEIgBAEIgKAXIgFAAIAAgfg");
	this.shape_66.setTransform(-43.8,-4.8,1.819,1.819);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgBAEIgKAXIgFAAIAAgfIAEAAIAAAXIgBAEIABgEIAKgXIAFAAIAAAfg");
	this.shape_67.setTransform(-43.8,-4.8,1.819,1.819);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGAIIAKAAIAAgcIAEAAIAAAcIAEAAIAAAMIgFAAIAAgIIgSAAIAAggIAFAAg");
	this.shape_68.setTransform(-48.9,-4,1.819,1.819);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AAHAVIAAgJIgSAAIAAggIAFAAIAAAcIAKAAIAAgcIAEAAIAAAcIAEAAIAAANg");
	this.shape_69.setTransform(-48.9,-4,1.819,1.819);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgIAAIAKgPIAGAAIgJAMIAJATIgFAAIgHgQIgEAFIAAALIgEAAIAAgfIAEAAg");
	this.shape_70.setTransform(-53.4,-4.8,1.819,1.819);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAFAQIgHgQIgDAFIAAALIgFAAIAAgfIAFAAIAAAPIAKgPIAGAAIgLAMIALATg");
	this.shape_71.setTransform(-53.9,-4.8,1.819,1.819);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgCgPIAFAAIAMArIgFAAIgEgNIgMAAIgDANIgGAAgAAAgLIgFAWIAKAAg");
	this.shape_72.setTransform(-59.6,-6.8,1.819,1.819);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AAKAWIgDgNIgNAAIgDANIgGAAIANgrIAFAAIANArgAgFAFIALAAIgGgWg");
	this.shape_73.setTransform(-59.6,-5.8,1.819,1.819);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AACgJIAAAHIAGgCIABADIgHABIAFAFIgDACIgEgFIgDAFIgDgCIAFgFIgHgBIABgDIAHADIAAgIg");
	this.shape_74.setTransform(-65.1,-8,1.819,1.819);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AAAADIgDAGIgDgCIAFgGIgHgBIABgDIAHADIAAgHIACAAIAAAHIAGgDIABADIgHABIAFAGIgDACg");
	this.shape_75.setTransform(-65.1,-8.2,1.819,1.819);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgBgPIAAgGIADAAIAAAGgAACAWIgDAAIAAggIADAAg");
	this.shape_76.setTransform(544.4,-6.2,1.819,1.819);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgBAWIAAggIADAAIAAAggAgBgPIAAgGIADAAIAAAGg");
	this.shape_77.setTransform(544.4,-6.2,1.819,1.819);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgCgJIAAgDQAAgJAHAAIACAAIAAAEIgCAAQgDAAAAAEIAAAEIAFAAIAAADIgFAAIAAAcIgEAAIAAgcIgEAAIAAgDg");
	this.shape_78.setTransform(541.8,-6.2,1.819,1.819);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgCAWIAAgcIgEAAIAAgDIAEAAIAAgDQAAgJAHAAIACAAIAAAEIgCAAQgDAAAAAEIAAAEIAFAAIAAADIgFAAIAAAcg");
	this.shape_79.setTransform(541.8,-6.2,1.819,1.819);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_80.setTransform(539.1,-2.8,1.819,1.819);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_81.setTransform(539.1,-2.8,1.819,1.819);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgHAEIAKgOIAFAAIgJAMIAJAUIgFAAIgHgQIgDAEIAAAMIgFAAIAAgrIAFAAg");
	this.shape_82.setTransform(536.1,-6.2,1.819,1.819);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AAGAWIgHgQIgEAEIAAAMIgFAAIAAgrIAFAAIAAAZIAKgOIAGAAIgKAMIAKAUg");
	this.shape_83.setTransform(535.6,-6.2,1.819,1.819);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAIAAAAAIIAAASQAAADACAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgCAFgEAAQgIAAAAgJQAAgHAIgCIAEgCQACgBAAgDQAAgFgEAAQgFAAAAAGgAgGAIQAAAFAFAAQAFAAAAgHIAAgGQgDAAgDACQgEACAAAEg");
	this.shape_84.setTransform(530.6,-5.2,1.819,1.819);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAIgCIAEgCQABAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgFgEAAQgFAAAAAGIgEAAQAAgKAJAAQAJAAgBAIIAAASQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIAAADIgCAAQgEAAAAgEIgBAAQgBAFgFAAQgIAAAAgJgAgCACQgEACAAAEQAAAFAFAAQAFAAAAgHIAAgGIgGACg");
	this.shape_85.setTransform(530.6,-5.2,1.819,1.819);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgJAAQgKAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIgAAGgCQAAgKgGAAQgEAAAAAKg");
	this.shape_86.setTransform(525.8,-5.2,1.819,1.819);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIIAEAAQAAAMgJAAQgKAAAAgRgAgEgCIAKAAQAAgKgGAAQgEAAAAAKg");
	this.shape_87.setTransform(525.8,-5.2,1.819,1.819);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgRQACgEADAAQALAAAAAQQAAARgKAAQgDAAgDgEIAAAOIgFAAIAAgqIAFAAgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFAAAAAMg");
	this.shape_88.setTransform(520.9,-4.3,1.819,1.819);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgKAWIAAgrIAFAAIAAAFQACgFADAAQALAAAAAQQAAAQgKAAQgDAAgDgDIAAAOgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFgBAAANg");
	this.shape_89.setTransform(520.9,-4.3,1.819,1.819);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgKAAQgJAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAHAAACQACADACAAQAGAAAAgIgAAFgCQAAgKgFAAQgEAAAAAKg");
	this.shape_90.setTransform(515.8,-5.2,1.819,1.819);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAIAAAJQACADACAAQAGAAAAgIIAEAAQAAAMgKAAQgJAAAAgRgAgEgCIAJAAQAAgKgFAAQgEAAAAAKg");
	this.shape_91.setTransform(515.8,-5.2,1.819,1.819);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFAAQAAANAGAAQAFAAAAgIIAFAAQAAAMgKAAQgLAAAAgRQAAgQALAAQAKAAAAALIgFAAQAAgHgFAAQgGAAAAAMg");
	this.shape_92.setTransform(511.1,-5.2,1.819,1.819);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAKAAQAJAAABALIgFAAQAAgHgFAAQgGAAAAAMQAAANAGAAQAFAAAAgIIAFAAQgBAMgJAAQgKAAAAgRg");
	this.shape_93.setTransform(511.1,-5.2,1.819,1.819);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgBgPIAAgGIADAAIAAAGgAACAWIgDAAIAAggIADAAg");
	this.shape_94.setTransform(507.5,-6.2,1.819,1.819);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgBAWIAAggIADAAIAAAggAgBgPIAAgGIADAAIAAAGg");
	this.shape_95.setTransform(507.5,-6.2,1.819,1.819);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_96.setTransform(505,-2.8,1.819,1.819);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_97.setTransform(505,-2.8,1.819,1.819);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgMgQIAGAcIAFgcIAEAAIAFAcIAAAAIAGgcIAEAAIgHAgIgGAAIgFgbIgEAbIgFAAIgIggg");
	this.shape_98.setTransform(500.1,-5.1,1.819,1.819);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AAFAQIgFgaIgEAaIgFAAIgIgfIAFAAIAGAbIAFgbIAEAAIAFAbIAAAAIAGgbIAEAAIgHAfg");
	this.shape_99.setTransform(500.1,-5.2,1.819,1.819);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgNgQIAGAcIAFgcIAFAAIAFAcIAFgcIAFAAIgIAgIgFAAIgFgbIgEAbIgGAAIgHggg");
	this.shape_100.setTransform(493.2,-5.1,1.819,1.819);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AAFAQIgFgaIgEAaIgGAAIgHgfIAFAAIAFAbIAGgbIAEAAIAFAbIAGgbIAEAAIgIAfg");
	this.shape_101.setTransform(493.2,-5.2,1.819,1.819);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgNgQIAGAcIAFgcIAFAAIAFAcIAGgcIAEAAIgHAgIgGAAIgFgbIgEAbIgGAAIgHggg");
	this.shape_102.setTransform(486.2,-5.1,1.819,1.819);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AAFAQIgFgaIgEAaIgGAAIgHgfIAEAAIAHAbIAEgbIAFAAIAFAbIAGgbIAEAAIgHAfg");
	this.shape_103.setTransform(486.2,-5.2,1.819,1.819);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgKAAQgJAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIgAAFgCQAAgKgFAAQgEAAAAAKg");
	this.shape_104.setTransform(477.7,-5.2,1.819,1.819);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIIAEAAQAAAMgKAAQgJAAAAgRgAgEgCIAJAAQAAgKgFAAQgEAAAAAKg");
	this.shape_105.setTransform(477.7,-5.2,1.819,1.819);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgBAQIAAgbIgJAAIAAgEIAVAAIAAAEIgJAAIAAAbg");
	this.shape_106.setTransform(473.2,-5.2,1.819,1.819);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgBAQIAAgbIgJAAIAAgEIAVAAIAAAEIgJAAIAAAbg");
	this.shape_107.setTransform(473.2,-5.2,1.819,1.819);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIABgEIAJgXIAGAAIAAAfIgFAAIAAgXIABgEIgBAEIgKAXIgGAAIAAgfgAgEgZQABAEADAAQAFAAAAgEIADAAQgBAHgHAAQgGAAAAgHg");
	this.shape_108.setTransform(468.4,-5.2,1.819,1.819);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AAGAVIAAgXIABgEIgBAEIgKAXIgGAAIAAgfIAFAAIAAAXIAAAEIABgEIAJgXIAGAAIAAAfgAgGgUIACAAQABAEADAAQAFAAAAgEIADAAQgBAHgHAAQgGAAAAgHg");
	this.shape_109.setTransform(468.4,-6.1,1.819,1.819);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAJAAAAAIIAAASQAAADABAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgBAFgFAAQgIAAAAgJQAAgHAIgCIAFgCQABgBAAgDQAAgFgEAAQgFAAAAAGgAgFAIQAAAFAEAAQAFAAAAgHIAAgGQgDAAgDACQgDACAAAEg");
	this.shape_110.setTransform(463.4,-5.2,1.819,1.819);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAIgCIAFgCQAAAAAAgBQAAAAAAAAQAAgBAAgBQABAAAAgBQgBgFgDAAQgFAAAAAGIgEAAQAAgKAJAAQAIAAABAIIAAASQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgCAFgEAAQgIAAAAgJgAgCACQgDACAAAEQAAAFAEAAQAEAAABgHIAAgGIgGACg");
	this.shape_111.setTransform(463.4,-5.2,1.819,1.819);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFAAQAAANAGAAQAEAAABgIIAEAAQAAAMgJAAQgKAAAAgRQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMg");
	this.shape_112.setTransform(458.7,-5.2,1.819,1.819);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMQAAANAGAAQAEAAABgIIAEAAQAAAMgJAAQgKAAAAgRg");
	this.shape_113.setTransform(458.7,-5.2,1.819,1.819);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAIAAAAAIIAAASQAAADACAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgBAFgFAAQgIAAAAgJQAAgHAIgCIAFgCQABgBAAgDQAAgFgEAAQgFAAAAAGgAgGAIQAAAFAFAAQAFAAAAgHIAAgGQgDAAgDACQgEACAAAEg");
	this.shape_114.setTransform(451.3,-5.2,1.819,1.819);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAIgCIAFgCQAAAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgFgEAAQgFAAAAAGIgEAAQAAgKAJAAQAIAAABAIIAAASQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgCAFgEAAQgIAAAAgJgAgCACQgDACgBAEQABAFAEAAQAFAAAAgHIAAgGIgGACg");
	this.shape_115.setTransform(451.3,-5.2,1.819,1.819);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgCIAKAAIAAgNIAFAAIAAAfIgFAAIAAgPIgKAAIAAAPIgEAAIAAgfIAEAAg");
	this.shape_116.setTransform(446.3,-5.2,1.819,1.819);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AAFAQIAAgPIgKAAIAAAPIgEAAIAAgfIAEAAIAAANIAKAAIAAgNIAFAAIAAAfg");
	this.shape_117.setTransform(446.3,-5.2,1.819,1.819);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIAAAEIAAgEIAKgXIAGAAIAAAfIgFAAIAAgXIABgEIgBAEIgKAXIgGAAIAAgfg");
	this.shape_118.setTransform(438.3,-5.2,1.819,1.819);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgBAEIgKAXIgGAAIAAgfIAFAAIAAAXIAAAEIABgEIAJgXIAFAAIAAAfg");
	this.shape_119.setTransform(438.3,-5.2,1.819,1.819);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgKIAAAYIgBAEIABAAIABgEIAJgYIAGAAIAAAgIgFAAIAAgYIABgEIgBAEIgKAYIgGAAIAAggg");
	this.shape_120.setTransform(432.9,-6.2,1.819,1.819);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgBAEIgKAXIgGAAIAAgfIAFAAIAAAXIgBAEIABAAIABgEIAJgXIAGAAIAAAfg");
	this.shape_121.setTransform(432.9,-5.2,1.819,1.819);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGAIIAKAAIAAgcIAFAAIAAAcIADAAIAAAMIgEAAIAAgIIgTAAIAAggIAFAAg");
	this.shape_122.setTransform(427.8,-4.4,1.819,1.819);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AAIAUIAAgIIgTAAIAAggIAFAAIAAAcIAKAAIAAgcIAFAAIAAAcIADAAIAAAMg");
	this.shape_123.setTransform(427.8,-4.4,1.819,1.819);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgIAAIAKgPIAGAAIgJAMIAJATIgFAAIgHgQIgEAFIAAALIgEAAIAAgfIAEAAg");
	this.shape_124.setTransform(423.4,-5.2,1.819,1.819);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AAFAQIgGgQIgEAFIAAALIgEAAIAAgfIAEAAIAAAPIAKgPIAGAAIgKAMIAKATg");
	this.shape_125.setTransform(422.9,-5.2,1.819,1.819);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAJAAAAAIIAAASQAAADABAAIABAAIAAADIgBAAQgFAAAAgEIgBAAQgBAFgFAAQgIAAAAgJQAAgHAIgCIAFgCQABgBAAgDQAAgFgEAAQgEAAAAAGgAgFAIQAAAFAEAAQAFAAAAgHIAAgGQgCAAgEACQgDACAAAEg");
	this.shape_126.setTransform(417.9,-5.2,1.819,1.819);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAIgCIAFgCQAAAAAAgBQAAAAABAAQAAgBAAgBQAAAAAAgBQAAgFgEAAQgFAAABAGIgFAAQAAgKAJAAQAJAAgBAIIAAASQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIAAADIgCAAQgEAAAAgEIgBAAQgBAFgFAAQgIAAAAgJgAgCACQgDACAAAEQgBAFAFAAQAFAAAAgHIAAgGIgGACg");
	this.shape_127.setTransform(417.9,-5.2,1.819,1.819);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADADIgGANIgFAAIAHgOQgGgCAAgGQAAgJAIAAIALAAIAAAfIgEAAIAAgNgAAIgLIgFAAQgFAAAAAFQAAAGAEAAIAGAAg");
	this.shape_128.setTransform(409.9,-5.2,1.819,1.819);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AAGAQIAAgNIgFAAIgGANIgEAAIAHgOQgHgCABgGQgBgJAJAAIAKAAIAAAfgAgDgGQAAAGADAAIAGAAIAAgLIgFAAQgFAAABAFg");
	this.shape_129.setTransform(410.1,-5.2,1.819,1.819);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIgBAEIABgEIAKgXIAGAAIAAAfIgFAAIAAgbIgBAEIgJAXIgGAAIAAgfg");
	this.shape_130.setTransform(405.2,-5.2,1.819,1.819);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AAGAQIAAgbIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIgBAEIABgEIAKgXIAGAAIAAAfg");
	this.shape_131.setTransform(405.2,-5.2,1.819,1.819);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgEgCIAKAAIAAgNIAEAAIAAAfIgEAAIAAgPIgKAAIAAAPIgFAAIAAgfIAFAAg");
	this.shape_132.setTransform(399.8,-5.2,1.819,1.819);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AAGAQIAAgPIgKAAIAAAPIgFAAIAAgfIAFAAIAAANIAKAAIAAgNIAEAAIAAAfg");
	this.shape_133.setTransform(399.8,-5.2,1.819,1.819);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgJAAQgKAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIgAAGgCQAAgKgGAAQgEAAAAAKg");
	this.shape_134.setTransform(394.8,-5.2,1.819,1.819);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIIAEAAQAAAMgJAAQgKAAAAgRgAgEgCIAKAAQAAgKgGAAQgEAAAAAKg");
	this.shape_135.setTransform(394.8,-5.2,1.819,1.819);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgJIAAgLIARAAIAAAcIACAAIAAAMIgEAAIAAgIIgRAAIAAAIIgEAAIAAgMIACAAQAEgIAAgJgAAGgQIgIAAIAAAJQAAAHgDAIIALAAg");
	this.shape_136.setTransform(389.8,-4.4,1.819,1.819);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AAKAUIAAgIIgSAAIAAAIIgFAAIAAgMIADAAQAEgIAAgIIAAgMIARAAIAAAcIACAAIAAAMgAgCgGQABAGgEAIIALAAIAAgXIgIAAg");
	this.shape_137.setTransform(389.8,-4.4,1.819,1.819);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgJAAQgKAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAMAFAAQAFAAAAgIgAAGgCQAAgKgFAAQgFAAAAAKg");
	this.shape_138.setTransform(384.7,-5.2,1.819,1.819);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAQgBAMAGAAQAEAAAAgIIAFAAQAAAMgJAAQgKAAAAgRgAgEgCIAJAAQAAgKgEAAQgGAAABAKg");
	this.shape_139.setTransform(384.7,-5.2,1.819,1.819);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgPIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAJgIAAIgLAAgAgEgCIAEAAQAFAAAAgFQAAgEgFAAIgEAAgAgEAMIAEAAQAGAAAAgFQAAgGgGAAIgEAAg");
	this.shape_140.setTransform(379.9,-5.2,1.819,1.819);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgJAQIAAgfIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAJgIAAgAgEAMIAEAAQAGAAgBgFQABgGgGAAIgEAAgAgEgCIAEAAQAEAAAAgFQAAgEgEAAIgEAAg");
	this.shape_141.setTransform(379.9,-5.2,1.819,1.819);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMAAQAAARgMAAQgLAAAAgRQAAgQALAAQAMAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_142.setTransform(374.8,-5.2,1.819,1.819);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQAAARgLAAQgKAAAAgRgAgGAAQABANAFAAQAHAAAAgNQAAgMgHAAQgFAAgBAMg");
	this.shape_143.setTransform(374.8,-5.2,1.819,1.819);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgRQACgEADAAQALAAAAAQQAAARgKAAQgEAAgCgEIAAAOIgFAAIAAgqIAFAAgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFAAAAAMg");
	this.shape_144.setTransform(369.6,-4.3,1.819,1.819);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgKAWIAAgrIAFAAIAAAFQACgFADAAQALAAAAAQQAAAQgKAAQgEAAgCgDIAAAOgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFgBAAANg");
	this.shape_145.setTransform(369.6,-4.3,1.819,1.819);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKgPIAAAfIgEAAIAAgbIgLAAIAAAbIgEAAIAAgfg");
	this.shape_146.setTransform(364.3,-5.2,1.819,1.819);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AAGAQIAAgbIgLAAIAAAbIgEAAIAAgfIATAAIAAAfg");
	this.shape_147.setTransform(364.3,-5.2,1.819,1.819);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgPIAHAMIAGgMIAFAAIgJAPIAKAQIgFAAIgIgNIgHANIgFAAIAKgQIgIgPg");
	this.shape_148.setTransform(356.8,-4.9,1.819,1.819);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AAHAQIgHgNIgGANIgGAAIAKgQIgJgPIAFAAIAGAMIAHgMIAFAAIgJAPIAKAQg");
	this.shape_149.setTransform(356.8,-4.9,1.819,1.819);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADADIgGANIgFAAIAHgOQgGgCAAgGQAAgJAIAAIALAAIAAAfIgEAAIAAgNgAAIgLIgFAAQgFAAAAAFQAAAGAEAAIAGAAg");
	this.shape_150.setTransform(351.6,-4.9,1.819,1.819);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AAGAQIAAgNIgFAAIgGANIgEAAIAGgOQgFgCAAgGQgBgJAJAAIAKAAIAAAfgAgEgGQABAGAEAAIAFAAIAAgLIgFAAQgFAAAAAFg");
	this.shape_151.setTransform(351.8,-4.9,1.819,1.819);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIgBAEIABgEIAKgXIAGAAIAAAfIgFAAIAAgbIgBAEIgJAXIgGAAIAAgfg");
	this.shape_152.setTransform(346.9,-4.9,1.819,1.819);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AAGAQIAAgbIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIgBAEIABgEIAKgXIAGAAIAAAfg");
	this.shape_153.setTransform(346.9,-4.9,1.819,1.819);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgPIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAEgCADQgDACgDAAIgLAAgAgFgCIAFAAQAEAAAAgFQAAgEgEAAIgFAAgAgFAMIAFAAQAGAAAAgFQAAgGgGAAIgFAAg");
	this.shape_154.setTransform(341.8,-4.9,1.819,1.819);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgJAQIAAgfIAKAAQAIAAAAAIQAAAGgFABQAGABAAAGQAAAEgCADQgDACgDAAgAgFAMIAFAAQAGAAgBgFQABgGgGAAIgFAAgAgFgCIAFAAQAEAAAAgFQAAgEgEAAIgFAAg");
	this.shape_155.setTransform(341.8,-4.9,1.819,1.819);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMAAQAAARgMAAQgKAAAAgRQAAgQAKAAQAMAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_156.setTransform(336.6,-4.9,1.819,1.819);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQAAARgLAAQgKAAAAgRgAgGAAQAAANAGAAQAGAAABgNQgBgMgGAAQgGAAAAAMg");
	this.shape_157.setTransform(336.6,-4.9,1.819,1.819);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMgPIAAAfIgFAAIAAgbIgJAAIAAAMQAAAPgGAAIgDAAIAAgEIACAAQADAAAAgMIAAgPg");
	this.shape_158.setTransform(331.1,-4.9,1.819,1.819);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AAHAQIAAgbIgJAAIAAAMQAAAPgGAAIgDAAIAAgEIACAAQADAAAAgMIAAgPIASAAIAAAfg");
	this.shape_159.setTransform(331.1,-4.9,1.819,1.819);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFAAQAAANAFAAQAFAAABgIIAEAAQAAAMgJAAQgKAAAAgRQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMg");
	this.shape_160.setTransform(326.4,-4.9,1.819,1.819);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMQAAANAFAAQAFAAABgIIAEAAQAAAMgJAAQgKAAAAgRg");
	this.shape_161.setTransform(326.4,-4.9,1.819,1.819);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgHgVIAHAZIAHgZIAFAAIgKAgQgCAKgHAAIgDAAIAAgEIADABQAEAAACgHIgKggg");
	this.shape_162.setTransform(321.7,-3.9,1.819,1.819);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgKAVIAAgEIADABQAEAAACgHIgKgfIAEAAIAHAZIAIgZIAEAAIgKAfQgCALgHAAg");
	this.shape_163.setTransform(321.7,-3.9,1.819,1.819);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIgBAEIABgEIAKgXIAGAAIAAAfIgFAAIAAgXIAAgEIgBAEIgJAXIgGAAIAAgfg");
	this.shape_164.setTransform(314,-4.9,1.819,1.819);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIAAgEIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIgBAEIABgEIAKgXIAGAAIAAAfg");
	this.shape_165.setTransform(314,-4.9,1.819,1.819);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAKAFQAAAMgJAAQgKAAAAgRQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIgAAFgCQAAgKgFAAQgEAAAAAKg");
	this.shape_166.setTransform(306.3,-4.9,1.819,1.819);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAJAAQAKAAAAARIgOAAQAAAMAEAAQAGAAAAgIIAEAAQAAAMgJAAQgKAAAAgRgAgEgCIAJAAQAAgKgFAAQgEAAAAAKg");
	this.shape_167.setTransform(306.3,-4.9,1.819,1.819);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgRQACgEADAAQALAAAAAQQAAARgKAAQgDAAgDgEIAAAOIgFAAIAAgqIAFAAgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFAAAAAMg");
	this.shape_168.setTransform(301.4,-3.9,1.819,1.819);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#FFFFFF").s().p("AgKAWIAAgqIAFAAIAAADQACgEADAAQALAAAAAQQAAAQgKAAQgDAAgDgEIAAAPgAgFgEQAAAMAFAAQAGAAAAgNQAAgNgGAAQgFABAAANg");
	this.shape_169.setTransform(301.4,-3.9,1.819,1.819);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgLAAAAgRQAAgQALAAQALAAAAAQgAgGAAQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_170.setTransform(296.1,-4.9,1.819,1.819);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#FFFFFF").s().p("AgLAAQAAgQALAAQAMAAAAAQQAAARgMAAQgLAAAAgRgAgGAAQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_171.setTransform(296.1,-4.9,1.819,1.819);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgCAQIAAgbIgIAAIAAgEIAVAAIAAAEIgJAAIAAAbg");
	this.shape_172.setTransform(291.4,-4.9,1.819,1.819);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#FFFFFF").s().p("AgCAQIAAgbIgIAAIAAgEIAVAAIAAAEIgJAAIAAAbg");
	this.shape_173.setTransform(291.4,-4.9,1.819,1.819);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAIAAAAAIIAAASQAAADACAAIABAAIAAADIgCAAQgEAAgBgEQgBAFgFAAQgIAAAAgJQAAgHAHgCIAGgCQAAgBAAgDQAAgFgDAAQgFAAAAAGgAgGAIQAAAFAFAAQAEAAAAgHIAAgGQgCAAgDACQgEACAAAEg");
	this.shape_174.setTransform(287,-4.9,1.819,1.819);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAHgCIAGgCQAAAAAAgBQAAAAAAAAQAAgBAAgBQAAAAAAgBQAAgFgDAAQgFAAAAAGIgEAAQAAgKAJAAQAIAAAAAIIAAASQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIABAAIAAADIgCAAQgEAAgBgEQgCAFgEAAQgIAAAAgJgAgCACQgDACgBAEQABAFAEAAQAEAAAAgHIAAgGIgFACg");
	this.shape_175.setTransform(287,-4.9,1.819,1.819);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgIgGQAAgKAIAAQAKAAAAAIQAAAGgGACQAHAAAAAHQAAAKgLAAQgIAAgBgLIAEAAQABAHAEAAQAGAAAAgGQAAgGgFAAIgCAAIAAgDIACAAQAEAAAAgFQAAgFgFAAQgEAAAAAGg");
	this.shape_176.setTransform(282,-4.9,1.819,1.819);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#FFFFFF").s().p("AgJAGIAEAAQAAAHAFAAQAFAAAAgGQAAgGgFAAIgBAAIAAgDIABAAQAFAAAAgFQAAgFgFAAQgFAAAAAGIgEAAQAAgKAJAAQAJAAAAAIQAAAGgFACQAGAAAAAHQAAAKgKAAQgJAAAAgLg");
	this.shape_177.setTransform(282.1,-4.9,1.819,1.819);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIgBAEIABgEIAKgXIAGAAIAAAfIgFAAIAAgXIAAgEIgBAEIgJAXIgGAAIAAgfg");
	this.shape_178.setTransform(277.2,-4.9,1.819,1.819);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIAAgEIgBAEIgJAXIgGAAIAAgfIAFAAIAAAXIgBAEIABgEIAKgXIAGAAIAAAfg");
	this.shape_179.setTransform(277.2,-4.9,1.819,1.819);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgEgCIAKAAIAAgNIAEAAIAAAfIgEAAIAAgPIgKAAIAAAPIgFAAIAAgfIAFAAg");
	this.shape_180.setTransform(271.8,-4.9,1.819,1.819);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#FFFFFF").s().p("AAGAQIAAgPIgKAAIAAAPIgFAAIAAgfIAFAAIAAANIAKAAIAAgNIAEAAIAAAfg");
	this.shape_181.setTransform(271.8,-4.9,1.819,1.819);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgJgGQAAgKAJAAQAIAAAAAIIAAASQAAADACAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgBAFgFAAQgIAAAAgJQAAgHAIgCIAFgCQAAgBAAgDQAAgFgDAAQgFAAAAAGgAgGAIQAAAFAFAAQAEAAAAgHIAAgGQgCAAgDACQgEACAAAEg");
	this.shape_182.setTransform(267,-4.9,1.819,1.819);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#FFFFFF").s().p("AgKAIQAAgHAIgCIAFgCQAAAAAAgBQAAAAAAAAQAAgBAAgBQABAAAAgBQgBgFgDAAQgFAAAAAGIgEAAQAAgKAJAAQAIAAAAAIIAAASQAAABABAAQAAABAAAAQAAAAAAABQABAAAAAAIABAAIAAADIgCAAQgEAAgBgEIAAAAQgCAFgEAAQgIAAAAgJgAgCACQgEACABAEQgBAFAFAAQAEAAABgHIAAgGIgGACg");
	this.shape_183.setTransform(267,-4.9,1.819,1.819);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAJgPIAAAEIgLAAIAAAbIgFAAIAAgfg");
	this.shape_184.setTransform(262.8,-4.9,1.819,1.819);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#FFFFFF").s().p("AgIAQIAAgfIARAAIAAAEIgLAAIAAAbg");
	this.shape_185.setTransform(262.8,-4.9,1.819,1.819);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgRQACgEADAAQALAAAAAQQAAARgKAAQgEAAgCgEIAAAOIgFAAIAAgqIAFAAgAgFgFQAAANAFAAQAGAAAAgNQAAgMgGAAQgFAAAAAMg");
	this.shape_186.setTransform(258,-3.9,1.819,1.819);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#FFFFFF").s().p("AgKAWIAAgqIAFAAIAAADQACgEADAAQALAAAAAQQAAAQgKAAQgEAAgCgEIAAAPgAgFgEQAAAMAFAAQAGAAAAgNQAAgNgGAAQgFABAAANg");
	this.shape_187.setTransform(258,-3.9,1.819,1.819);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgLAAAAgRQAAgQALAAQALAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_188.setTransform(252.6,-4.9,1.819,1.819);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#FFFFFF").s().p("AgLAAQAAgQALAAQALAAABAQQgBARgLAAQgLAAAAgRgAgGAAQABANAFAAQAHAAAAgNQAAgMgHAAQgFAAgBAMg");
	this.shape_189.setTransform(252.6,-4.9,1.819,1.819);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AABgJQALAAAAAOQAAARgMAAQgKAAAAgTQAAgRAKgDQAGgCAAgCIAEAAQgBAGgIABQgGACgBAIQADgFAEAAgAAHAFQAAgKgHAAQgGAAAAAKQAAAOAGAAQAHAAAAgOg");
	this.shape_190.setTransform(244.8,-5.8,1.819,1.819);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#FFFFFF").s().p("AgKADQAAgRAKgEQAGgBAAgCIAEAAQgBAFgJACQgFACgBAIQADgFADAAQAMAAgBAOQAAARgLAAQgKAAAAgTgAgGAFQAAAOAGAAQAHAAAAgOQAAgKgHAAQgGAAAAAKg");
	this.shape_191.setTransform(244.8,-5.8,1.819,1.819);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgKAAAAgRQAAgQAKAAQALAAAAAQgAgGAAQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_192.setTransform(239.5,-4.9,1.819,1.819);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#FFFFFF").s().p("AgLAAQAAgQALAAQAMAAgBAQQABARgMAAQgLAAAAgRgAgGAAQAAANAGAAQAHAAgBgNQABgMgHAAQgGAAAAAMg");
	this.shape_193.setTransform(239.5,-4.9,1.819,1.819);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgPIAAAXIgBAEIABAAIAAgEIAKgXIAGAAIAAAfIgFAAIAAgXIABgEIgBAAIAAAEIgKAXIgGAAIAAgfg");
	this.shape_194.setTransform(231.6,-4.9,1.819,1.819);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#FFFFFF").s().p("AAGAQIAAgXIABgEIgBAAIAAAEIgKAXIgGAAIAAgfIAFAAIAAAXIgBAEIABAAIAAgEIAKgXIAGAAIAAAfg");
	this.shape_195.setTransform(231.6,-4.9,1.819,1.819);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgCAQIAAgbIgIAAIAAgEIAVAAIAAAEIgIAAIAAAbg");
	this.shape_196.setTransform(226.8,-4.9,1.819,1.819);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#FFFFFF").s().p("AgBAQIAAgbIgIAAIAAgEIATAAIAAAEIgIAAIAAAbg");
	this.shape_197.setTransform(226.8,-4.9,1.819,1.819);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFAAQAAANAGAAQAEAAABgIIAEAAQAAAMgJAAQgKAAAAgRQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMg");
	this.shape_198.setTransform(222.4,-4.9,1.819,1.819);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#FFFFFF").s().p("AgJAAQAAgQAKAAQAJAAAAALIgEAAQAAgHgFAAQgGAAAAAMQAAANAGAAQAEAAABgIIAEAAQAAAMgJAAQgKAAAAgRg");
	this.shape_199.setTransform(222.4,-4.9,1.819,1.819);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMAAQAAARgMAAQgKAAAAgRQAAgQAKAAQAMAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_200.setTransform(217.3,-4.9,1.819,1.819);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQABARgMAAQgKAAAAgRgAgGAAQAAANAGAAQAGAAABgNQgBgMgGAAQgGAAAAAMg");
	this.shape_201.setTransform(217.3,-4.9,1.819,1.819);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgFgCIAKAAIAAgNIAFAAIAAAfIgFAAIAAgPIgKAAIAAAPIgEAAIAAgfIAEAAg");
	this.shape_202.setTransform(212.1,-4.9,1.819,1.819);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#FFFFFF").s().p("AAFAQIAAgPIgKAAIAAAPIgEAAIAAgfIAEAAIAAANIAKAAIAAgNIAFAAIAAAfg");
	this.shape_203.setTransform(212.1,-4.9,1.819,1.819);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AABgJQAKAAAAAOQAAARgLAAQgKAAAAgTQAAgRAKgDQAGgCAAgCIAEAAQgBAGgIABQgGACgBAIQADgFAEAAgAAHAFQAAgKgHAAQgFAAAAAKQAAAOAFAAQAHAAAAgOg");
	this.shape_204.setTransform(206.8,-5.8,1.819,1.819);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#FFFFFF").s().p("AgLADQAAgRALgEQAGgBAAgCIAEAAQgBAFgIACQgGACgBAIQAEgFADAAQAKAAAAAOQABARgMAAQgLAAAAgTgAgFAFQAAAOAFAAQAHAAAAgOQAAgKgHAAQgFAAAAAKg");
	this.shape_205.setTransform(206.8,-5.8,1.819,1.819);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALAAQAAARgLAAQgKAAAAgRQAAgQAKAAQALAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_206.setTransform(201.5,-4.9,1.819,1.819);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#FFFFFF").s().p("AgKAAQAAgQAKAAQALAAAAAQQAAARgLAAQgKAAAAgRgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_207.setTransform(201.5,-4.9,1.819,1.819);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgRIABAAQABgEAEAAQALAAAAAQQAAARgLAAQgDAAgDgEIAAAOIgEAAIAAgqIAEAAgAgGgFQAAANAGAAQAGAAAAgNQAAgMgGAAQgGAAAAAMg");
	this.shape_208.setTransform(196.4,-3.9,1.819,1.819);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#FFFFFF").s().p("AgKAWIAAgqIAFAAIAAADIAAAAQABgEAEAAQALAAAAAQQAAAQgLAAQgDAAgCgEIAAAPgAgFgEQgBAMAGAAQAGAAAAgNQAAgNgGAAQgGABABANg");
	this.shape_209.setTransform(196.4,-3.9,1.819,1.819);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AgGgJIAAgLIAQAAIAAAcIADAAIAAAMIgEAAIAAgIIgRAAIAAAIIgFAAIAAgMIADAAQAEgHAAgKgAAGgQIgIAAIAAAJQAAAHgDAIIALAAg");
	this.shape_210.setTransform(190.9,-4.1,1.819,1.819);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#FFFFFF").s().p("AAJAUIAAgIIgRAAIAAAIIgEAAIAAgMIADAAQADgHAAgKIAAgKIAQAAIAAAbIAEAAIAAAMgAgBgHQgBAIgDAHIALAAIAAgYIgHAAg");
	this.shape_211.setTransform(190.9,-4.1,1.819,1.819);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AAMAAQAAARgMAAQgLAAAAgRQAAgQALAAQAMAAAAAQgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_212.setTransform(185.7,-4.9,1.819,1.819);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#FFFFFF").s().p("AgKAAQgBgQALAAQALAAAAAQQAAARgLAAQgLAAABgRgAgGAAQAAANAGAAQAHAAAAgNQAAgMgHAAQgGAAAAAMg");
	this.shape_213.setTransform(185.7,-4.9,1.819,1.819);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AANgVIAAArIgFAAIAAgmIgPAAIAAAmIgFAAIAAgrg");
	this.shape_214.setTransform(179.8,-5.9,1.819,1.819);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#FFFFFF").s().p("AAIAWIAAgmIgQAAIAAAmIgEAAIAAgrIAZAAIAAArg");
	this.shape_215.setTransform(179.8,-5.9,1.819,1.819);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_216.setTransform(172.7,-2.5,1.819,1.819);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_217.setTransform(172.7,-2.5,1.819,1.819);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALgUIAAAEQgLAQgCAVIgFAAQACgUAMgRIgSAAIAAgEg");
	this.shape_218.setTransform(168.9,-5.8,1.819,1.819);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#FFFFFF").s().p("AgHAVQACgUANgRIgTAAIAAgEIAXAAIAAAEQgMAQgBAVg");
	this.shape_219.setTransform(168.8,-5.8,1.819,1.819);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AACgJIgIAAIAAgEQAJAAAAgIIAEAAIAAArIgFAAg");
	this.shape_220.setTransform(163,-5.9,1.819,1.819);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#FFFFFF").s().p("AACAWIAAgfIgIAAIAAgEQAJAAAAgIIAEAAIAAArg");
	this.shape_221.setTransform(163,-5.9,1.819,1.819);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_222.setTransform(159.6,-2.5,1.819,1.819);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_223.setTransform(159.6,-2.5,1.819,1.819);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AACgJIgIAAIAAgEQAIAAABgIIAEAAIAAArIgFAAg");
	this.shape_224.setTransform(155.1,-5.9,1.819,1.819);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#FFFFFF").s().p("AACAWIAAgfIgIAAIAAgEQAIAAACgIIADAAIAAArg");
	this.shape_225.setTransform(155.1,-5.9,1.819,1.819);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AACgJIgIAAIAAgEQAJAAAAgIIAEAAIAAArIgFAAg");
	this.shape_226.setTransform(149.9,-5.9,1.819,1.819);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#FFFFFF").s().p("AACAWIAAgfIgIAAIAAgEQAJAAAAgIIAEAAIAAArg");
	this.shape_227.setTransform(149.9,-5.9,1.819,1.819);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AADgCIAAAFIgFAAIAAgFg");
	this.shape_228.setTransform(146.5,-2.5,1.819,1.819);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#FFFFFF").s().p("AgCADIAAgFIAFAAIAAAFg");
	this.shape_229.setTransform(146.5,-2.5,1.819,1.819);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#FFFFFF").ss(0.3,0,0,4).p("AALgUIAAAEQgLAQgCAVIgFAAQACgUAMgRIgSAAIAAgEg");
	this.shape_230.setTransform(142.7,-5.8,1.819,1.819);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#FFFFFF").s().p("AgHAVQACgUANgRIgTAAIAAgEIAXAAIAAAEQgMAQgBAVg");
	this.shape_231.setTransform(142.6,-5.8,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ11, new cjs.Rectangle(-67.7,-11.1,613.6,12.3), null);


(lib.Символ10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOA+IgUgxIgKAMIAAAlIgXAAIAAh7IAXAAIAAA2IAcg2IAbAAIgfA2IAgBFg");
	this.shape.setTransform(55.7,0,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAUA+IgGggIgZAAIgIAgIgZAAIAfh7IAfAAIAbB7gAgIALIATAAIgKg5g");
	this.shape_1.setTransform(38.4,0,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AggA+IAAh7IBBAAIAAAUIgqAAIAAAcIAmAAIAAASIgmAAIAAAmIAqAAIAAATg");
	this.shape_2.setTransform(22.8,0,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgmA+IAAh7IAsAAQAKAAAHAEQAIAGAEAIQAEAJAAAJQAAAKgEAJQgFAHgHAGQgJAFgJAAIgTAAIAAAygAgOgGIAMAAQAQAAAAgTQAAgSgQAAIgMAAg");
	this.shape_3.setTransform(7,0,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AggA+IAAh7IBBAAIAAAUIgqAAIAAAcIAmAAIAAASIgmAAIAAAmIAqAAIAAATg");
	this.shape_4.setTransform(-8.9,0,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdA2QgIgMAAgTIAAgsQAAgVAKgLQAKgLASAAQAMAAAIAEQAIAFAFAJQAEAIAAALIAAAGIgYAAIAAgDQAAgMgDgEQgDgFgIAAQgGAAgEAFQgDAFAAALIAAAxQAAALADAFQADAFAHAAQAHAAAEgFQADgFAAgLIAAgHIAYAAIAAAFQAAALgDAKQgEAKgIAGQgJAFgOAAQgUAAgJgLg");
	this.shape_5.setTransform(-24.7,0,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgLA+IAAh7IAXAAIAAB7g");
	this.shape_6.setTransform(-36.6,0,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgdA2QgIgLAAgUIAAgsQAAgXAJgJQALgLARAAQANAAAIAEQAIAFAFAJQAEAIAAALIAAAGIgXAAIAAgDQgBgLgDgFQgDgFgIAAQgGAAgEAFQgDAEAAAMIAAAxQAAAMADAEQADAFAHAAQAHAAAEgFQADgGABgKIAAgHIAXAAIAAAFQAAANgEAIQgDAKgIAGQgJAFgOAAQgUAAgJgLg");
	this.shape_7.setTransform(-56,0,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ10, new cjs.Rectangle(-62.9,-11.8,126,23.7), null);


(lib.Символ9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgcA9IAAgSIAIACQAGAAAEgKIgjhhIAbAAIASBBIAThBIAaAAIgiBkQgCAIgEAHQgFAGgCACQgFADgGAAQgJAAgGgDg");
	this.shape.setTransform(53.8,0,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAQA+IAAg6IgfAAIAAA6IgXAAIAAh7IAXAAIAAAwIAfAAIAAgwIAXAAIAAB7g");
	this.shape_1.setTransform(36.4,-0.2,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AARA+IAAgvQAAgbADgPIghBZIgaAAIAAh7IAWAAIAAA+IgDAbIAihZIAaAAIAAB7g");
	this.shape_2.setTransform(18.9,-0.2,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ag8A+IAAh7IAXAAIAABoIAaAAIAAhoIAXAAIAABoIAaAAIAAhoIAXAAIAAB7g");
	this.shape_3.setTransform(-2.7,-0.2,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgmA+IAAh7IAsAAQAKAAAHAEQAIAFAEAJQAEAHAAALQAAALgEAIQgEAHgIAFQgIAGgJAAIgUAAIAAAygAgOgGIAMAAQARAAAAgSQAAgTgRAAIgMAAg");
	this.shape_4.setTransform(-23.6,-0.2,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggA+IAAh7IBBAAIAAAUIgqAAIAAAcIAnAAIAAARIgnAAIAAAnIAqAAIAAATg");
	this.shape_5.setTransform(-39.4,-0.2,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AglA+IAAh7IAqAAQALAAAHADQAHAFADAGQAEAKAAAGQAAAFgDAHQgBAGgEAEQgEAEgFABQAJAEAEAGQAFAHAAAMQAAAMgDAHQgEAKgGAEQgHAEgIAAgAgOAsIAPAAQAHABADgFQADgEAAgLQAAgTgNAAIgPAAgAgOgLIANAAQANAAABgRQgBgIgCgEQgEgDgHAAIgNAAg");
	this.shape_6.setTransform(-55.1,-0.2,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ9, new cjs.Rectangle(-62,-11.5,124.2,23.1), null);


(lib.Символ8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AARA/IAAgvQAAgdAEgOIgiBaIgaAAIAAh9IAXAAIgCBPIgCALIAihaIAaAAIAAB9g");
	this.shape.setTransform(43.1,0,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmA/IAAh9IAsAAQAIAAAJAGQAIAFAEAIQAEAJAAAJQAAALgFAIQgEAIgHAFQgHAEgLAAIgTAAIAAA0gAgOgGIALAAQARAAAAgTQAAgSgRAAIgLAAg");
	this.shape_1.setTransform(26.1,0,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgnAWIAAgrQAAgPAFgJQAFgKAJgFQAJgDALAAQAMAAAKADQAIAFAGAJQAEAKAAAPIAAArQAAAQgEAJQgGAKgIAEQgIADgOAAQgnABAAgrgAgPgYIAAAyQAAATAPABQAIAAAEgGQAEgFAAgJIAAgyQAAgIgEgHQgEgFgIAAQgPAAAAAUg");
	this.shape_2.setTransform(8.7,0,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AANA/IgTgzIgJANIAAAmIgYAAIAAh9IAYAAIAAA3IAbg3IAbAAIgfA3IAgBGg");
	this.shape_3.setTransform(-7.9,0,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgoAWIAAgrQABgNAFgLQAEgJAKgGQAKgDAKAAQANAAAIADQAJAFAGAJQAEALAAAOIAAArQAAAOgEALQgGAKgJAEQgHADgOAAQgoABAAgrgAgPgYIAAAyQAAATAPABQAJAAADgGQAEgEAAgKIAAgyQAAgKgEgFQgEgFgIAAQgPAAAAAUg");
	this.shape_4.setTransform(-25.6,0,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAQA/IAAhqIgeAAIAABqIgYAAIAAh9IBNAAIAAB9g");
	this.shape_5.setTransform(-43.2,0,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ8, new cjs.Rectangle(-50.3,-11.7,100.6,23.5), null);


(lib.Символ7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhHBDQADgRAggMIAtAAIAGgVIhJAAQAKgYAYgEIAvAAIAHgaIhNAAQAHgWAZgHIBXAAIglCFg");
	this.shape.setTransform(-51,-0.1,1.819,1.819);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E76720").s().p("AguAwQgTgUAAgcQAAgaATgVQATgTAbAAQAbAAAUATQATAUAAAbQAAAcgTAUQgUATgbAAQgbAAgTgTg");
	this.shape_1.setTransform(85.3,0.1,1.819,1.819);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAABDQgHghgDgKQgIgOgHAAIgYAAIAJgcIAbAAQANABAGgQIAKghIAjAAIgRA3QgDALgPAGIATA9g");
	this.shape_2.setTransform(59.2,0.1,1.819,1.819);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgjBCIAkiDIAjAAIgkCDg");
	this.shape_3.setTransform(44.8,0,1.819,1.819);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AANBDIAJgeIgxAAIAIgaIAwAAIAOgsIgeAAQgSAAgJAEQgJAGgEANIgXBMIghAAIAbhfQAEgSAQgKQANgJAQAAIBbAAIglCFg");
	this.shape_4.setTransform(25.3,0.1,1.819,1.819);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhRBDIAliFIB9AAIgUA3QgEALgLAGQgKAGgMAAIgpAAIAJgcIAbAAQAKAAAGgLQADgFAAgGIg2AAIgdBpg");
	this.shape_5.setTransform(-25.5,0.1,1.819,1.819);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhHBDQADgQAggNIAtAAIAGgVIhJAAQAKgYAYgFIAvAAIAHgZIhNAAQAHgWAagHIBWAAIgmCFg");
	this.shape_6.setTransform(-0.2,0.1,1.819,1.819);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgvBDQgIAAgFgEQgFgDAAgIIAAgDIAZhgQAEgKAIgFQAHgEAQAAIBHAAQgCALgOAKIgOAIIgiAAQgFAAgCADQgDABgDAFIgRBBIAJABIA8AAIgFAKQgEAKgHAFQgIAEgXAAg");
	this.shape_7.setTransform(-73.9,0.1,1.819,1.819);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgiBDIAiiFIAjAAIgjCFg");
	this.shape_8.setTransform(-91,0.1,1.819,1.819);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AnsCBQhEAAgcg2QgIgRgEgVIgCgSIAAglQAAhEA3gcQAbgOAcAAIPZAAQBEAAAbA2QAOAcABAcIAAAlQAABEg2AcQgSAJgVADIgRACgAohhrQgxAZABBAIAAAlQAAAIACAKQACATAJAQQAZAxA/AAIPZAAQAIAAAJgCQATgDAQgIQAxgZAAhAIAAglQAAgcgNgZQgZgxg/AAIvZAAQgcAAgZANg");
	this.shape_9.setTransform(0,0,1.819,1.819);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AnsB9QhCAAgag1QgJgQgDgUIgCgRIAAglQAAhCA1gbQAbgNAaAAIPZAAQBCAAAbA1QANAaAAAbIAAAlQAABDg1AaQgQAIgUAEIgRABg");
	this.shape_10.setTransform(0,0,1.819,1.819);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ7, new cjs.Rectangle(-109.6,-23.5,219.4,47.1), null);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._2();
	this.instance.parent = this;
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ3, new cjs.Rectangle(-120,-200,728,209), null);


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ2, new cjs.Rectangle(-120,-200,728,207), null);


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 1
	this.instance = new lib._0();
	this.instance.parent = this;
	this.instance.setTransform(-120,-200);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ1, new cjs.Rectangle(-120,-200,728,135), null);


// stage content:
(lib._728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("Eg4ygG8MBxlAAAIAAN5MhxlAAAg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},257).wait(1));

	// logo
	this.instance = new lib.Символ7();
	this.instance.parent = this;
	this.instance.setTransform(600.9,45.2,0.912,0.091,0,0,0,0,1.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90).to({_off:false},0).to({regY:0.1,scaleY:0.91,y:45.1},8,cjs.Ease.get(1)).wait(61).to({regY:1.6,scaleY:0.1,y:45.2},6,cjs.Ease.get(1)).to({_off:true},1).wait(92));

	// Символ 15
	this.instance_1 = new lib.Символ15();
	this.instance_1.parent = this;
	this.instance_1.setTransform(350,45);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(82).to({_off:false},0).to({scaleY:1.03,skewX:-13.7,x:113.8,alpha:1},5,cjs.Ease.get(1)).to({scaleY:1,skewX:0,x:120},2).wait(70).to({scaleY:1.02,skewX:-10.4,x:115},0).to({x:-115,alpha:0},6,cjs.Ease.get(1)).to({_off:true},1).wait(92));

	// Символ 14
	this.instance_2 = new lib.Символ14();
	this.instance_2.parent = this;
	this.instance_2.setTransform(556.5,45);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(83).to({_off:false},0).to({scaleY:1.03,skewX:-14.4,x:320.3,alpha:1},5,cjs.Ease.get(1)).to({scaleY:1,skewX:0,x:326.5},2).wait(68).to({scaleY:1.02,skewX:-12.6},0).to({x:96.5,alpha:0},6,cjs.Ease.get(1)).to({_off:true},2).wait(92));

	// Символ 13
	this.instance_3 = new lib.Символ13();
	this.instance_3.parent = this;
	this.instance_3.setTransform(418.9,45.3,0.75,0.75,0,0,0,0.6,0.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1).to({_off:false},0).to({regY:0.2,scaleY:0.76,skewX:-7.6,x:256.4,y:45.2,alpha:1},5,cjs.Ease.get(1)).to({regX:0,regY:0,scaleY:0.75,skewX:0,x:263.8,y:45},2,cjs.Ease.get(1)).wait(69).to({scaleY:0.75,skewX:-5.3,x:260},0).to({x:106.3,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(173));

	// Символ 12
	this.instance_4 = new lib.Символ12();
	this.instance_4.parent = this;
	this.instance_4.setTransform(325.6,46);
	this.instance_4.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({scaleY:1.03,skewX:-13.6,x:120.6,alpha:1},5,cjs.Ease.get(1)).to({scaleY:1,skewX:0,x:130.6},2).wait(69).to({scaleY:1.03,skewX:-13.6,x:125.6},0).to({x:-79.4,alpha:0},7,cjs.Ease.get(1)).to({_off:true},1).wait(174));

	// Layer 1
	this.instance_5 = new lib.Символ11();
	this.instance_5.parent = this;
	this.instance_5.setTransform(124.3,87.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(5).to({_off:false},0).to({alpha:1},8,cjs.Ease.get(1)).wait(64).to({alpha:0},7).to({_off:true},1).wait(173));

	// Символ 10
	this.instance_6 = new lib.Символ10();
	this.instance_6.parent = this;
	this.instance_6.setTransform(676,45);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(173).to({_off:false},0).to({scaleY:1.06,skewX:-18.7,x:481.5,alpha:1},7,cjs.Ease.get(1)).to({scaleY:1,skewX:0,x:486},3,cjs.Ease.get(1)).wait(68).to({scaleY:1.01,skewX:-9.6,x:481},0).to({scaleY:1.09,skewX:-23,x:296,alpha:0},5).to({_off:true},1).wait(1));

	// Символ 9
	this.instance_7 = new lib.Символ9();
	this.instance_7.parent = this;
	this.instance_7.setTransform(540.5,46.1,1,1,0,0,0,0,1.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(172).to({_off:false},0).to({scaleY:1.08,skewX:-21.6,x:346,alpha:1},7,cjs.Ease.get(1)).to({regY:0,scaleY:1,skewX:0,x:350.5,y:45},3,cjs.Ease.get(1)).wait(68).to({scaleY:1.03,skewX:-14.6,x:345.5},0).to({scaleY:1.06,skewX:-19.1,x:160.5,alpha:0},5).to({_off:true},1).wait(2));

	// Символ 8
	this.instance_8 = new lib.Символ8();
	this.instance_8.parent = this;
	this.instance_8.setTransform(416,46.1,1,1,0,0,0,0,1.1);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(171).to({_off:false},0).to({regX:0.1,scaleY:1.01,skewX:-8.9,x:221.6,alpha:1},7,cjs.Ease.get(1)).to({regX:0,regY:0,scaleY:1,skewX:0,x:226,y:45},3,cjs.Ease.get(1)).wait(68).to({scaleY:1.02,skewX:-12.1,x:221},0).to({scaleY:1.06,skewX:-18.9,x:36,alpha:0},5).to({_off:true},1).wait(3));

	// Символ 3
	this.instance_9 = new lib.Символ3();
	this.instance_9.parent = this;
	this.instance_9.setTransform(120,140);
	this.instance_9.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({y:169.7,alpha:1},84).to({y:200,alpha:0},86).to({_off:true},1).wait(87));

	// Символ 2
	this.instance_10 = new lib.Символ2();
	this.instance_10.parent = this;
	this.instance_10.setTransform(120,141.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).to({y:201},84).to({_off:true},1).wait(86).to({_off:false,y:80,alpha:0},0).to({y:140.9,alpha:1},86).wait(1));

	// Символ 1
	this.instance_11 = new lib.Символ1();
	this.instance_11.parent = this;
	this.instance_11.setTransform(120,200);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(85).to({_off:false},0).to({y:179.6,alpha:1},86).to({y:156,alpha:0},86).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(363.5,-15,729,209);
// library properties:
lib.properties = {
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_atlas_NP_.jpg?1508080912769", id:"728x90_atlas_NP_"}
	],
	preloads: []
};




})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{}, AdobeAn = AdobeAn||{});
var lib, images, createjs, ss, AdobeAn;
import React, { Component } from "react";

import '../styles/App.less';
import '../styles/common.less';

class App extends Component {
    render() {
        return (
            <div>
                <h1>My React App!!</h1>
                <img src="../images/av-26741.jpg" alt=""/>
            </div>
        );
    }
}

export default App;